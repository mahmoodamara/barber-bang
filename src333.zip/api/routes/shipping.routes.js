// src/api/routes/shipping.routes.js
import { Router } from "express";
import { asyncHandler } from "../../middlewares/asyncHandler.js";
import { validate } from "../../middlewares/validate.js";
import { endpointLimiterMongo } from "../../middlewares/endpointLimiterMongo.js";
import { listPublic } from "../../controllers/shipping.controller.js";
import { listShippingMethodsQuerySchema } from "../../validators/shipping.validators.js";

// New 3-mode shipping system
import {
  listAreas,
  listPickupPointsForArea,
  getStorePickup,
  listShippingModes,
} from "../../controllers/publicShipping.controller.js";

const router = Router();

/* ------------------------------------------------------------------ */
/* Legacy: Shipping Methods                                            */
/* ------------------------------------------------------------------ */

router.get(
  "/methods",
  endpointLimiterMongo({ scope: "shipping:methods_public", windowMs: 60_000, max: 120, messageCode: "RATE_LIMITED" }),
  validate(listShippingMethodsQuerySchema),
  asyncHandler(listPublic),
);

/* ------------------------------------------------------------------ */
/* New 3-Mode Shipping System (DELIVERY, PICKUP_POINT, STORE_PICKUP)   */
/* ------------------------------------------------------------------ */

// Get available shipping modes
router.get(
  "/modes",
  endpointLimiterMongo({ scope: "shipping:modes_public", windowMs: 60_000, max: 120, messageCode: "RATE_LIMITED" }),
  asyncHandler(listShippingModes),
);

// Get active delivery areas
router.get(
  "/areas",
  endpointLimiterMongo({ scope: "shipping:areas_public", windowMs: 60_000, max: 120, messageCode: "RATE_LIMITED" }),
  asyncHandler(listAreas),
);

// Get pickup points for a specific area
router.get(
  "/areas/:areaId/pickup-points",
  endpointLimiterMongo({ scope: "shipping:pickup_points_public", windowMs: 60_000, max: 120, messageCode: "RATE_LIMITED" }),
  asyncHandler(listPickupPointsForArea),
);

// Get store pickup configuration
router.get(
  "/store-pickup",
  endpointLimiterMongo({ scope: "shipping:store_pickup_public", windowMs: 60_000, max: 120, messageCode: "RATE_LIMITED" }),
  asyncHandler(getStorePickup),
);

export default router;
