import express from "express";
import { z } from "zod";
import mongoose from "mongoose";

import { Review } from "../models/Review.js";
import { requireAuth, requirePermission, PERMISSIONS } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { sendOk, sendError } from "../utils/response.js";
import { auditAdmin } from "../middleware/audit.js";

const router = express.Router();

// Auth: Staff with PRODUCTS_WRITE or Admin
router.use(requireAuth());
router.use(requirePermission(PERMISSIONS.PRODUCTS_WRITE));
router.use(auditAdmin());

/* ============================
   Helpers
============================ */

function isValidObjectId(id) {
    return mongoose.Types.ObjectId.isValid(String(id || ""));
}

function safeNotFound(res, code = "NOT_FOUND", message = "Review not found") {
    return sendError(res, 404, code, message);
}

/* ============================
   Schemas
============================ */

const listQuerySchema = z.object({
    query: z
        .object({
            page: z.string().regex(/^\d+$/).optional(),
            limit: z.string().regex(/^\d+$/).optional(),
            productId: z.string().optional(),
            userId: z.string().optional(),
            status: z.enum(["approved", "pending", "rejected"]).optional(),
            isHidden: z.enum(["true", "false"]).optional(),
            rating: z.enum(["1", "2", "3", "4", "5"]).optional(),
            dateFrom: z.string().datetime().optional(),
            dateTo: z.string().datetime().optional(),
        })
        .strict()
        .optional(),
});

const updateSchema = z.object({
    params: z.object({ id: z.string().min(1) }),
    body: z.object({
        isHidden: z.boolean().optional(),
        moderationStatus: z.enum(["approved", "pending", "rejected"]).optional(),
        moderationNote: z.string().max(500).optional(),
    }).strict(),
});

/* ============================
   GET /api/admin/reviews
============================ */
router.get("/", validate(listQuerySchema), async (req, res) => {
    try {
        const q = req.validated.query || {};
        const page = Math.max(1, Number(q.page || 1));
        const limit = Math.min(100, Math.max(1, Number(q.limit || 20)));
        const skip = (page - 1) * limit;

        const filter = {};

        if (q.productId && isValidObjectId(q.productId)) filter.productId = q.productId;
        if (q.userId && isValidObjectId(q.userId)) filter.userId = q.userId;
        if (q.status) filter.moderationStatus = q.status;
        if (q.isHidden) filter.isHidden = q.isHidden === "true";
        if (q.rating) filter.rating = Number(q.rating);

        if (q.dateFrom || q.dateTo) {
            filter.createdAt = {};
            if (q.dateFrom) filter.createdAt.$gte = new Date(q.dateFrom);
            if (q.dateTo) filter.createdAt.$lte = new Date(q.dateTo);
        }

        const [items, total] = await Promise.all([
            Review.find(filter)
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(limit)
                .populate("productId", "name slug images") // Minimal product info
                .populate("userId", "name email") // Minimal user info
                .populate("moderatedBy", "name") // Moderator info
                .lean(),
            Review.countDocuments(filter),
        ]);

        return sendOk(res, items, {
            page,
            limit,
            total,
            pages: Math.ceil(total / limit),
        });
    } catch (e) {
        return sendError(res, 500, "SERVER_ERROR", e.message);
    }
});

/* ============================
   GET /api/admin/reviews/:id
============================ */
router.get("/:id", async (req, res) => {
    try {
        const id = String(req.params.id || "");
        if (!isValidObjectId(id)) return safeNotFound(res);

        const item = await Review.findById(id)
            .populate("productId", "name slug images")
            .populate("userId", "name email")
            .populate("moderatedBy", "name")
            .lean();

        if (!item) return safeNotFound(res);

        return sendOk(res, item);
    } catch (e) {
        return sendError(res, 500, "SERVER_ERROR", e.message);
    }
});

/* ============================
   PATCH /api/admin/reviews/:id
============================ */
router.patch("/:id", validate(updateSchema), async (req, res) => {
    try {
        const id = String(req.params.id || "");
        if (!isValidObjectId(id)) return safeNotFound(res);

        const { isHidden, moderationStatus, moderationNote } = req.validated.body;

        const update = {};
        if (isHidden !== undefined) update.isHidden = isHidden;
        if (moderationStatus !== undefined) update.moderationStatus = moderationStatus;
        if (moderationNote !== undefined) update.moderationNote = moderationNote;

        // Track who moderated
        if (Object.keys(update).length > 0) {
            update.moderatedBy = req.user._id;
            update.moderatedAt = new Date();
        }

        const item = await Review.findByIdAndUpdate(id, update, { new: true })
            .populate("productId", "name")
            .populate("userId", "name");

        if (!item) return safeNotFound(res);

        return sendOk(res, item);
    } catch (e) {
        return sendError(res, 500, "SERVER_ERROR", e.message);
    }
});

/* ============================
   DELETE /api/admin/reviews/:id
============================ */
router.delete("/:id", async (req, res) => {
    try {
        const id = String(req.params.id || "");
        if (!isValidObjectId(id)) return safeNotFound(res);

        const item = await Review.findByIdAndDelete(id);
        if (!item) return safeNotFound(res);

        return sendOk(res, { deleted: true, id });
    } catch (e) {
        return sendError(res, 500, "SERVER_ERROR", e.message);
    }
});

export default router;
