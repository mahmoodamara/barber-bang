// src/routes/admin.orders.routes.js
import express from "express";
import { z } from "zod";
import mongoose from "mongoose";

import { Order } from "../models/Order.js";
import { Product } from "../models/Product.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { auditAdmin } from "../middleware/audit.js";
import { validate } from "../middleware/validate.js";
import { getRequestId } from "../middleware/error.js";
import { mapOrder } from "../utils/mapOrder.js";
import { createStripeRefund } from "../services/stripe.service.js";
import { createInvoiceForOrder, resolveInvoiceProvider } from "../services/invoice.service.js";

const router = express.Router();

router.use(requireAuth());
router.use(requireRole("admin"));
router.use(auditAdmin());

/* ============================
   Helpers
============================ */

function isValidObjectId(id) {
  return mongoose.Types.ObjectId.isValid(String(id || ""));
}

function makeErr(statusCode, code, message) {
  const err = new Error(message);
  err.statusCode = statusCode;
  err.code = code;
  return err;
}

function jsonRes(res, data, meta = null) {
  const payload = { success: true, data };
  if (meta) payload.meta = meta;
  return res.json(payload);
}

function jsonErr(res, e) {
  const req = res.req;
  return res.status(e.statusCode || 500).json({
    success: false,
    error: {
      code: e.code || "INTERNAL_ERROR",
      message: e.message || "Unexpected error",
      requestId: getRequestId(req),
      path: req?.originalUrl || req?.url || "",
    },
  });
}

function safeNotFound(res, code = "NOT_FOUND", message = "Not found") {
  const req = res.req;
  return res.status(404).json({
    success: false,
    error: {
      code,
      message,
      requestId: getRequestId(req),
      path: req?.originalUrl || req?.url || "",
    },
  });
}

function pickIdempotencyKey(req) {
  const raw = String(req.headers["idempotency-key"] || "").trim();
  return raw ? raw.slice(0, 200) : "";
}

/* ============================
   Status State Machine
============================ */

const ORDER_STATUSES = [
  "pending_payment",
  "pending_cod",
  "cod_pending_approval",
  "paid",
  "payment_received",
  "confirmed",
  "stock_confirmed",
  "shipped",
  "delivered",
  "cancelled",
  "refund_pending",
  "partially_refunded",
  "refunded",
  "return_requested",
];

// Define valid transitions
const VALID_TRANSITIONS = {
  pending_payment: ["paid", "cancelled"],
  pending_cod: ["cod_pending_approval", "confirmed", "cancelled"],
  cod_pending_approval: ["confirmed", "cancelled"],
  paid: ["payment_received", "confirmed", "stock_confirmed", "shipped", "refund_pending", "cancelled"],
  payment_received: ["confirmed", "stock_confirmed", "shipped", "refund_pending", "cancelled"],
  confirmed: ["stock_confirmed", "shipped", "cancelled", "refund_pending"],
  stock_confirmed: ["shipped", "cancelled", "refund_pending"],
  shipped: ["delivered", "return_requested"],
  delivered: ["return_requested", "refund_pending"],
  return_requested: ["refund_pending", "partially_refunded", "refunded"],
  refund_pending: ["partially_refunded", "refunded"],
  partially_refunded: ["refunded"],
  refunded: [],
  cancelled: [],
};

function isValidTransition(from, to) {
  const allowed = VALID_TRANSITIONS[from];
  if (!allowed) return false;
  return allowed.includes(to);
}

/* ============================
   Schemas
============================ */

const listQuerySchema = z.object({
  query: z
    .object({
      status: z.string().optional(),
      paymentMethod: z.enum(["stripe", "cod"]).optional(),
      q: z.string().max(120).optional(),
      dateFrom: z.string().datetime().optional(),
      dateTo: z.string().datetime().optional(),
      page: z.string().regex(/^\d+$/).optional(),
      limit: z.string().regex(/^\d+$/).optional(),
    })
    .optional(),
});

const statusUpdateSchema = z.object({
  params: z.object({ id: z.string().min(1) }),
  body: z
    .object({
      status: z.enum(ORDER_STATUSES),
    })
    .strict(),
});

const shippingUpdateSchema = z.object({
  params: z.object({ id: z.string().min(1) }),
  body: z
    .object({
      carrier: z.string().min(1).max(100).optional(),
      trackingNumber: z.string().min(1).max(100).optional(),
      shippedAt: z.string().datetime().optional(),
    })
    .strict(),
});

const cancelSchema = z.object({
  params: z.object({ id: z.string().min(1) }),
  body: z
    .object({
      reason: z.string().min(1).max(400),
      restock: z.boolean().optional(),
    })
    .strict(),
});

const refundSchema = z.object({
  params: z.object({ id: z.string().min(1) }),
  body: z
    .object({
      amount: z.number().min(0).optional(),
      reason: z.enum(["customer_cancel", "return", "out_of_stock", "fraud", "duplicate", "other"]).optional(),
      note: z.string().max(400).optional(),
    })
    .strict(),
});

const invoiceSchema = z.object({
  params: z.object({ id: z.string().min(1) }),
});

const resendEmailSchema = z.object({
  params: z.object({ id: z.string().min(1) }),
  body: z
    .object({
      type: z.enum(["confirmation", "shipping", "invoice"]).optional(),
    })
    .strict()
    .optional(),
});

/* ============================
   GET /api/admin/orders
============================ */

router.get("/", validate(listQuerySchema), async (req, res) => {
  try {
    const q = req.validated.query || {};

    const page = Math.max(1, Number(q.page || 1));
    const limit = Math.min(100, Math.max(1, Number(q.limit || 20)));
    const skip = (page - 1) * limit;

    const filter = {};

    if (q.status) {
      const statuses = q.status.split(",").map((s) => s.trim()).filter(Boolean);
      if (statuses.length === 1) {
        filter.status = statuses[0];
      } else if (statuses.length > 1) {
        filter.status = { $in: statuses };
      }
    }

    if (q.paymentMethod) {
      filter.paymentMethod = q.paymentMethod;
    }

    if (q.dateFrom || q.dateTo) {
      filter.createdAt = {};
      if (q.dateFrom) {
        filter.createdAt.$gte = new Date(q.dateFrom);
      }
      if (q.dateTo) {
        filter.createdAt.$lte = new Date(q.dateTo);
      }
    }

    // Search by order number, user email, or phone
    if (q.q) {
      const search = String(q.q).trim().slice(0, 120);
      if (search) {
        const regex = new RegExp(search.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
        filter.$or = [
          { orderNumber: regex },
          { "shipping.phone": regex },
          { "shipping.address.phone": regex },
        ];

        // Also search by _id if it looks like ObjectId
        if (isValidObjectId(search)) {
          filter.$or.push({ _id: search });
        }
      }
    }

    const [items, total] = await Promise.all([
      Order.find(filter)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .populate("userId", "name email")
        .lean(),
      Order.countDocuments(filter),
    ]);

    const mapped = items.map((o) => ({
      ...mapOrder(o, { lang: req.lang }),
      user: o.userId
        ? {
            id: o.userId._id,
            name: o.userId.name || "",
            email: o.userId.email || "",
          }
        : null,
    }));

    return jsonRes(res, mapped, {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit),
    });
  } catch (e) {
    return jsonErr(res, e);
  }
});

/* ============================
   GET /api/admin/orders/:id
============================ */

router.get("/:id", async (req, res) => {
  try {
    const id = String(req.params.id || "");
    if (!isValidObjectId(id)) {
      return safeNotFound(res, "NOT_FOUND", "Order not found");
    }

    const item = await Order.findById(id).populate("userId", "name email phone");
    if (!item) {
      return safeNotFound(res, "NOT_FOUND", "Order not found");
    }

    const mapped = mapOrder(item, { lang: req.lang });
    mapped.user = item.userId
      ? {
          id: item.userId._id,
          name: item.userId.name || "",
          email: item.userId.email || "",
        }
      : null;

    return jsonRes(res, mapped);
  } catch (e) {
    return jsonErr(res, e);
  }
});

/* ============================
   PATCH /api/admin/orders/:id/status
============================ */

router.patch("/:id/status", validate(statusUpdateSchema), async (req, res) => {
  try {
    const id = String(req.params.id || "");
    if (!isValidObjectId(id)) {
      return safeNotFound(res, "NOT_FOUND", "Order not found");
    }

    const order = await Order.findById(id);
    if (!order) {
      return safeNotFound(res, "NOT_FOUND", "Order not found");
    }

    const { status: nextStatus } = req.validated.body;
    const currentStatus = order.status;

    // Validate state machine transition
    if (!isValidTransition(currentStatus, nextStatus)) {
      throw makeErr(
        400,
        "INVALID_STATUS_TRANSITION",
        `Cannot transition from "${currentStatus}" to "${nextStatus}"`
      );
    }

    const update = { status: nextStatus };

    // Auto-set timestamps
    if (!order.paidAt && (nextStatus === "paid" || nextStatus === "payment_received")) {
      update.paidAt = new Date();
    }
    if (!order.shippedAt && nextStatus === "shipped") {
      update.shippedAt = new Date();
    }
    if (!order.deliveredAt && nextStatus === "delivered") {
      update.deliveredAt = new Date();
    }

    const item = await Order.findByIdAndUpdate(id, { $set: update }, { new: true, runValidators: true });
    if (!item) {
      return safeNotFound(res, "NOT_FOUND", "Order not found");
    }

    return jsonRes(res, mapOrder(item, { lang: req.lang }));
  } catch (e) {
    return jsonErr(res, e);
  }
});

/* ============================
   PATCH /api/admin/orders/:id/shipping
============================ */

router.patch("/:id/shipping", validate(shippingUpdateSchema), async (req, res) => {
  try {
    const id = String(req.params.id || "");
    if (!isValidObjectId(id)) {
      return safeNotFound(res, "NOT_FOUND", "Order not found");
    }

    const order = await Order.findById(id);
    if (!order) {
      return safeNotFound(res, "NOT_FOUND", "Order not found");
    }

    const { carrier, trackingNumber, shippedAt } = req.validated.body;
    const update = {};

    if (carrier) {
      update["shipping.carrier"] = carrier;
    }
    if (trackingNumber) {
      update["shipping.trackingNumber"] = trackingNumber;
    }
    if (shippedAt) {
      update.shippedAt = new Date(shippedAt);
    }

    const item = await Order.findByIdAndUpdate(id, { $set: update }, { new: true, runValidators: true });
    if (!item) {
      return safeNotFound(res, "NOT_FOUND", "Order not found");
    }

    return jsonRes(res, mapOrder(item, { lang: req.lang }));
  } catch (e) {
    return jsonErr(res, e);
  }
});

/* ============================
   POST /api/admin/orders/:id/cancel
============================ */

router.post("/:id/cancel", validate(cancelSchema), async (req, res) => {
  try {
    const id = String(req.params.id || "");
    if (!isValidObjectId(id)) {
      return safeNotFound(res, "NOT_FOUND", "Order not found");
    }

    const order = await Order.findById(id);
    if (!order) {
      return safeNotFound(res, "NOT_FOUND", "Order not found");
    }

    // Check if already cancelled
    if (order.status === "cancelled") {
      return jsonRes(res, mapOrder(order, { lang: req.lang }));
    }

    // Check if can be cancelled
    const nonCancellableStatuses = ["delivered", "refunded", "cancelled"];
    if (nonCancellableStatuses.includes(order.status)) {
      throw makeErr(400, "CANNOT_CANCEL", `Order in status "${order.status}" cannot be cancelled`);
    }

    const { reason, restock } = req.validated.body;

    // Restock items if requested
    if (restock) {
      for (const item of order.items) {
        if (item.variantId) {
          await Product.updateOne(
            { _id: item.productId, "variants._id": item.variantId },
            { $inc: { "variants.$.stock": item.qty } }
          );
        } else {
          await Product.updateOne({ _id: item.productId }, { $inc: { stock: item.qty } });
        }
      }
    }

    const update = {
      status: "cancelled",
      "cancellation.requested": true,
      "cancellation.requestedAt": new Date(),
      "cancellation.requestedBy": "admin",
      "cancellation.cancelledAt": new Date(),
      "cancellation.cancelledBy": "admin",
      "cancellation.reason": reason,
    };

    const item = await Order.findByIdAndUpdate(id, { $set: update }, { new: true, runValidators: true });
    if (!item) {
      return safeNotFound(res, "NOT_FOUND", "Order not found");
    }

    return jsonRes(res, {
      ...mapOrder(item, { lang: req.lang }),
      restocked: Boolean(restock),
    });
  } catch (e) {
    return jsonErr(res, e);
  }
});

/* ============================
   POST /api/admin/orders/:id/refund
============================ */

router.post("/:id/refund", validate(refundSchema), async (req, res) => {
  try {
    const id = String(req.params.id || "");
    if (!isValidObjectId(id)) {
      return safeNotFound(res, "NOT_FOUND", "Order not found");
    }

    const idemKey = pickIdempotencyKey(req);
    const { amount, reason, note } = req.validated.body;

    const order = await Order.findById(id);
    if (!order) {
      return safeNotFound(res, "NOT_FOUND", "Order not found");
    }

    // Check if already fully refunded
    if (order.status === "refunded" || order?.refund?.status === "succeeded") {
      return jsonRes(res, mapOrder(order, { lang: req.lang }));
    }

    const orderTotal = Number(order?.pricing?.total ?? order?.total ?? 0);
    const refundAmount = typeof amount === "number" ? amount : orderTotal;

    if (!Number.isFinite(refundAmount) || refundAmount <= 0) {
      throw makeErr(400, "INVALID_REFUND_AMOUNT", "Refund amount must be > 0");
    }
    if (orderTotal > 0 && refundAmount > orderTotal) {
      throw makeErr(400, "AMOUNT_EXCEEDS_TOTAL", "Refund amount exceeds order total");
    }

    // Handle Stripe refunds
    if (order.paymentMethod === "stripe") {
      const paymentIntentId = String(order?.stripe?.paymentIntentId || "");
      if (!paymentIntentId) {
        throw makeErr(400, "MISSING_PAYMENT_INTENT", "Order has no paymentIntentId");
      }

      // Idempotency guard
      if (idemKey && String(order?.idempotency?.refundKey || "") === idemKey) {
        const fresh = await Order.findById(order._id);
        return jsonRes(res, mapOrder(fresh || order, { lang: req.lang }));
      }

      // Mark pending
      await Order.updateOne(
        { _id: order._id },
        {
          $set: {
            status: "refund_pending",
            "refund.status": "pending",
            "refund.reason": reason || "other",
            "refund.requestedAt": new Date(),
            ...(idemKey ? { "idempotency.refundKey": idemKey } : {}),
            ...(note ? { internalNote: String(note) } : {}),
          },
        }
      );

      try {
        const refund = await createStripeRefund({
          paymentIntentId,
          amountMajor: refundAmount,
          reason: reason || "other",
          idempotencyKey: idemKey || `refund:admin:${String(order._id)}:${paymentIntentId}:${refundAmount}`,
        });

        const isPartial = refundAmount > 0 && orderTotal > 0 && refundAmount < orderTotal;

        const updated = await Order.findByIdAndUpdate(
          order._id,
          {
            $set: {
              status: isPartial ? "partially_refunded" : "refunded",
              "refund.status": "succeeded",
              "refund.amount": refundAmount,
              "refund.currency": "ils",
              "refund.stripeRefundId": String(refund?.id || ""),
              "refund.refundedAt": new Date(),
              ...(note ? { internalNote: String(note) } : {}),
            },
          },
          { new: true }
        );

        return jsonRes(res, mapOrder(updated, { lang: req.lang }));
      } catch (rfErr) {
        const updated = await Order.findByIdAndUpdate(
          order._id,
          {
            $set: {
              status: "refund_pending",
              "refund.status": "failed",
              "refund.failureMessage": String(rfErr?.message || "Refund failed").slice(0, 800),
              ...(note ? { internalNote: String(note) } : {}),
            },
          },
          { new: true }
        );

        return res.status(202).json({
          success: true,
          data: {
            ...mapOrder(updated, { lang: req.lang }),
            warning: "REFUND_PENDING_MANUAL_ACTION",
          },
        });
      }
    } else {
      // COD orders - manual refund marking
      const isPartial = refundAmount > 0 && orderTotal > 0 && refundAmount < orderTotal;

      const updated = await Order.findByIdAndUpdate(
        order._id,
        {
          $set: {
            status: isPartial ? "partially_refunded" : "refunded",
            "refund.status": "succeeded",
            "refund.amount": refundAmount,
            "refund.currency": "ils",
            "refund.reason": reason || "other",
            "refund.refundedAt": new Date(),
            ...(note ? { internalNote: String(note) } : {}),
          },
        },
        { new: true }
      );

      return jsonRes(res, {
        ...mapOrder(updated, { lang: req.lang }),
        manualRefund: true,
      });
    }
  } catch (e) {
    return jsonErr(res, e);
  }
});

/* ============================
   POST /api/admin/orders/:id/issue-invoice
============================ */

router.post("/:id/issue-invoice", validate(invoiceSchema), async (req, res) => {
  try {
    const id = String(req.params.id || "");
    if (!isValidObjectId(id)) {
      return safeNotFound(res, "NOT_FOUND", "Order not found");
    }

    const order = await Order.findById(id);
    if (!order) {
      return safeNotFound(res, "NOT_FOUND", "Order not found");
    }

    // Check if already issued
    if (order?.invoice?.status === "issued") {
      return jsonRes(res, {
        ...mapOrder(order, { lang: req.lang }),
        invoiceAlreadyIssued: true,
      });
    }

    try {
      const invoice = await createInvoiceForOrder(order);

      await Order.updateOne(
        { _id: order._id },
        {
          $set: {
            "invoice.provider": invoice.provider,
            "invoice.docId": invoice.docId || "",
            "invoice.docType": invoice.docType || "",
            "invoice.number": invoice.number || "",
            "invoice.url": invoice.url || "",
            "invoice.issuedAt": invoice.issuedAt || null,
            "invoice.status": invoice.status || "pending",
            "invoice.error": invoice.error || "",
            "invoice.allocation": invoice.allocation || {},
          },
        }
      );

      const updated = await Order.findById(order._id);
      return jsonRes(res, mapOrder(updated, { lang: req.lang }));
    } catch (invoiceErr) {
      const provider = resolveInvoiceProvider(order);

      await Order.updateOne(
        { _id: order._id },
        {
          $set: {
            "invoice.provider": provider,
            "invoice.docId": String(order._id),
            "invoice.number": "",
            "invoice.url": "",
            "invoice.issuedAt": null,
            "invoice.status": "failed",
            "invoice.error": String(invoiceErr?.message || "Invoice failed"),
          },
        }
      );

      const updated = await Order.findById(order._id);
      return res.status(500).json({
        success: false,
        error: {
          code: "INVOICE_FAILED",
          message: String(invoiceErr?.message || "Failed to issue invoice"),
          requestId: getRequestId(req),
          path: req?.originalUrl || req?.url || "",
        },
        data: mapOrder(updated, { lang: req.lang }),
      });
    }
  } catch (e) {
    return jsonErr(res, e);
  }
});

/* ============================
   POST /api/admin/orders/:id/resend-email
   TODO: Implement with actual mailer when available
============================ */

router.post("/:id/resend-email", validate(resendEmailSchema), async (req, res) => {
  try {
    const id = String(req.params.id || "");
    if (!isValidObjectId(id)) {
      return safeNotFound(res, "NOT_FOUND", "Order not found");
    }

    const order = await Order.findById(id);
    if (!order) {
      return safeNotFound(res, "NOT_FOUND", "Order not found");
    }

    const type = req.validated?.body?.type || "confirmation";

    // TODO: Implement actual email sending when mailer service is available
    // For now, return stub response indicating email would be sent

    return jsonRes(res, {
      orderId: order._id,
      emailType: type,
      status: "stub",
      message: "Email sending not implemented. TODO: integrate with mailer service.",
    });
  } catch (e) {
    return jsonErr(res, e);
  }
});

export default router;
