import mongoose from "mongoose";
import { Product } from "../models/Product.js";
import { Variant } from "../models/Variant.js";
import { Category } from "../models/Category.js";
import { parsePagination } from "../utils/paginate.js";
import { applyQueryBudget } from "../utils/queryBudget.js";
import { getCategorySlugCache, setCategorySlugCache } from "../utils/categoryCache.js";
import { toMajorUnits } from "../utils/money.js";

function oid(id) {
  return new mongoose.Types.ObjectId(id);
}

function escapeRegex(input) {
  return String(input).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * ✅ Stock resolver (schema-agnostic)
 * Supports Variant fields:
 * - available (preferred if exists)
 * - stock
 * - stockReserved
 */
function resolveVariantAvailable(v) {
  const reserved = Number(v?.stockReserved ?? 0);

  // Some schemas store "available" directly
  const hasAvailableField = v && Object.prototype.hasOwnProperty.call(v, "available");
  if (hasAvailableField) {
    const a = Number(v.available ?? 0);
    // if schema uses "available" as final available, don't subtract reserved twice
    // but if reserved is tracked separately, subtract defensively:
    return Math.max(0, a - reserved);
  }

  // Classic stock - reserved
  const stock = Number(v?.stock ?? 0);
  return Math.max(0, stock - reserved);
}

export async function createProduct(payload) {
  return Product.create({
    nameHe: payload.nameHe,
    nameAr: payload.nameAr,
    descriptionHe: payload.descriptionHe,
    descriptionAr: payload.descriptionAr,
    brand: payload.brand,
    categoryIds: (payload.categoryIds || []).map(oid),
    images: payload.images || [],
    slug: payload.slug,
    isActive: payload.isActive ?? true,
    attributes: payload.attributes || {},

    // inStock is derived from variants (stock.service recomputes it)
    inStock: false,
    isDeleted: false,
  });
}

export async function updateProduct(productId, patch) {
  const prod = await Product.findOne({ _id: productId, isDeleted: { $ne: true } });
  if (!prod) {
    const err = new Error("PRODUCT_NOT_FOUND");
    err.statusCode = 404;
    throw err;
  }

  const setIf = (k, v) => {
    if (v !== undefined) prod[k] = v;
  };

  setIf("nameHe", patch.nameHe);
  setIf("nameAr", patch.nameAr);
  setIf("descriptionHe", patch.descriptionHe);
  setIf("descriptionAr", patch.descriptionAr);
  setIf("brand", patch.brand);
  setIf("images", patch.images);
  setIf("slug", patch.slug);
  setIf("isActive", patch.isActive);

  if (patch.categoryIds !== undefined) prod.categoryIds = (patch.categoryIds || []).map(oid);
  if (patch.attributes !== undefined) prod.attributes = patch.attributes || {};

  await prod.save();
  return prod;
}

export async function softDeleteProduct(productId) {
  const prod = await Product.findOne({ _id: productId, isDeleted: { $ne: true } });
  if (!prod) {
    const err = new Error("PRODUCT_NOT_FOUND");
    err.statusCode = 404;
    throw err;
  }
  prod.isActive = false;
  prod.isDeleted = true;
  prod.deletedAt = new Date();
  await prod.save();
  return prod;
}

export async function listProductsPublic(query) {
  const { page, limit, skip } = parsePagination(query, { maxLimit: 50, defaultLimit: 20 });

  const onlyActive = query.includeInactive ? false : true;

  const q = {};
  if (onlyActive) q.isActive = true;
  q.isDeleted = { $ne: true };

  // Brand filter (single - backward compat)
  if (query.brand) q.brand = String(query.brand).trim();

  // Brands filter (multi - guide compat)
  if (query.brands && Array.isArray(query.brands) && query.brands.length > 0) {
    const brandList = query.brands.map((b) => String(b).trim()).filter(Boolean);
    if (brandList.length > 0) {
      // Case-insensitive brand match
      const brandRegexes = brandList.map((b) => new RegExp(`^${escapeRegex(b)}$`, "i"));
      q.brand = { $in: brandRegexes };
    }
  }

  let useTextSearch = false;
  if (query.q) {
    const raw = String(query.q).trim().slice(0, 64);
    if (raw.length >= 2) {
      q.$text = { $search: raw };
      useTextSearch = true;
    } else {
      const safe = escapeRegex(raw);
      q.$or = [
        { nameHe: { $regex: safe, $options: "i" } },
        { nameAr: { $regex: safe, $options: "i" } },
        { brand: { $regex: safe, $options: "i" } },
      ];
    }
  }

  // CategoryIds filter (multi - guide compat)
  if (query.categoryIds && Array.isArray(query.categoryIds) && query.categoryIds.length > 0) {
    const validCatIds = query.categoryIds.filter((id) => mongoose.Types.ObjectId.isValid(id));
    if (validCatIds.length > 0) {
      // Find categories and their descendants
      const catOids = validCatIds.map((id) => new mongoose.Types.ObjectId(id));
      const descendantsQuery = Category.find(
        { $or: [{ _id: { $in: catOids } }, { ancestors: { $in: catOids } }], isDeleted: { $ne: true } },
        { _id: 1 },
      ).lean();
      const allCats = await applyQueryBudget(descendantsQuery);
      const allCatIds = allCats.map((c) => c._id);
      if (allCatIds.length > 0) {
        q.categoryIds = { $in: allCatIds };
      }
    }
  }

  if (query.categoryFullSlug) {
    const fullSlug = String(query.categoryFullSlug).trim();
    const cachedIds = getCategorySlugCache(fullSlug);
    if (cachedIds) {
      q.categoryIds = { $in: cachedIds };
    } else {
      const catQuery = Category.findOne(
        { fullSlug, isDeleted: { $ne: true } },
        { _id: 1 },
      ).lean();
      const cat = await applyQueryBudget(catQuery);

      if (cat) {
        const descendantsQuery = Category.find(
          { ancestors: cat._id, isDeleted: { $ne: true } },
          { _id: 1 },
        ).lean();
        const descendants = await applyQueryBudget(descendantsQuery);
        const ids = [cat._id, ...descendants.map((d) => d._id)];
        setCategorySlugCache(fullSlug, ids);
        q.categoryIds = { $in: ids };
      } else {
        return { items: [], page, limit, total: 0 };
      }
    }
  }

  // inStock filter (guide compat)
  if (query.inStock === true) {
    q.inStock = true;
  } else if (query.inStock === false) {
    q.inStock = { $ne: true };
  }

  // Featured filter (guide compat)
  if (query.featured === true) {
    q.isFeatured = true;
  }

  // minRating filter (guide compat)
  if (typeof query.minRating === "number" && query.minRating > 0) {
    q.ratingAvg = { $gte: query.minRating };
  }

  const projection = {
    nameHe: 1,
    nameAr: 1,
    descriptionHe: 1,
    descriptionAr: 1,
    brand: 1,
    categoryIds: 1,
    images: 1,
    slug: 1,
    isActive: 1,

    // ✅ IMPORTANT: include product-level inStock
    inStock: 1,
    reviewsCount: 1,
    ratingAvg: 1,

    createdAt: 1,
    updatedAt: 1,
  };

  if (useTextSearch) {
    projection.score = { $meta: "textScore" };
  }

  // Map guide sort values to internal sort values
  const sortKey = String(query.sort || "new");
  const sortMap = {
    newest: "new",
    bestselling: "popular",
    price_asc: "price_asc",
    price_desc: "price_desc",
    rating_desc: "rating_desc",
    name_asc: "name_asc",
    new: "new",
    popular: "popular",
  };
  const normalizedSort = sortMap[sortKey] || "new";

  const total = await applyQueryBudget(Product.countDocuments(q));

  // Build sort object based on sort key
  // Always add _id as secondary sort for stability
  let sort;
  if (useTextSearch) {
    switch (normalizedSort) {
      case "popular":
        sort = { score: { $meta: "textScore" }, reviewsCount: -1, ratingAvg: -1, createdAt: -1, _id: 1 };
        break;
      case "rating_desc":
        sort = { score: { $meta: "textScore" }, ratingAvg: -1, reviewsCount: -1, _id: 1 };
        break;
      case "name_asc":
        sort = { score: { $meta: "textScore" }, nameHe: 1, _id: 1 };
        break;
      case "price_asc":
      case "price_desc":
        // Price sorting handled post-fetch due to variant-based pricing
        sort = { score: { $meta: "textScore" }, createdAt: -1, _id: 1 };
        break;
      default: // new/newest
        sort = { score: { $meta: "textScore" }, createdAt: -1, _id: 1 };
    }
  } else {
    switch (normalizedSort) {
      case "popular":
        sort = { reviewsCount: -1, ratingAvg: -1, createdAt: -1, _id: 1 };
        break;
      case "rating_desc":
        sort = { ratingAvg: -1, reviewsCount: -1, _id: 1 };
        break;
      case "name_asc":
        sort = { nameHe: 1, _id: 1 };
        break;
      case "price_asc":
      case "price_desc":
        // Price sorting handled post-fetch due to variant-based pricing
        sort = { createdAt: -1, _id: 1 };
        break;
      default: // new/newest
        sort = { createdAt: -1, _id: 1 };
    }
  }

  const itemsQuery = Product.find(q, projection).sort(sort).skip(skip).limit(limit).lean();
  const items = await applyQueryBudget(itemsQuery);

  // Variant summary: min price + inStock per product
  const ids = items.map((p) => p._id);

  const variants = ids.length
    ? await applyQueryBudget(
        Variant.find({ productId: { $in: ids }, isActive: true, isDeleted: { $ne: true } })
          .select("productId price compareAtPrice currency available stock stockReserved")
          .lean(),
      )
    : [];

  /**
   * pid -> { minPrice, maxPrice, currency, anyVariantAvailable, hasDiscount }
   * Note: product-level inStock will be applied later as a gate.
   */
  const variantSummary = new Map();
  for (const v of variants) {
    const pid = String(v.productId);
    const available = resolveVariantAvailable(v);
    const price = Number(v.price ?? 0);
    const compareAtPrice = Number(v.compareAtPrice ?? 0);

    const entry =
      variantSummary.get(pid) || {
        minPrice: null,
        maxPrice: null,
        currency: v.currency || "₪",
        anyVariantAvailable: false,
        hasDiscount: false,
      };

    if (entry.minPrice === null || price < entry.minPrice) {
      entry.minPrice = price;
    }
    if (entry.maxPrice === null || price > entry.maxPrice) {
      entry.maxPrice = price;
    }

    if (available > 0) entry.anyVariantAvailable = true;

    // Check for discount (compareAtPrice > price means item is on sale)
    if (compareAtPrice > price) {
      entry.hasDiscount = true;
    }

    if (!entry.currency) entry.currency = v.currency || "₪";

    variantSummary.set(pid, entry);
  }

  let out = items.map((p) => {
    const pid = String(p._id);

    const s = variantSummary.get(pid) || {
      minPrice: null,
      maxPrice: null,
      currency: "₪",
      anyVariantAvailable: false,
      hasDiscount: false,
    };

    const r = {
      reviewsCount: p.reviewsCount || 0,
      ratingAvg: p.ratingAvg ?? null,
    };

    // ✅ FINAL inStock:
    // product-level inStock gates availability. If product.inStock=false => false no matter what variants say.
    // If product.inStock=true/undefined => depends on variants availability
    const finalInStock = typeof p.inStock === "boolean" ? p.inStock : s.anyVariantAvailable;
    const priceFrom = s.minPrice === null ? null : toMajorUnits(s.minPrice, s.currency);

    return {
      ...p,
      priceFrom,
      priceFromMinor: s.minPrice, // Keep minor for filtering
      currency: s.currency,
      inStock: finalInStock,
      hasDiscount: s.hasDiscount,

      reviewsCount: r.reviewsCount || 0,
      ratingAvg: r.ratingAvg === null || r.ratingAvg === undefined ? null : Number(Number(r.ratingAvg).toFixed(2)),
    };
  });

  // Apply price filtering (guide compat - minPrice/maxPrice in minor units)
  if (typeof query.minPrice === "number") {
    out = out.filter((p) => p.priceFromMinor !== null && p.priceFromMinor >= query.minPrice);
  }
  if (typeof query.maxPrice === "number") {
    out = out.filter((p) => p.priceFromMinor !== null && p.priceFromMinor <= query.maxPrice);
  }

  // Apply onSale filter (guide compat)
  if (query.onSale === true) {
    out = out.filter((p) => p.hasDiscount === true);
  }

  // Apply price-based sorting post-fetch (since prices come from variants)
  if (normalizedSort === "price_asc") {
    out.sort((a, b) => {
      const priceA = a.priceFromMinor ?? Number.MAX_SAFE_INTEGER;
      const priceB = b.priceFromMinor ?? Number.MAX_SAFE_INTEGER;
      if (priceA !== priceB) return priceA - priceB;
      return String(a._id).localeCompare(String(b._id));
    });
  } else if (normalizedSort === "price_desc") {
    out.sort((a, b) => {
      const priceA = a.priceFromMinor ?? 0;
      const priceB = b.priceFromMinor ?? 0;
      if (priceA !== priceB) return priceB - priceA;
      return String(a._id).localeCompare(String(b._id));
    });
  }

  // Remove priceFromMinor and hasDiscount from response (internal use only)
  const finalOut = out.map(({ priceFromMinor, hasDiscount, ...rest }) => rest);

  return { items: finalOut, page, limit, total };
}

export async function getProductPublic(productId) {
  const prodQuery = Product.findOne({ _id: productId, isDeleted: { $ne: true } }).lean();
  const prod = await applyQueryBudget(prodQuery);
  if (!prod || !prod.isActive) {
    const err = new Error("PRODUCT_NOT_FOUND");
    err.statusCode = 404;
    throw err;
  }

  const variantsQuery = Variant.find({
    productId: prod._id,
    isActive: true,
    isDeleted: { $ne: true },
  })
    .sort({ sortOrder: 1, createdAt: 1 })
    .lean();
  const variants = await applyQueryBudget(variantsQuery);

  return { product: prod, variants };
}
