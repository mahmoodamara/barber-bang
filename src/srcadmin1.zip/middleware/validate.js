// src/middleware/validate.js

/**
 * Zod validation middleware.
 * Strips the "lang" query parameter globally before parsing to allow i18n
 * while keeping schemas strict.
 */
export function validate(schema) {
  return (req, _res, next) => {
    // Strip "lang" from query before validation to support i18n with strict schemas
    const queryWithoutLang = { ...req.query };
    delete queryWithoutLang.lang;

    const result = schema.safeParse({
      body: req.body,
      query: queryWithoutLang,
      params: req.params,
    });

    if (!result.success) {
      // ✅ forward ZodError to central errorHandler
      // so we always get:
      // { ok:false, success:false, error:{ code,message,requestId,path,details } }
      return next(result.error);
    }

    req.validated = result.data;
    return next();
  };
}
