// src/models/CouponReservation.js
/**
 * ✅ DELIVERABLE #2: Coupon Reservation Collection
 *
 * Replaces Coupon.reservedByOrders array to avoid 16MB document limit.
 * TTL indexed for automatic cleanup of expired reservations.
 */
import mongoose from "mongoose";

const couponReservationSchema = new mongoose.Schema(
  {
    couponId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Coupon",
      required: true,
      index: true,
    },
    orderId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Order",
      required: true,
      index: true,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    couponCode: {
      type: String,
      required: true,
      uppercase: true,
      trim: true,
    },
    expiresAt: {
      type: Date,
      required: true,
      index: true,
    },
    status: {
      type: String,
      enum: ["active", "consumed", "released", "expired"],
      default: "active",
    },
  },
  {
    timestamps: true,
  }
);

// ✅ Unique compound index: one reservation per coupon+order
couponReservationSchema.index({ couponId: 1, orderId: 1 }, { unique: true });

// ✅ Index for finding active reservations per coupon
couponReservationSchema.index({ couponId: 1, status: 1, expiresAt: 1 });

// ✅ Index for looking up by coupon code (normalized queries)
couponReservationSchema.index({ couponCode: 1, orderId: 1 });

// ✅ TTL index: MongoDB auto-deletes documents 0 seconds after expiresAt
// Note: Only removes if status is not 'consumed' (handled in application logic)
couponReservationSchema.index(
  { expiresAt: 1 },
  {
    expireAfterSeconds: 0,
    partialFilterExpression: { status: { $in: ["active", "expired"] } },
  }
);

export const CouponReservation = mongoose.model("CouponReservation", couponReservationSchema);
