﻿// src/scripts/seed.js
// سكريبت بذور البيانات لمتجر حلاقة الرجال - ثنائي اللغة (عبرية/عربية)
// منتجات واقعية من سوق الحلاقة الرجالية

import "dotenv/config";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import { connectDB } from "../config/db.js";

import { User } from "../models/User.js";
import { Category } from "../models/Category.js";
import { Product } from "../models/Product.js";
import { DeliveryArea } from "../models/DeliveryArea.js";
import { PickupPoint } from "../models/PickupPoint.js";
import { StorePickupConfig } from "../models/StorePickupConfig.js";
import { Coupon } from "../models/Coupon.js";
import { Campaign } from "../models/Campaign.js";
import { Gift } from "../models/Gift.js";
import { Offer } from "../models/Offer.js";
import { ContentPage } from "../models/ContentPage.js";
import { Review } from "../models/Review.js";
import { ProductAttribute } from "../models/ProductAttribute.js";

/* =========================
   دوال مساعدة
========================= */

function nowPlusDays(days) {
  const d = new Date();
  d.setDate(d.getDate() + Number(days || 0));
  return d;
}

async function upsertByFilter(Model, filter, doc) {
  const setDoc = { ...doc };
  delete setDoc.createdAt;
  setDoc.updatedAt = new Date();

  return Model.findOneAndUpdate(
    filter,
    { $set: setDoc, $setOnInsert: { createdAt: doc.createdAt || new Date() } },
    { upsert: true, new: true }
  );
}

function roundMoney(n) {
  return Math.round((Number(n || 0) + Number.EPSILON) * 100) / 100;
}

function toMinorSafe(major) {
  const n = Number(major || 0);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.round((n + Number.EPSILON) * 100));
}

function normalizeKey(raw) {
  const v = String(raw || "").trim().toLowerCase();
  if (!v) return "";
  return v
    .replace(/\s+/g, "_")
    .replace(/[^a-z0-9_]/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function toSlugFromSku(sku) {
  const v = String(sku || "").trim().toLowerCase();
  if (!v) return "";
  return v.replace(/[^a-z0-9]+/g, "-").replace(/-+/g, "-").replace(/^-+|-+$/g, "");
}

function deriveSalePriceFromDiscount(price, discountPercent) {
  const p = Number(price || 0);
  const pct = Number(discountPercent || 0);
  if (!(p > 0)) return null;
  if (!(pct > 0 && pct < 100)) return null;

  const sale = roundMoney(p * (1 - pct / 100));
  if (!(sale < p)) return null;
  return sale;
}

function computeVariantKeyFromAttributes(attrs) {
  const list = Array.isArray(attrs) ? attrs : [];
  const normalized = list
    .map((a) => ({
      key: normalizeKey(a?.key),
      val: normalizeKey(a?.valueKey) || String(a?.value ?? "").trim(),
    }))
    .filter((x) => x.key && x.val);

  normalized.sort((a, b) =>
    (a.key + ":" + a.val).localeCompare(b.key + ":" + b.val)
  );
  return normalized.map((x) => `${x.key}:${x.val}`).join("|");
}

function normalizeProductDoc(p) {
  const doc = { ...p };

  doc.title = doc.titleHe || doc.title || "";
  doc.description = doc.descriptionHe || doc.description || "";
  doc.slug = doc.slug || toSlugFromSku(doc.sku);

  doc.isActive = doc.isActive ?? true;
  doc.isFeatured = Boolean(doc.isFeatured);
  doc.isBestSeller = Boolean(doc.isBestSeller);

  if (doc.salePrice == null && doc.discountPercent != null) {
    const derived = deriveSalePriceFromDiscount(doc.price, doc.discountPercent);
    if (derived != null) doc.salePrice = derived;
  }

  if (doc.salePrice != null) {
    const sp = Number(doc.salePrice);
    const pr = Number(doc.price);
    if (!(sp < pr)) doc.salePrice = null;
  }

  doc.priceMinor = toMinorSafe(doc.price);
  doc.salePriceMinor = doc.salePrice != null ? toMinorSafe(doc.salePrice) : null;

  if (doc.salePrice === undefined) delete doc.salePrice;
  if (doc.discountPercent === undefined) delete doc.discountPercent;

  if (doc.saleStartAt === undefined || doc.saleStartAt === null) delete doc.saleStartAt;
  if (doc.saleEndAt === undefined || doc.saleEndAt === null) delete doc.saleEndAt;

  doc.tags = Array.isArray(doc.tags) ? doc.tags.filter(Boolean).map(String) : [];

  if (Array.isArray(doc.variants) && doc.variants.length > 0) {
    doc.variants = doc.variants.map((v) => {
      const attrs = Array.isArray(v?.attributes) ? v.attributes : [];
      const variantKey = v.variantKey || computeVariantKeyFromAttributes(attrs);

      const priceOverride =
        v.priceOverride != null && Number.isFinite(Number(v.priceOverride))
          ? Number(v.priceOverride)
          : null;

      const priceOverrideMinor = priceOverride != null ? toMinorSafe(priceOverride) : null;

      return {
        ...v,
        variantKey,
        priceOverride,
        priceOverrideMinor,
        stock: Number.isFinite(Number(v.stock)) ? Number(v.stock) : 0,
        attributes: attrs
          .map((a) => ({
            key: normalizeKey(a?.key),
            type: String(a?.type || "text"),
            value: a?.value ?? null,
            valueKey: normalizeKey(a?.valueKey) || "",
            unit: String(a?.unit || ""),
          }))
          .filter((a) => a.key && a.type),
      };
    });
  } else {
    doc.variants = [];
  }

  // ✅ If product has variants, derive base stock from variants to avoid "out of stock" UI bugs
  if (Array.isArray(doc.variants) && doc.variants.length > 0) {
    const sum = doc.variants.reduce((acc, v) => acc + (Number.isFinite(Number(v?.stock)) ? Number(v.stock) : 0), 0);
    doc.stock = sum;
  } else {
    doc.stock = Number.isFinite(Number(doc.stock)) ? Number(doc.stock) : 0;
  }

  return doc;
}

/* =========================
   دالة حذف البيانات السابقة
========================= */

async function clearExistingData() {
  console.log("🚮 بدء عملية تنظيف البيانات...");

  try {
    const deletionOrder = [
      { model: Review, name: "التقييمات" },
      { model: Product, name: "المنتجات" },
      { model: Category, name: "الفئات" },
      { model: ProductAttribute, name: "سمات المنتج" },
      { model: DeliveryArea, name: "مناطق التوصيل" },
      { model: PickupPoint, name: "نقاط الاستلام" },
      { model: StorePickupConfig, name: "إعدادات الاستلام من المتجر" },
      { model: Coupon, name: "الكوبونات" },
      { model: Campaign, name: "الحملات" },
      { model: Gift, name: "الهدايا" },
      { model: Offer, name: "العروض" },
      { model: ContentPage, name: "صفحات المحتوى" },
      {
        model: User,
        name: "المستخدمين",
        filter: {
          email: {
            $nin: [
              process.env.SEED_ADMIN_EMAIL || "admin@shop.local",
              process.env.SEED_TEST_EMAIL || "test@shop.local",
            ],
          },
        },
      },
    ];

    let totalDeleted = 0;

    for (const { model, name, filter = {} } of deletionOrder) {
      try {
        const result = await model.deleteMany(filter);
        console.log(`✅ تم حذف ${result.deletedCount} ${name}`);
        totalDeleted += result.deletedCount;
      } catch (error) {
        console.warn(`⚠️  تحذير عند حذف ${name}:`, error.message);
      }
    }

    console.log(`📊 إجمالي الوثائق المحذوفة: ${totalDeleted}`);
    console.log("✅ اكتملت عملية تنظيف البيانات بنجاح");
    return totalDeleted;
  } catch (error) {
    console.error("❌ خطأ أثناء تنظيف البيانات:", error);
    throw error;
  }
}

/* =========================
   الدالة الرئيسية
========================= */

async function main() {
  await connectDB();
  mongoose.set("strictQuery", true);

  const cleanupOption = process.env.SEED_CLEANUP || "smart";

  if (cleanupOption === "all") {
    console.log("🔥 بدء عملية حذف جميع البيانات...");
    await mongoose.connection.dropDatabase();
    console.log("✅ تم حذف قاعدة البيانات بالكامل");
  } else if (cleanupOption === "smart") {
    await clearExistingData();
  } else {
    console.log("⏭️  تخطي عملية تنظيف البيانات");
  }

  /* -------------------------
     1) المستخدمون الإداريون ومستخدم الاختبار
  ------------------------- */
  const adminEmail = process.env.SEED_ADMIN_EMAIL || "admin@shop.local";
  const adminPass = process.env.SEED_ADMIN_PASSWORD || "Admin123!";
  const adminNameHe = "אדמין ראשי";
  const adminNameAr = "المشرف الرئيسي";

  const testEmail = process.env.SEED_TEST_EMAIL || "test@shop.local";
  const testPass = process.env.SEED_TEST_PASSWORD || "Test123!";
  const testNameHe = "משתמש בדיקה";
  const testNameAr = "مستخدم تجريبي";

  const [adminHash, testHash] = await Promise.all([
    bcrypt.hash(adminPass, 10),
    bcrypt.hash(testPass, 10),
  ]);

  const adminUser = await upsertByFilter(
    User,
    { email: adminEmail },
    {
      name: adminNameHe,
      nameHe: adminNameHe,
      nameAr: adminNameAr,
      email: adminEmail,
      passwordHash: adminHash,
      role: "admin",
      phone: "+972501234567",
      address: {
        streetHe: "רחוב הארבעה 12, תל אביב",
        streetAr: "شارع الأربعة 12، تل أبيب",
        cityHe: "תל אביב",
        cityAr: "تل أبيب",
        zipCode: "12345",
      },
      createdAt: new Date(),
      updatedAt: new Date(),
    }
  );

  const testUser = await upsertByFilter(
    User,
    { email: testEmail },
    {
      name: testNameHe,
      nameHe: testNameHe,
      nameAr: testNameAr,
      email: testEmail,
      passwordHash: testHash,
      role: "user",
      phone: "+972501234568",
      cart: [],
      wishlist: [],
      address: {
        streetHe: "דרך השלום 34, ירושלים",
        streetAr: "طريق السلام 34، القدس",
        cityHe: "ירושלים",
        cityAr: "القدس",
        zipCode: "54321",
      },
      createdAt: new Date(),
      updatedAt: new Date(),
    }
  );

  console.log(`👤 المستخدم الإداري: ${adminEmail}`);
  console.log(`👤 مستخدم الاختبار: ${testEmail}`);

  /* -------------------------
     2) كتالوج سمات المنتج
     ✅ تمت إضافة سمات ناقصة: color, pack_count, finish_type
     ✅ تعديل size ليشمل 30ml
  ------------------------- */
  console.log("📝 إضافة سمات المنتج...");

  const attrDocs = [
    {
      key: "volume_ml",
      nameHe: "נפח (מ״ל)",
      nameAr: "الحجم (مل)",
      type: "number",
      unit: "ml",
      options: [],
      isActive: true,
    },
    {
      key: "weight_g",
      nameHe: "משקל (גרם)",
      nameAr: "الوزن (غرام)",
      type: "number",
      unit: "g",
      options: [],
      isActive: true,
    },
    {
      key: "blade_size",
      nameHe: "גודל להב",
      nameAr: "حجم الشفرة",
      type: "enum",
      unit: "",
      options: [
        { valueKey: "small", labelHe: "קטן", labelAr: "صغير", isActive: true },
        { valueKey: "medium", labelHe: "בינוני", labelAr: "وسط", isActive: true },
        { valueKey: "large", labelHe: "גדול", labelAr: "كبير", isActive: true },
      ],
      isActive: true,
    },
    {
      key: "scent",
      nameHe: "ריח",
      nameAr: "العطر",
      type: "text",
      unit: "",
      options: [],
      isActive: true,
    },
    {
      key: "hold_level",
      nameHe: "רמת אחיזה",
      nameAr: "مستوى التثبيت",
      type: "enum",
      unit: "",
      options: [
        { valueKey: "low", labelHe: "חלשה", labelAr: "ضعيف", isActive: true },
        { valueKey: "medium", labelHe: "בינונית", labelAr: "متوسط", isActive: true },
        { valueKey: "strong", labelHe: "חזקה", labelAr: "قوي", isActive: true },
        { valueKey: "extra_strong", labelHe: "חזקה מאוד", labelAr: "قوي جداً", isActive: true },
      ],
      isActive: true,
    },
    {
      key: "skin_type",
      nameHe: "סוג עור",
      nameAr: "نوع البشرة",
      type: "enum",
      unit: "",
      options: [
        { valueKey: "sensitive", labelHe: "רגיש", labelAr: "حساس", isActive: true },
        { valueKey: "normal", labelHe: "רגיל", labelAr: "عادي", isActive: true },
        { valueKey: "oily", labelHe: "שמנוני", labelAr: "دهني", isActive: true },
        { valueKey: "dry", labelHe: "יבש", labelAr: "جاف", isActive: true },
      ],
      isActive: true,
    },
    {
      key: "size",
      nameHe: "גודל",
      nameAr: "الحجم",
      type: "enum",
      unit: "",
      options: [
        { valueKey: "30ml", labelHe: "30 מ״ל", labelAr: "30 مل", isActive: true },
        { valueKey: "50ml", labelHe: "50 מ״ל", labelAr: "50 مل", isActive: true },
        { valueKey: "100ml", labelHe: "100 מ״ל", labelAr: "100 مل", isActive: true },
        { valueKey: "150ml", labelHe: "150 מ״ל", labelAr: "150 مل", isActive: true },
        { valueKey: "200ml", labelHe: "200 מ״ל", labelAr: "200 مل", isActive: true },
      ],
      isActive: true,
    },
    {
      key: "power_source",
      nameHe: "מקור כוח",
      nameAr: "مصدر الطاقة",
      type: "enum",
      unit: "",
      options: [
        { valueKey: "corded", labelHe: "חשמלי", labelAr: "كهربائي", isActive: true },
        { valueKey: "cordless", labelHe: "סוללה", labelAr: "بطارية", isActive: true },
        { valueKey: "both", labelHe: "שניהם", labelAr: "كلاهما", isActive: true },
      ],
      isActive: true,
    },

    // ✅ إضافات منطقية لتوافق الـ Variants الموجودة بالمنتجات
    {
      key: "color",
      nameHe: "צבע",
      nameAr: "اللون",
      type: "text",
      unit: "",
      options: [],
      isActive: true,
    },
    {
      key: "pack_count",
      nameHe: "כמות בחבילה",
      nameAr: "عدد القطع في العبوة",
      type: "number",
      unit: "pcs",
      options: [],
      isActive: true,
    },
    {
      key: "finish_type",
      nameHe: "סוג גימור",
      nameAr: "نوع اللمعة",
      type: "text",
      unit: "",
      options: [],
      isActive: true,
    },
  ];

  const attributes = [];
  for (const a of attrDocs) {
    const attr = await upsertByFilter(
      ProductAttribute,
      { key: normalizeKey(a.key) },
      {
        key: normalizeKey(a.key),
        nameHe: a.nameHe,
        nameAr: a.nameAr,
        name: a.nameHe,
        type: a.type,
        unit: a.unit || "",
        options: Array.isArray(a.options)
          ? a.options.map((o) => ({
              valueKey: normalizeKey(o.valueKey),
              labelHe: o.labelHe,
              labelAr: o.labelAr,
              isActive: o.isActive ?? true,
            }))
          : [],
        isActive: a.isActive ?? true,
        createdAt: new Date(),
        updatedAt: new Date(),
      }
    );
    attributes.push(attr);
  }

  console.log(`✅ تم إضافة ${attributes.length} سمة منتج`);

  /* -------------------------
     3) الفئات (ثنائية اللغة)
     ✅ Fix قوي لمشكلة HAIR_CARE vs hair-care
  ------------------------- */
  console.log("📝 إضافة الفئات...");

  const categoryImages = {
    clippers:
      "https://images.unsplash.com/photo-1622287162716-f311baa1a2b8?auto=format&fit=crop&w=800&h=600&q=80",
    trimmers:
      "https://images.unsplash.com/photo-1595476108010-b4d1f102b1b1?auto=format&fit=crop&w=800&h=600&q=80",
    shaving:
      "https://images.unsplash.com/photo-1607452231257-77686cd90c9e?auto=format&fit=crop&w=800&h=600&q=80",
    hairCare:
      "https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=800&h=600&q=80",
    beardCare:
      "https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&w=800&h=600&q=80",
    accessories:
      "https://images.unsplash.com/photo-1621604048412-5b2e0c5e8d27?auto=format&fit=crop&w=800&h=600&q=80",
    skincare:
      "https://images.unsplash.com/photo-1556228578-9c360e1d458d?auto=format&fit=crop&w=800&h=600&q=80",
  };

  const categoryDocs = [
    {
      key: "CLIPPERS",
      nameHe: "מכונות תספורת",
      nameAr: "ماكينات قص الشعر",
      descriptionHe: "מכונות תספורת מקצועיות לבית ולסלון",
      descriptionAr: "ماكينات قص شعر احترافية للمنزل والصالون",
      slug: "clippers",
      imageUrl: categoryImages.clippers,
      isFeatured: true,
    },
    {
      key: "TRIMMERS",
      nameHe: "טרימרים",
      nameAr: "ماكينات تهذيب",
      descriptionHe: "טרימרים לקווים מדויקים ועיצוב זקן",
      descriptionAr: "ماكينات تهذيب لخطوط دقيقة وتشكيل اللحية",
      slug: "trimmers",
      imageUrl: categoryImages.trimmers,
      isFeatured: true,
    },
    {
      key: "SHAVING",
      nameHe: "גילוח",
      nameAr: "الحلاقة",
      descriptionHe: "סכיני גילוח, קצף וג'לים לגילוח חלק",
      descriptionAr: "شفرات حلاقة، رغوة وجل للحلاقة الناعمة",
      slug: "shaving",
      imageUrl: categoryImages.shaving,
      isFeatured: false,
    },
    {
      key: "HAIR_CARE",
      nameHe: "טיפוח שיער",
      nameAr: "عناية بالشعر",
      descriptionHe: "שמפו, מרכך ומוצרי עיצוב לשיער",
      descriptionAr: "شامبو، بلسم ومنتجات تصفيف للشعر",
      slug: "hair-care",
      imageUrl: categoryImages.hairCare,
      isFeatured: false,
    },
    {
      key: "BEARD_CARE",
      nameHe: "טיפוח זקן",
      nameAr: "عناية باللحية",
      descriptionHe: "שמני זקן, מסרקים ומוצרים לטיפוח זקן",
      descriptionAr: "زيوت اللحية، أمشاط ومنتجات العناية باللحية",
      slug: "beard-care",
      imageUrl: categoryImages.beardCare,
      isFeatured: true,
    },
    {
      key: "ACCESSORIES",
      nameHe: "אביזרים",
      nameAr: "إكسسوارات",
      descriptionHe: "אביזרי עזר לחיתוך, טיפוח וניקוי",
      descriptionAr: "إكسسوارات مساعدة للقص، العناية والتنظيف",
      slug: "accessories",
      imageUrl: categoryImages.accessories,
      isFeatured: false,
    },
    {
      key: "SKINCARE",
      nameHe: "טיפוח עור",
      nameAr: "عناية بالبشرة",
      descriptionHe: "קרמים, סרומים ומוצרים לטיפוח עור הגבר",
      descriptionAr: "كريمات، سيروم ومنتجات لعناية بشرة الرجل",
      slug: "skincare",
      imageUrl: categoryImages.skincare,
      isFeatured: false,
    },
  ];

  const categories = [];
  for (const c of categoryDocs) {
    const payload = {
      nameHe: c.nameHe,
      nameAr: c.nameAr,
      name: c.nameHe,
      descriptionHe: c.descriptionHe,
      descriptionAr: c.descriptionAr,
      description: c.descriptionHe,
      slug: c.slug,
      imageUrl: c.imageUrl || "",
      isActive: true,
      isFeatured: c.isFeatured || false,
      metaTitleHe: c.nameHe,
      metaTitleAr: c.nameAr,
      metaDescriptionHe: c.descriptionHe,
      metaDescriptionAr: c.descriptionAr,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const saved = await upsertByFilter(Category, { slug: c.slug }, payload);
    categories.push(saved);
  }

  // ✅ FIX: normalize keys بحيث hair-care == HAIR_CARE
  const normCatKey = (s) =>
    String(s || "")
      .trim()
      .toUpperCase()
      .replace(/[-\s]+/g, "_");

  const catByKey = new Map();
  for (let i = 0; i < categoryDocs.length; i++) {
    const doc = categoryDocs[i];
    const saved = categories[i];

    // اربط key و slug
    catByKey.set(normCatKey(doc.key), saved);
    catByKey.set(normCatKey(doc.slug), saved);
  }

  const getCatId = (key) => {
    const c = catByKey.get(normCatKey(key));
    if (!c?._id) throw new Error(`[seed] فئة مفقودة للمفتاح=${key}`);
    return c._id;
  };

  console.log(`✅ تم إضافة ${categories.length} فئة`);

  /* -------------------------
     4) المنتجات (ثنائية اللغة + متوافقة + متغيرات)
  ------------------------- */
  console.log("📝 إضافة المنتجات...");

  const img = {
    // ماكينات قص الشعر
    wahlMagic:
      "https://images.unsplash.com/photo-1622287162716-f311baa1a2b8?auto=format&fit=crop&w=800&h=800&q=80",
    andisMaster:
      "https://images.unsplash.com/photo-1585747860715-2ba37e788b70?auto=format&fit=crop&w=800&h=800&q=80",
    osterFastFeed:
      "https://images.unsplash.com/photo-1562243061-2046c8bb60e7?auto=format&fit=crop&w=800&h=800&q=80",

    // ماكينات تهذيب
    babylissSkeleton:
      "https://images.unsplash.com/photo-1595476108010-b4d1f102b1b1?auto=format&fit=crop&w=800&h=800&q=80",
    philipsMultigroom:
      "https://images.unsplash.com/photo-1515377905703-c4788e51af15?auto=format&fit=crop&w=800&h=800&q=80",
    wahlDetailer:
      "https://images.unsplash.com/photo-1562243061-2046c8bb60e7?auto=format&fit=crop&w=800&h=800&q=80",

    // حلاقة
    gilletteFusion:
      "https://images.unsplash.com/photo-1607452231257-77686cd90c9e?auto=format&fit=crop&w=800&h=800&q=80",
    harrysRazor:
      "https://images.unsplash.com/photo-1600033823210-0ff56e5e9c09?auto=format&fit=crop&w=800&h=800&q=80",
    shavingCream:
      "https://images.unsplash.com/photo-1604336737429-4897e55e76b3?auto=format&fit=crop&w=800&h=800&q=80",

    // عناية بالشعر
    hairWax:
      "https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=800&h=800&q=80",
    pomade:
      "https://images.unsplash.com/photo-1621607512214-68297480165e?auto=format&fit=crop&w=800&h=800&q=80",
    hairSpray:
      "https://images.unsplash.com/photo-1591084728795-1149f32d9866?auto=format&fit=crop&w=800&h=800&q=80",

    // عناية باللحية
    beardOil:
      "https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&w=800&h=800&q=80",
    beardComb:
      "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=800&h=800&q=80",
    beardBrush:
      "https://images.unsplash.com/photo-1621604048412-5b2e0c5e8d27?auto=format&fit=crop&w=800&h=800&q=80",

    // إكسسوارات
    barberScissors:
      "https://images.unsplash.com/photo-1631085216051-b6e2783d7077?auto=format&fit=crop&w=800&h=800&q=80",
    barberCape:
      "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=800&h=800&q=80",
    cleaningBrush:
      "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=800&h=800&q=80",

    // عناية بالبشرة
    aftershave:
      "https://images.unsplash.com/photo-1556228578-9c360e1d458d?auto=format&fit=crop&w=800&h=800&q=80",
    faceCream:
      "https://images.unsplash.com/photo-1571875257727-256c39da42af?auto=format&fit=crop&w=800&h=800&q=80",
    faceWash:
      "https://images.unsplash.com/photo-1556228578-9c360e1d458d?auto=format&fit=crop&w=800&h=800&q=80",
  };

  const baseCompliance = {
    brand: "BarberPro",
    sku: "",
    barcode: "",
    sizeLabel: "",
    unit: null,
    netQuantity: null,
    tags: ["حلاقة", "رجالي", "عناية"],
    ingredients: "—",
    usage: "—",
    warnings: "—",
    manufacturerName: "BarberPro LTD",
    importerName: "BarberPro Import",
    countryOfOrigin: "Various",
    warrantyInfo: "ضمان سنة واحدة من تاريخ الشراء",
  };

  const productDocs = [
    // ========== ماكينات قص الشعر ==========
    {
      titleHe: "WAHL Magic Clip - מכונת תספורת אלחוטית",
      titleAr: "WAHL Magic Clip - ماكينة قص شعر لاسلكية",
      descriptionHe: `מכונת התספורת האלחוטית WAHL Magic Clip היא כלי חיוני לכל ספר מקצועי ולכל מי שרוצה להשיג תוצאות מושלמות בבית.
      עם זמן עבודה של עד 120 דקות מטען אחד, היא מושלמת ליום עבודה שלם.
      הלהבים המותאמים אישית מאפשרים חיתוך מדויק ונוח.`,
      descriptionAr: `ماكينة قص الشعر اللاسلكية WAHL Magic Clip هي أداة أساسية لكل حلاق محترف وأي شخص يريد تحقيق نتائج مثالية في المنزل.
      مع وقت عمل يصل إلى 120 دقيقة بشحنة واحدة، إنها مثالية ليوم عمل كامل.
      الشفرات القابلة للتعديل تتيح قصاً دقيقاً ومريحاً.`,
      price: 549,
      stock: 25,
      categoryId: getCatId("CLIPPERS"),
      imageUrl: img.wahlMagic,
      discountPercent: 15,
      saleStartAt: new Date(),
      saleEndAt: nowPlusDays(30),
      isFeatured: true,
      isBestSeller: true,
      isNew: true,

      ...baseCompliance,
      sku: "BP-WAHL-MAGIC-CLIP",
      barcode: "729001000001",
      sizeLabel: "لاسلكي",
      unit: "pcs",
      netQuantity: 1,
      tags: [...baseCompliance.tags, "wahl", "لاسلكي", "احترافي"],
      ingredients: "بلاستيك عالي الجودة، فولاذ لا يصدأ",
      usage: "استخدم على شعر جاف. نظف الشفرات بعد كل استخدام",
      warnings: "بعيداً عن متناول الأطفال. لا تستخدم على شعر مبلل",

      variants: [
        {
          sku: "BP-WAHL-MAGIC-CLIP-BLK",
          barcode: "729001000011",
          stock: 15,
          priceOverride: null,
          attributes: [
            { key: "power_source", type: "enum", value: null, valueKey: "cordless", unit: "" },
            { key: "color", type: "text", value: "أسود", valueKey: "", unit: "" },
          ],
        },
        {
          sku: "BP-WAHL-MAGIC-CLIP-SLV",
          barcode: "729001000012",
          stock: 10,
          priceOverride: null,
          attributes: [
            { key: "power_source", type: "enum", value: null, valueKey: "cordless", unit: "" },
            { key: "color", type: "text", value: "فضي", valueKey: "", unit: "" },
          ],
        },
      ],
    },

    {
      titleHe: "Andis Master - מכונת תספורת מקצועית",
      titleAr: "Andis Master - ماكينة قص شعر احترافية",
      descriptionHe: `מכונת התספורת Andis Master היא סטנדרט הזהב בתעשיית הספרים.
      עם מנוע מגנטי חזק, היא מספקת ביצועים עקביים לאורך כל היום.
      מתאימה לכל סוגי השיער, משיער דק ועד לשיער עבה וקשה.`,
      descriptionAr: `ماكينة قص الشعر Andis Master هي المعيار الذهبي في صناعة الحلاقة.
      بمحرك مغناطيسي قوي، توفر أداءً متسقاً طوال اليوم.
      مناسبة لجميع أنواع الشعر، من الشعر الناعم إلى الشعر السميك والخشن.`,
      price: 799,
      stock: 18,
      categoryId: getCatId("CLIPPERS"),
      imageUrl: img.andisMaster,
      isFeatured: true,
      isBestSeller: true,

      ...baseCompliance,
      sku: "BP-ANDIS-MASTER",
      barcode: "729001000002",
      sizeLabel: "احترافي",
      unit: "pcs",
      netQuantity: 1,
      tags: [...baseCompliance.tags, "andis", "احترافي", "صالون"],
      usage: "للشعر الجاف فقط. نظف الشفرات بانتظام",
      warnings: "للاستخدام المهني. لا تغمر في الماء",
      variants: [],
    },

    // ========== ماكينات تهذيب ==========
    {
      titleHe: "BabylissPRO Skeleton Trimmer - טרימר מקצועי",
      titleAr: "BabylissPRO Skeleton Trimmer - ماكينة تهذيب احترافية",
      descriptionHe: `הטרימר BabylissPRO Skeleton הוא הטרימר המושלם לקווים מדויקים ועיצוב זקן.
      עם להבי טיטניום חדים במיוחד, הוא מספק דיוק שאין שני לו.
      עיצוב ארגונומי להחזקה נוחה לאורך זמן.`,
      descriptionAr: `ماكينة تهذيب BabylissPRO Skeleton هي الأداة المثالية للخطوط الدقيقة وتشكيل اللحية.
      بشفرات تيتانيوم حادة جداً، توفر دقة لا مثيل لها.
      تصميم مريح يسهل الإمساك به لفترات طويلة.`,
      price: 399,
      stock: 30,
      categoryId: getCatId("TRIMMERS"),
      imageUrl: img.babylissSkeleton,
      discountPercent: 20,
      saleStartAt: new Date(),
      saleEndAt: nowPlusDays(14),
      isFeatured: true,

      ...baseCompliance,
      sku: "BP-BABYLISS-SKELETON",
      barcode: "729001000003",
      sizeLabel: "تهذيب",
      unit: "pcs",
      netQuantity: 1,
      tags: [...baseCompliance.tags, "babyliss", "تهذيب", "دقيق"],
      usage: "لتهذيب الشعر واللحية. نظف بعد كل استخدام",
      variants: [],
    },

    {
      titleHe: "פיליפס מולטיגרום 7000 - מכונת גילוח רב תכליתית",
      titleAr: "فيليبس مولتي جرم 7000 - ماكينة حلاقة متعددة الاستخدامات",
      descriptionHe: `מכונת הגילוח הרב-תכליתית פיליפס מולטיגרום 7000 היא הפיתרון המושלם לכל צרכי הגילוח והטיפוח.
      כוללת 5 מתקנים להחלפה: מכונת תספורת, טרימר, מכונת גילוח, מסרק עיצוב ומברשת ניקוי.
      סוללה המספיקה ל-120 דקות עבודה.`,
      descriptionAr: `ماكينة الحلاقة متعددة الاستخدامات فيليبس مولتي جرم 7000 هي الحل المثالي لجميع احتياجات الحلاقة والعناية.
      تشمل 5 ملحقات قابلة للتبديل: ماكينة قص شعر، ماكينة تهذيب، ماكينة حلاقة، مشط تشكيل وفرشة تنظيف.
      بطارية تكفي لـ 120 دقيقة عمل.`,
      price: 699,
      stock: 22,
      categoryId: getCatId("TRIMMERS"),
      imageUrl: img.philipsMultigroom,
      isFeatured: false,
      isNew: true,

      ...baseCompliance,
      sku: "BP-PHILIPS-MG7000",
      barcode: "729001000004",
      sizeLabel: "متعدد",
      unit: "set",
      netQuantity: 1,
      tags: [...baseCompliance.tags, "philips", "متعدد", "شامل"],
      usage: "للحلاقة والتهذيب والتشكيل. نظف الملحقات بانتظام",
      variants: [],
    },

    // ========== حلاقة ==========
    {
      titleHe: "ג'ילט פיוז'ן 5 - סכיני גילוח עם 5 להבים",
      titleAr: "جيلت فيوجن 5 - شفرات حلاقة بـ 5 شفرات",
      descriptionHe: `סכיני הגילוח ג'ילט פיוז'ן 5 עם 5 להבים מספקים גילוח חלק ללא גירויים.
      הטכנולוגיה המיוחדת מפחיתה את החיכוך עם העור ומבטיחה גילוח נוח.
      מתאים לכל סוגי העור, כולל עור רגיש.`,
      descriptionAr: `شفرات الحلاقة جيلت فيوجن 5 بـ 5 شفرات توفر حلاقة ناعمة بدون تهيج.
      التقنية الخاصة تقلل الاحتكاك مع الجلد وتضمن حلاقة مريحة.
      مناسبة لجميع أنواع البشرة، بما في ذلك البشرة الحساسة.`,
      price: 129,
      stock: 150,
      categoryId: getCatId("SHAVING"),
      imageUrl: img.gilletteFusion,
      discountPercent: 25,
      saleStartAt: new Date(),
      saleEndAt: nowPlusDays(7),
      isFeatured: true,

      ...baseCompliance,
      sku: "BP-GILLETTE-FUSION5",
      barcode: "729001000005",
      sizeLabel: "4 قطع",
      unit: "pcs",
      netQuantity: 4,
      tags: [...baseCompliance.tags, "gillette", "شفرات", "حلاقة"],
      usage: "استخدم مع رغوة أو جل حلاقة. استبدل الشفرة كل 5-7 استخدامات",
      warnings: "حفظ بعيداً عن متناول الأطفال. الشفرات حادة",

      variants: [
        {
          sku: "BP-GILLETTE-FUSION5-4P",
          barcode: "729001000051",
          stock: 80,
          priceOverride: null,
          attributes: [{ key: "pack_count", type: "number", value: 4, valueKey: "", unit: "pcs" }],
        },
        {
          sku: "BP-GILLETTE-FUSION5-8P",
          barcode: "729001000052",
          stock: 70,
          priceOverride: 239,
          attributes: [{ key: "pack_count", type: "number", value: 8, valueKey: "", unit: "pcs" }],
        },
      ],
    },

    {
      titleHe: "Harry's Razor Set - ערכת גילוח פרימיום",
      titleAr: "Harry's Razor Set - مجموعة حلاقة فاخرة",
      descriptionHe: `ערכת הגילוח Harry's כוללת סכין גילוח עם ידית מגנזיום, 5 להבי חילוף וקצף גילוח.
      העיצוב הארגונומי והמשקל המאוזן מספקים שליטה מושלמת בגילוח.
      מוצר איכותי במחיר הוגן.`,
      descriptionAr: `مجموعة الحلاقة Harry's تشمل شفرة حلاقة بمقبض مغنيسيوم، 5 شفرات بديلة ورغوة حلاقة.
      التصميم المريح والوزن المتوازن يوفران تحكماً مثالياً في الحلاقة.
      منتج عالي الجودة بسعر معقول.`,
      price: 249,
      stock: 45,
      categoryId: getCatId("SHAVING"),
      imageUrl: img.harrysRazor,
      isFeatured: false,

      ...baseCompliance,
      sku: "BP-HARRYS-SET",
      barcode: "729001000006",
      sizeLabel: "مجموعة",
      unit: "set",
      netQuantity: 1,
      tags: [...baseCompliance.tags, "harrys", "فاخر", "مجموعة"],
      variants: [],
    },

    // ========== عناية بالشعر ==========
    {
      titleHe: "ווקס לשיער - אחיזה חזקה מאוד, גימור מט",
      titleAr: "واكس للشعر - تثبيت قوي جداً، مظهر غير لامع",
      descriptionHe: `הווקס לשיער שלנו עם אחיזה חזקה מאוד וגימור מט טבעי מתאים לכל סוגי השיער.
      אינו משאיר שאריות לבנות, נשטף בקלות ואינו מייקר את השיער.
      מכיל מרכיבים טבעיים ושומר על בריאות השיער.`,
      descriptionAr: `واكس الشعر لدينا بتثبيت قوي جداً ومظهر غير لامع طبيعي يناسب جميع أنواع الشعر.
      لا يترك بقايا بيضاء، يغسل بسهولة ولا يثقل الشعر.
      يحتوي على مكونات طبيعية ويحافظ على صحة الشعر.`,
      price: 49,
      stock: 0,
      categoryId: getCatId("HAIR_CARE"),
      imageUrl: img.hairWax,
      isFeatured: true,

      ...baseCompliance,
      sku: "BP-HAIR-WAX",
      barcode: "729001000007",
      sizeLabel: "متغير",
      unit: "ml",
      netQuantity: null,
      tags: [...baseCompliance.tags, "واكس", "تثبيت", "شعر"],
      ingredients: "شمع النحل، زبدة الشيا، زيوت طبيعية",
      usage: "ضع كمية صغيرة على راحة اليد، دلك ثم وزع على الشعر",

      variants: [
        {
          sku: "BP-HAIR-WAX-100-MATTE",
          barcode: "729001000071",
          stock: 60,
          priceOverride: 49,
          attributes: [
            { key: "size", type: "enum", value: null, valueKey: "100ml", unit: "" },
            { key: "hold_level", type: "enum", value: null, valueKey: "extra_strong", unit: "" },
            { key: "finish_type", type: "text", value: "غير لامع", valueKey: "", unit: "" },
          ],
        },
        {
          sku: "BP-HAIR-WAX-100-SHINE",
          barcode: "729001000072",
          stock: 55,
          priceOverride: 49,
          attributes: [
            { key: "size", type: "enum", value: null, valueKey: "100ml", unit: "" },
            { key: "hold_level", type: "enum", value: null, valueKey: "strong", unit: "" },
            { key: "finish_type", type: "text", value: "لامع", valueKey: "", unit: "" },
          ],
        },
        {
          sku: "BP-HAIR-WAX-200-MATTE",
          barcode: "729001000073",
          stock: 40,
          priceOverride: 79,
          attributes: [
            { key: "size", type: "enum", value: null, valueKey: "200ml", unit: "" },
            { key: "hold_level", type: "enum", value: null, valueKey: "extra_strong", unit: "" },
            { key: "finish_type", type: "text", value: "غير لامع", valueKey: "", unit: "" },
          ],
        },
      ],
    },

    {
      titleHe: "פומאדה קלאסית - אחיזה בינונית, גימור מבריק",
      titleAr: "بومادة كلاسيكية - تثبيت متوسط، مظهر لامع",
      descriptionHe: `הפומאדה הקלאסית שלנו מספקת אחיזה בינונית עם גימור מבריק ומקצועי.
      מתאימה ליצירת תסרוקות קלאסיות כמו סידור הצידה או קווים ישרים.
      ניתן לעיצוב מחדש לאורך היום.`,
      descriptionAr: `البومادة الكلاسيكية لدينا توفر تثبيت متوسط بمظهر لامع واحترافي.
      مناسبة لإنشاء تسريحات كلاسيكية مثل التصفيف الجانبي أو الخطوط المستقيمة.
      قابلة لإعادة التشكيل طوال اليوم.`,
      price: 59,
      stock: 85,
      categoryId: getCatId("HAIR_CARE"),
      imageUrl: img.pomade,
      discountPercent: 10,
      saleStartAt: new Date(),
      saleEndAt: nowPlusDays(21),

      ...baseCompliance,
      sku: "BP-POMADE-CLASSIC",
      barcode: "729001000008",
      sizeLabel: "100ml",
      unit: "ml",
      netQuantity: 100,
      tags: [...baseCompliance.tags, "بومادة", "كلاسيكي", "لمعان"],
      variants: [],
    },

    // ========== عناية باللحية ==========
    {
      titleHe: "שמן זקן פרימיום - שמן ארגן וזית",
      titleAr: "زيت لحية فاخر - زيت الأرجان والزيتون",
      descriptionHe: `שמן הזקן הפרימיום שלנו מכיל שמן ארגן אורגני ושמן זית בכבישה קרה.
      מרכך את הזקן, מונע קשקשים וגירויים, ומעניק ריח עדין וטבעי.
      מתאים לכל סוגי העור והזקן.`,
      descriptionAr: `زيت اللحية الفاخر لدينا يحتوي على زيت الأرجان العضوي وزيت الزيتون البكر.
      يلين اللحية، يمنع القشرة والتهيج، ويعطي رائحة خفيفة وطبيعية.
      مناسب لجميع أنواع البشرة واللحى.`,
      price: 79,
      stock: 120,
      categoryId: getCatId("BEARD_CARE"),
      imageUrl: img.beardOil,
      isFeatured: true,
      isBestSeller: true,

      ...baseCompliance,
      sku: "BP-BEARD-OIL-PREMIUM",
      barcode: "729001000009",
      sizeLabel: "30ml",
      unit: "ml",
      netQuantity: 30,
      tags: [...baseCompliance.tags, "لحية", "زيت", "عناية"],
      ingredients: "زيت الأرجان العضوي، زيت الزيتون البكر، فيتامين E",
      usage: "ضع 3-4 قطرات على راحة اليد، دلك ثم وزع على اللحية والجلد تحتها",

      variants: [
        {
          sku: "BP-BEARD-OIL-30-ARGA",
          barcode: "729001000091",
          stock: 65,
          priceOverride: null,
          attributes: [
            { key: "size", type: "enum", value: null, valueKey: "30ml", unit: "" },
            { key: "scent", type: "text", value: "خشب الصندل", valueKey: "", unit: "" },
          ],
        },
        {
          sku: "BP-BEARD-OIL-30-CEDAR",
          barcode: "729001000092",
          stock: 55,
          priceOverride: null,
          attributes: [
            { key: "size", type: "enum", value: null, valueKey: "30ml", unit: "" },
            { key: "scent", type: "text", value: "أرز", valueKey: "", unit: "" },
          ],
        },
        {
          sku: "BP-BEARD-OIL-60-ARGA",
          barcode: "729001000093",
          stock: 40,
          priceOverride: 129,
          attributes: [
            { key: "size", type: "enum", value: null, valueKey: "50ml", unit: "" },
            { key: "scent", type: "text", value: "خشب الصندل", valueKey: "", unit: "" },
          ],
        },
      ],
    },

    {
      titleHe: "מסרק זקן מעץ - ערכת 2 מסרקים בגדלים שונים",
      titleAr: "مشط لحية من الخشب - مجموعة مشطين بحجمين مختلفين",
      descriptionHe: `ערכת מסרקי הזקן מעץ כוללת 2 מסרקים בגדלים שונים: מסרק צפוף להפצת שמן ומסרק רחב לסידור.
      העיצוב הארגונומי והחומר הטבעי מונעים חשמל סטטי ושבירת שיער.
      מתנה מושלמת לגברים עם זקן.`,
      descriptionAr: `مجموعة أمشاط اللحية الخشبية تشمل مشطين بحجمين مختلفين: مشط كثيف لتوزيع الزيت ومشط عريض للتصفيف.
      التصميم المريح والمادة الطبيعية تمنع الكهرباء الساكنة وتكسر الشعر.
      هدية مثالية للرجال ذوي اللحى.`,
      price: 45,
      stock: 75,
      categoryId: getCatId("BEARD_CARE"),
      imageUrl: img.beardComb,
      isFeatured: false,

      ...baseCompliance,
      sku: "BP-BEARD-COMB-SET",
      barcode: "729001000010",
      sizeLabel: "مجموعة",
      unit: "set",
      netQuantity: 2,
      tags: [...baseCompliance.tags, "مشط", "لحية", "خشب"],
      variants: [],
    },

    // ========== إكسسوارات ==========
    {
      titleHe: "מספריים ספרות מקצועיות - 5.5 אינץ'",
      titleAr: "مقص حلاقة احترافي - 5.5 بوصة",
      descriptionHe: `מספריים הספרות המקצועיות שלנו באורך 5.5 אינץ' עשויות מפלדת יפנית איכותית.
      הלהבים החדים והמשקל המאוזן מאפשרים חיתוך מדויק ונוח לאורך זמן.
      מתאימות לספרים מקצועיים ולשימוש ביתי.`,
      descriptionAr: `مقص الحلاقة الاحترافي لدينا بطول 5.5 بوصة مصنوع من فولاذ ياباني عالي الجودة.
      الشفرات الحادة والوزن المتوازن يسمحان بقص دقيق ومريح لفترات طويلة.
      مناسبة للحلاقين المحترفين والاستخدام المنزلي.`,
      price: 189,
      stock: 40,
      categoryId: getCatId("ACCESSORIES"),
      imageUrl: img.barberScissors,
      discountPercent: 15,
      saleStartAt: new Date(),
      saleEndAt: nowPlusDays(45),
      isFeatured: true,

      ...baseCompliance,
      sku: "BP-SCISSORS-PRO",
      barcode: "729001000011",
      sizeLabel: "5.5 بوصة",
      unit: "pcs",
      netQuantity: 1,
      tags: [...baseCompliance.tags, "مقص", "احترافي", "صالون"],
      variants: [],
    },

    // ========== عناية بالبشرة ==========
    {
      titleHe: "אפטרשייב מרגיע - לק אחרי גילוח",
      titleAr: "مهدئ بعد الحلاقة - لوشن بعد الحلاقة",
      descriptionHe: `האפטרשייב המרגיע שלנו מכיל אלנטואין ואלוורה להרגעת העור לאחר הגילוח.
      מונע גירויים, אדמומיות ופצעים לאחר הגילוח.
      מתאים לכל סוגי העור, כולל עור רגיש.`,
      descriptionAr: `اللوشن المهدئ بعد الحلاقة لدينا يحتوي على الألانتوين والألوفيرا لتهدئة البشرة بعد الحلاقة.
      يمنع التهيج، الاحمرار والجروح بعد الحلاقة.
      مناسب لجميع أنواع البشرة، بما في ذلك البشرة الحساسة.`,
      price: 65,
      stock: 95,
      categoryId: getCatId("SKINCARE"),
      imageUrl: img.aftershave,
      isFeatured: false,

      ...baseCompliance,
      sku: "BP-AFTERSHAVE-SOOTH",
      barcode: "729001000012",
      sizeLabel: "100ml",
      unit: "ml",
      netQuantity: 100,
      tags: [...baseCompliance.tags, "بشرة", "بعد الحلاقة", "تهدئة"],
      variants: [],
    },

    // ========== منتج هدية ==========
    {
      titleHe: "מסרק מתנה - עם רכישה מעל 300 ש״ח",
      titleAr: "مشط هدية - مع شراء فوق 300 شيكل",
      descriptionHe: `מסרק איכותי מעץ - מתנה לרכישה מעל 300 ש״ח.
      מתאים לשיער ולזקן, בעיצוב קלאסי ואיכותי.
      *מחיר המוצר 0 ש״ח - ניתן רק כמתנה עם רכישה.`,
      descriptionAr: `مشط خشب عالي الجودة - هدية مع شراء فوق 300 شيكل.
      مناسب للشعر واللحية، بتصميم كلاسيكي وعالي الجودة.
      *سعر المنتج 0 شيكل - متاح فقط كهدية مع الشراء.`,
      price: 0,
      stock: 999,
      categoryId: getCatId("ACCESSORIES"),
      imageUrl: img.beardComb,
      isActive: true,

      ...baseCompliance,
      sku: "BP-GIFT-COMB",
      barcode: "729001000099",
      sizeLabel: "هدية",
      unit: "pcs",
      netQuantity: 1,
      tags: [...baseCompliance.tags, "هدية", "مجاني"],
      variants: [],
    },
  ];

  const products = [];
  for (const p of productDocs) {
    const doc = normalizeProductDoc(p);
    doc.createdAt = new Date();
    doc.updatedAt = new Date();
    doc.tagsHe = doc.tags;
    doc.tagsAr = doc.tags;

    const saved = await upsertByFilter(Product, { sku: doc.sku }, doc);
    products.push(saved);
  }

  const productBySku = new Map(products.map((p) => [p.sku, p]));

  console.log(
    `✅ تم إضافة ${products.length} منتج بـ ${productDocs.reduce(
      (acc, p) => acc + (p.variants?.length || 0),
      0
    )} متغير`
  );

  /* -------------------------
     5) الشحن والتوصيل
  ------------------------- */
  console.log("📝 إضافة خيارات الشحن...");

  const deliveryAreas = await Promise.all(
    [
      {
        nameHe: "מרכז (תל אביב והסביבה)",
        nameAr: "المركز (تل أبيب والمنطقة)",
        fee: 25,
        isActive: true,
      },
      {
        nameHe: "צפון (חיפה, נצרת והגליל)",
        nameAr: "الشمال (حيفا، الناصرة والجليل)",
        fee: 30,
        isActive: true,
      },
      {
        nameHe: "דרום (באר שבע, אילת והנגב)",
        nameAr: "الجنوب (بئر السبع، إيلات والنقب)",
        fee: 35,
        isActive: true,
      },
      {
        nameHe: "ירושלים והסביבה",
        nameAr: "القدس والمنطقة",
        fee: 28,
        isActive: true,
      },
    ].map((a) =>
      upsertByFilter(DeliveryArea, { nameHe: a.nameHe }, {
        ...a,
        name: a.nameHe,
        fee: Number(a.fee),
        createdAt: new Date(),
        updatedAt: new Date(),
      })
    )
  );

  const pickupPoints = await Promise.all(
    [
      {
        nameHe: "נקודת איסוף — קניון עזריאלי, תל אביב",
        nameAr: "نقطة استلام - مركز عزرائيلي التجاري، تل أبيب",
        addressHe: "תל אביב, קניון עזריאלי, קומה 2, חנות 205",
        addressAr: "تل أبيب، مركز عزرائيلي التجاري، الطابق 2، محل 205",
        fee: 10,
        isActive: true,
      },
      {
        nameHe: "נקודת איסוף — מלון דן פנורמה, ירושלים",
        nameAr: "نقطة استلام - فندق دان بانوراما، القدس",
        addressHe: "ירושלים, רחוב קרן היסוד 39, לובי המלון",
        addressAr: "القدس، شارع كيرين هيسود 39، لوبي الفندق",
        fee: 12,
        isActive: true,
      },
      {
        nameHe: "נקודת איסוף — קניון חיפה, חיפה",
        nameAr: "نقطة استلام - مركز حيفا التجاري، حيفا",
        addressHe: "חיפה, קניון חיפה, קומה 1, ליד הכניסה הראשית",
        addressAr: "حيفا، مركز حيفا التجاري، الطابق 1، بجانب المدخل الرئيسي",
        fee: 10,
        isActive: true,
      },
    ].map((p) =>
      upsertByFilter(PickupPoint, { nameHe: p.nameHe }, {
        ...p,
        name: p.nameHe,
        address: p.addressHe,
        fee: Number(p.fee),
        createdAt: new Date(),
        updatedAt: new Date(),
      })
    )
  );

  await StorePickupConfig.findOneAndUpdate(
    {},
    {
      $set: {
        isEnabled: true,
        fee: 0,
        addressHe: "תל אביב, רחוב המסגר 12",
        addressAr: "تل أبيب، شارع هامسغير 12",
        notesHe:
          "שעות פעילות: א׳–ה׳ 9:00–18:00, ו' 9:00–14:00. יש לתאם הגעה מראש בטלפון.",
        notesAr:
          "ساعات العمل: الأحد-الخميس 9:00-18:00، الجمعة 9:00-14:00. يجب التنسيق على الهاتف مسبقاً.",
        address: "תל אביב, רחוב המסגר 12",
        notes:
          "שעות פעילות: א׳–ה׳ 9:00–18:00, ו' 9:00–14:00. יש לתאם הגעה מראש בטלפון.",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    },
    { upsert: true, new: true }
  );

  console.log(`✅ تم إضافة ${deliveryAreas.length} منطقة توصيل، ${pickupPoints.length} نقطة استلام`);

  /* -------------------------
     6) الكوبونات
  ------------------------- */
  console.log("📝 إضافة الكوبونات...");

  const coupons = [
    {
      code: "SAVE20",
      type: "percent",
      value: 20,
      minOrderTotal: 200,
      maxDiscount: 100,
      usageLimit: 500,
      usedCount: 0,
      startAt: new Date(),
      endAt: nowPlusDays(60),
      isActive: true,
    },
    {
      code: "FIRST10",
      type: "percent",
      value: 10,
      minOrderTotal: 100,
      maxDiscount: 50,
      usageLimit: 1000,
      usedCount: 0,
      startAt: new Date(),
      endAt: nowPlusDays(90),
      isActive: true,
    },
    {
      code: "FREESHIP",
      type: "fixed",
      value: 30,
      minOrderTotal: 150,
      maxDiscount: 30,
      usageLimit: 2000,
      usedCount: 0,
      startAt: new Date(),
      endAt: nowPlusDays(45),
      isActive: true,
    },
    {
      code: "BEARD25",
      type: "percent",
      value: 25,
      minOrderTotal: 100,
      maxDiscount: 75,
      usageLimit: 300,
      usedCount: 0,
      startAt: new Date(),
      endAt: nowPlusDays(30),
      isActive: true,
    },
  ];

  for (const coupon of coupons) {
    await upsertByFilter(Coupon, { code: coupon.code }, {
      ...coupon,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }

  console.log(`✅ تم إضافة ${coupons.length} كوبون`);

  /* -------------------------
     7) الحملات
  ------------------------- */
  console.log("📝 إضافة الحملات...");

  const campaigns = [
  ];

  for (const campaign of campaigns) {
    await upsertByFilter(Campaign, { nameHe: campaign.nameHe }, {
      ...campaign,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }

  console.log(`✅ تم إضافة ${campaigns.length} حملة`);

  /* -------------------------
     8) الهدايا
  ------------------------- */
  console.log("📝 إضافة عروض الهدايا...");

  const giftComb = productBySku.get("BP-GIFT-COMB");
  if (!giftComb) throw new Error("[seed] منتج الهدية غير موجود: BP-GIFT-COMB");

  const gifts = [
    {
      nameHe: "מסרק במתנה - רכישה מעל 300 ש״ח",
      nameAr: "مشط هدية - شراء فوق 300 شيكل",
      name: "מסרק במתנה",
      giftProductId: giftComb._id,
      minOrderTotal: 300,
      requiredProductId: null,
      requiredCategoryId: null,
      startAt: new Date(),
      endAt: nowPlusDays(90),
      isActive: true,
    },
    {
      nameHe: "שמן זקן במתנה - רכישה מעל 500 ש״ח",
      nameAr: "زيت لحية هدية - شراء فوق 500 شيكل",
      name: "שמן זקן במתנה",
      giftProductId: productBySku.get("BP-BEARD-OIL-PREMIUM")?._id,
      minOrderTotal: 500,
      requiredProductId: null,
      requiredCategoryId: getCatId("BEARD_CARE"),
      startAt: new Date(),
      endAt: nowPlusDays(60),
      isActive: true,
    },
  ];

  let savedGiftsCount = 0;
  for (const gift of gifts) {
    if (gift.giftProductId) {
      await upsertByFilter(Gift, { nameHe: gift.nameHe }, {
        ...gift,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      savedGiftsCount++;
    }
  }

  console.log(`✅ تم إضافة ${savedGiftsCount} عرض هدايا`);

  /* -------------------------
     9) العروض الموسمية
  ------------------------- */
  console.log("📝 إضافة العروض الموسمية...");

  
  const hairWax = productBySku.get("BP-HAIR-WAX");
  if (!hairWax) throw new Error("[seed] منتج غير موجود للعرض BUY_X_GET_Y: BP-HAIR-WAX");

const offers = [
    {
      nameHe: "הנחת חורף - 15% על כל מוצרי הטיפוח",
      nameAr: "خصم شتوي - 15٪ على جميع منتجات العناية",
      name: "הנחת חורף",
      type: "PERCENT_OFF",
      value: 15,
      minTotal: 150,
      productIds: [],
      categoryIds: [getCatId("HAIR_CARE"), getCatId("BEARD_CARE"), getCatId("SKINCARE")],
      stackable: true,
      priority: 10,
      startAt: new Date(),
      endAt: nowPlusDays(60),
      isActive: true,
    },
    {
      nameHe: "משלוח חינם בהזמנה מעל 250 ש״ח",
      nameAr: "شحن مجاني على الطلبات فوق 250 شيكل",
      name: "משלוח חינם",
      type: "FREE_SHIPPING",
      value: 0,
      minTotal: 250,
      productIds: [],
      categoryIds: [],
      stackable: false,
      priority: 20,
      startAt: new Date(),
      endAt: nowPlusDays(45),
      isActive: true,
    },
    {
  nameHe: "רכישה 3 ב-2 על שעווה לשיער",
  nameAr: "شراء 3 بسعر 2 على واكس الشعر",
  name: "רכישה 3 ב-2",
  type: "BUY_X_GET_Y",
  value: 0,
  minTotal: 100,

  // BUY 3 GET 1 on the same product (hair wax)
  buyProductId: hairWax._id,
  buyVariantId: null,
  buyQty: 3,

  getProductId: hairWax._id,
  getVariantId: null,
  getQty: 1,

  productIds: [],
  categoryIds: [],

  stackable: false,
  priority: 30,
  startAt: new Date(),
  endAt: nowPlusDays(30),
  isActive: true,
},
  ];

  for (const offer of offers) {
    await upsertByFilter(Offer, { nameHe: offer.nameHe }, {
      ...offer,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }

  console.log(`✅ تم إضافة ${offers.length} عرض موسمي`);

  /* -------------------------
     10) صفحات المحتوى
  ------------------------- */
  console.log("📝 إضافة صفحات المحتوى...");

  const pages = [
  // =========================================================
  // ABOUT
  // =========================================================
  {
    slug: "about",
    titleHe: "אודות Barber Bang",
    titleAr: "من نحن - Barber Bang",
    contentHe: `ברוכים הבאים ל-Barber Bang — חנות אונליין מובילה בישראל למוצרי טיפוח לגברים ולציוד ברבר מקצועי.

אנחנו מתמחים במוצרי שיער, זקן וגילוח באיכות גבוהה, ומתמקדים בחוויית קנייה מודרנית, מהירה ובטוחה.

מה תמצאו אצלנו:
• מוצרי טיפוח לשיער ולזקן (שמפו, ווקס, פומייד, שמנים)
• ציוד ברבר מקצועי (מסרקים, מברשות, אביזרי גילוח)
• מוצרים משלימים לגברים (ספריי, סטיילינג, טיפוח עור)

למה לבחור ב-Barber Bang?
• איכות גבוהה ומבחר מקצועי
• שירות לקוחות זמין ומהיר
• משלוחים לכל הארץ + נקודות איסוף + איסוף מהחנות
• תשלום מאובטח ושקיפות מלאה לאורך כל הדרך

אנחנו מאמינים שטיפוח גברי הוא לא טרנד — זה סטנדרט.
תודה שבחרתם Barber Bang.`,
    contentAr: `أهلاً بكم في Barber Bang — متجر إلكتروني رائد في إسرائيل لمنتجات العناية بالرجال ومستلزمات الحلاقة الاحترافية.

نحن متخصصون بمنتجات الشعر واللحية والحلاقة بجودة عالية، ونركّز على تجربة شراء حديثة وسريعة وآمنة.

ماذا ستجدون لدينا؟
• منتجات عناية للشعر واللحية (شامبو، واكس، بوميد، زيوت)
• معدات حلاقة احترافية (أمشاط، فرش، أدوات حلاقة)
• منتجات مكملة للرجال (سبراي، ستايلينغ، عناية بالبشرة)

لماذا Barber Bang؟
• جودة عالية ومجموعة مختارة بعناية
• خدمة عملاء سريعة ومتاحة
• توصيل لكل البلاد + نقاط استلام + استلام من المتجر
• دفع آمن وشفافية كاملة

نؤمن أن العناية الرجالية ليست موضة — بل أسلوب حياة.
شكراً لاختياركم Barber Bang.`,
    sortOrder: 10,
    isActive: true,
  },

  // =========================================================
  // TERMS
  // =========================================================
  {
    slug: "terms",
    titleHe: "תקנון האתר",
    titleAr: "شروط وأحكام",
    contentHe: `תקנון האתר — Barber Bang

1) כללי:
• השימוש באתר מהווה הסכמה לתנאי התקנון.
• האתר מיועד לרכישה אונליין של מוצרי טיפוח וציוד ברבר.
• Barber Bang רשאית לעדכן תוכן/מחירים/מבצעים בכל עת.

2) מחירים ומע״מ (VAT):
• כל המחירים באתר כוללים מע״מ (VAT), אלא אם צוין אחרת במפורש.
• המחיר הסופי בעגלה/בקופה הוא המחיר הקובע לאחר הטבות/קופונים/מבצעים (אם יש).

3) זמינות מלאי:
• הזמנות כפופות לזמינות מלאי בפועל.
• במקרה של חוסר במלאי — ניצור קשר ונציע החלפה/זיכוי/ביטול פריט.

4) תמונות ותיאור:
• תמונות להמחשה בלבד.
• ייתכנו הבדלים קלים בגוון/אריזה בין אצווה לאצווה.

5) תשלום ואישור הזמנה:
• הזמנה מאושרת לאחר השלמת תשלום/אישור ובדיקת פרטים.
• ייתכנו מקרים חריגים בהם ניצור קשר לאימות.

6) אחריות המשתמש:
• המשתמש אחראי לספק פרטים נכונים (שם, טלפון, כתובת).
• במקרה של כתובת שגויה/אי זמינות — יתכנו עיכובים או חיובים בהתאם למדיניות.

7) יצירת קשר:
• ניתן לפנות לשירות לקוחות בכל שאלה — פרטי יצירת קשר מופיעים באתר.`,
    contentAr: `شروط وأحكام — Barber Bang

1) عام:
• استخدام الموقع يعني الموافقة على الشروط.
• الموقع مخصص لشراء منتجات العناية ومستلزمات الحلاقة عبر الإنترنت.
• يحق لـ Barber Bang تعديل المحتوى/الأسعار/العروض في أي وقت.

2) الأسعار وضريبة القيمة المضافة (VAT):
• جميع الأسعار في الموقع تشمل ضريبة القيمة المضافة VAT إلا إذا ذكر غير ذلك بشكل واضح.
• السعر النهائي في السلة/الدفع هو السعر المعتمد بعد الخصومات/الكوبونات/العروض إن وجدت.

3) توفر المخزون:
• الطلبات تخضع لتوفر المخزون الفعلي.
• في حال نفاد منتج — نتواصل معكم لتبديل/إرجاع مبلغ/إلغاء المنتج.

4) الصور والوصف:
• الصور للعرض فقط.
• قد توجد فروقات بسيطة في اللون أو التغليف بين دفعات مختلفة.

5) الدفع وتأكيد الطلب:
• يتم تأكيد الطلب بعد إتمام الدفع/الموافقة والتحقق من التفاصيل.
• قد نطلب تأكيداً إضافياً في حالات خاصة.

6) مسؤولية العميل:
• العميل مسؤول عن إدخال بيانات صحيحة (الاسم/الهاتف/العنوان).
• في حال عنوان غير صحيح أو عدم توفر المستلم قد يحدث تأخير أو رسوم حسب السياسة.

7) التواصل:
• يمكنكم التواصل مع خدمة العملاء لأي استفسار — التفاصيل موجودة بالموقع.`,
    sortOrder: 15,
    isActive: true,
  },

  // =========================================================
  // SHIPPING POLICY
  // =========================================================
  {
    slug: "shipping",
    titleHe: "מדיניות משלוחים",
    titleAr: "سياسة الشحن",
    contentHe: `מדיניות משלוחים — Barber Bang

שיטות משלוח (יוצגו בקופה לפי אזור וזמינות):

1) משלוח עד הבית (DELIVERY)
• זמן אספקה משוער: 1–4 ימי עסקים
• עלות: משתנה לפי אזור (מוצג בקופה)
• מסירה לכתובת שנמסרה בעת ההזמנה

2) נקודת איסוף (PICKUP POINT)
• זמן אספקה משוער: 2–3 ימי עסקים
• עלות: משתנה לפי נקודה (מוצג בקופה)
• הלקוח בוחר נקודת איסוף מהרשימה הזמינה

3) איסוף עצמי מהחנות (STORE PICKUP)
• בתיאום מראש
• זמן הכנה: לרוב באותו יום/יום עסקים אחד
• עלות: חינם או לפי תנאי העסק (מוצג בקופה)

מידע חשוב:
• ימי עסקים: א׳–ה׳ (לא כולל שבת וחגים)
• הזמנות לפני שעה מסוימת עשויות לצאת באותו יום עסקים (לפי עומסים)
• תקבלו עדכון סטטוס הזמנה לאחר יצירת ההזמנה ובמהלך הטיפול

עיכובים חריגים:
• מזג אוויר/עומסים/חגים עלולים להשפיע על זמני אספקה.

משלוח חינם:
• אם קיים מבצע “משלוח חינם” — הוא יחול בהתאם לסכום מינימום/תנאי המבצע המוצגים באתר.`,
    contentAr: `سياسة الشحن — Barber Bang

طرق الشحن (تظهر عند الدفع حسب المنطقة والتوفر):

1) توصيل للمنزل (DELIVERY)
• مدة التوصيل المتوقعة: 1–4 أيام عمل
• التكلفة: تختلف حسب المنطقة (تظهر عند الدفع)
• التسليم يكون للعنوان المُدخل أثناء الطلب

2) نقطة استلام (PICKUP POINT)
• مدة التوصيل المتوقعة: 2–3 أيام عمل
• التكلفة: تختلف حسب النقطة (تظهر عند الدفع)
• العميل يختار نقطة الاستلام من القائمة المتاحة

3) الاستلام من المتجر (STORE PICKUP)
• بالتنسيق المسبق
• تجهيز الطلب غالباً بنفس اليوم أو يوم عمل واحد
• التكلفة: مجاناً أو حسب سياسة المتجر (تظهر عند الدفع)

معلومات مهمة:
• أيام العمل: الأحد–الخميس (باستثناء السبت والأعياد)
• بعض الطلبات قد تُرسل في نفس يوم العمل حسب الوقت والضغط
• ستصلكم تحديثات عن حالة الطلب أثناء المعالجة

تأخير استثنائي:
• ضغط العطل/الطقس/الأعياد قد يؤثر على أوقات التوصيل

الشحن المجاني:
• إذا كان هناك عرض “شحن مجاني” يتم تطبيقه حسب الحد الأدنى وشروط العرض الموجودة بالموقع.`,
    sortOrder: 20,
    isActive: true,
  },

  // =========================================================
  // RETURNS & EXCHANGES
  // =========================================================
  {
    slug: "returns",
    titleHe: "החזרות והחלפות",
    titleAr: "الإرجاع والاستبدال",
    contentHe: `מדיניות החזרות והחלפות — Barber Bang

1) תקופת החזרה:
• ניתן לבקש החזרה או החלפה תוך 14 ימים מיום קבלת ההזמנה.
• המוצר חייב להיות באריזתו המקורית, סגור, לא בשימוש ובמצב תקין.

2) מוצרים שלא ניתן להחזיר:
• מוצרי היגיינה/אישיים שנפתחו (לדוגמה: סכיני גילוח, תערים, מוצרים שנפתחו לשימוש).
• מוצרים שניזוקו עקב שימוש לא נכון.
• מוצרים בהתאמה אישית (אם קיים).

3) איך מבקשים החזרה?
• פונים אלינו בוואטסאפ/טלפון עם מספר הזמנה.
• מצרפים תמונה של המוצר במידת הצורך.
• לאחר אישור — נמסור הנחיות החזרה.

4) החזר כספי:
• לאחר קבלת המוצר ובדיקתו — נבצע זיכוי בהתאם לשיטת התשלום המקורית תוך 7–10 ימי עסקים.
• עלויות משלוח עשויות שלא להיות מוחזרות (בהתאם לנסיבות).

5) מוצר פגום / טעות בהזמנה:
• יש לפנות אלינו בתוך 48 שעות מקבלת המוצר ולצרף תמונות ברורות.
• נטפל במהירות ובאחריות מלאה.

אנחנו מחויבים לשירות הוגן וחוויית קנייה מצוינת.`,
    contentAr: `سياسة الإرجاع والاستبدال — Barber Bang

1) مدة الإرجاع:
• يمكن طلب إرجاع أو استبدال خلال 14 يوماً من تاريخ استلام الطلب.
• يجب أن يكون المنتج بعلبته الأصلية، مغلق، غير مستخدم وبحالة سليمة.

2) منتجات لا يمكن إرجاعها:
• المنتجات الشخصية/الصحية بعد فتحها (مثل شفرات الحلاقة أو منتجات تم فتحها للاستخدام).
• المنتجات المتضررة بسبب سوء الاستخدام.
• المنتجات المخصصة حسب الطلب (إن وجدت).

3) كيف نطلب الإرجاع؟
• تواصل معنا عبر واتساب/هاتف مع رقم الطلب.
• أرسل صورة للمنتج عند الحاجة.
• بعد الموافقة — نعطيك تعليمات الإرجاع.

4) استرجاع المبلغ:
• بعد استلام المنتج وفحصه — يتم استرجاع المبلغ خلال 7–10 أيام عمل حسب طريقة الدفع الأصلية.
• تكاليف الشحن قد لا تُعاد حسب الحالة.

5) منتج تالف / خطأ في الطلب:
• يجب التواصل خلال 48 ساعة مع صور واضحة.
• نعالج الموضوع بسرعة وبمسؤولية كاملة.

هدفنا تجربة شراء ممتازة وخدمة عادلة.`,
    sortOrder: 30,
    isActive: true,
  },

  // =========================================================
  // CANCELLATION POLICY (IMPORTANT IN ISRAEL)
  // =========================================================
  {
    slug: "cancellation",
    titleHe: "ביטול עסקה",
    titleAr: "إلغاء الصفقة",
    contentHe: `מדיניות ביטול עסקה — Barber Bang

ביטול לפני משלוח:
• ניתן לבקש ביטול הזמנה לפני שהמשלוח יצא לדרך.
• לאחר אישור הביטול — יבוצע זיכוי בהתאם לשיטת התשלום.

ביטול לאחר משלוח:
• אם המשלוח כבר יצא — ניתן להחזיר בהתאם למדיניות ההחזרות (תוך 14 ימים ובתנאים הנדרשים).
• במקרים מסוימים עלויות משלוח עשויות לחול.

איך מבקשים ביטול?
• פנו אלינו בוואטסאפ/טלפון עם מספר הזמנה.
• אנחנו נעדכן מיד את סטטוס ההזמנה ונעזור בצורה הוגנת ומהירה.`,
    contentAr: `سياسة إلغاء الصفقة — Barber Bang

إلغاء قبل الشحن:
• يمكن طلب إلغاء الطلب قبل أن يتم إرسال الشحنة.
• بعد تأكيد الإلغاء — يتم إرجاع المبلغ حسب طريقة الدفع الأصلية.

إلغاء بعد الشحن:
• إذا تم إرسال الشحنة بالفعل — يمكن الإرجاع حسب سياسة الإرجاع (خلال 14 يوماً وبالشروط المطلوبة).
• في بعض الحالات قد تُحسب رسوم شحن.

كيف نطلب الإلغاء؟
• تواصل معنا عبر واتساب/هاتف مع رقم الطلب.
• سنقوم بتحديث حالة الطلب مباشرة ومساعدتكم بسرعة وبشكل عادل.`,
    sortOrder: 35,
    isActive: true,
  },

  // =========================================================
  // WARRANTY / RESPONSIBILITY
  // =========================================================
  {
    slug: "warranty",
    titleHe: "אחריות ושירות",
    titleAr: "الضمان وخدمة ما بعد البيع",
    contentHe: `אחריות ושירות — Barber Bang

• אנחנו עובדים עם מוצרים מקוריים ואיכותיים.
• האחריות (אם קיימת) עשויה להשתנות לפי סוג המוצר/המותג.

מה נחשב בעיה?
• פגם בייצור / מוצר שהגיע פגום
• פריט חסר בהזמנה
• טעות בפריט שסופק

מה לא מכוסה?
• בלאי טבעי
• נזק עקב שימוש לא נכון
• נזק שנגרם לאחר פתיחה ושימוש

איך פונים לשירות?
• שלחו לנו מספר הזמנה + תמונות ברורות בוואטסאפ
• נטפל במהירות ונציע פתרון הוגן.`,
    contentAr: `الضمان وخدمة ما بعد البيع — Barber Bang

• نحن نوفّر منتجات أصلية وبجودة عالية.
• الضمان (إن وجد) قد يختلف حسب نوع المنتج أو العلامة التجارية.

ما الذي يُعتبر مشكلة؟
• عيب تصنيع / منتج وصل تالفاً
• نقص في الطلب
• خطأ في المنتج المُرسل

ما الذي لا يشمله الضمان؟
• اهتراء طبيعي
• ضرر بسبب استخدام غير صحيح
• ضرر حدث بعد فتح المنتج واستخدامه

كيف نتواصل مع الدعم؟
• أرسل رقم الطلب + صور واضحة عبر واتساب
• سنعالج الموضوع بسرعة ونقدم حل عادل.`,
    sortOrder: 37,
    isActive: true,
  },

  // =========================================================
  // PRIVACY
  // =========================================================
  {
    slug: "privacy",
    titleHe: "מדיניות פרטיות",
    titleAr: "سياسة الخصوصية",
    contentHe: `מדיניות פרטיות — Barber Bang

אנחנו מכבדים את פרטיותכם ושומרים על מידע אישי בהתאם לסטנדרטים מקובלים.

מידע שנאסף:
• שם, טלפון, כתובת, אימייל — לצורך עיבוד הזמנה ומשלוח
• מידע טכני בסיסי (Cookies) לשיפור חוויית שימוש

שימוש במידע:
• עיבוד הזמנות, משלוחים ותמיכה
• שיפור השירות וחוויית המשתמש
• הודעות על סטטוס הזמנה

שיתוף מידע:
• נשתף מידע מינימלי הנדרש לתפעול (תשלום/משלוח)
• לא נמכור מידע לצדדים שלישיים

זכויות המשתמש:
• ניתן לבקש גישה/עדכון/מחיקה של מידע אישי באמצעות יצירת קשר.`,
    contentAr: `سياسة الخصوصية — Barber Bang

نحن نحترم خصوصيتكم ونحافظ على معلوماتكم الشخصية وفق معايير متبعة.

المعلومات التي نجمعها:
• الاسم، الهاتف، العنوان، البريد الإلكتروني لتنفيذ الطلب والشحن
• معلومات تقنية بسيطة (Cookies) لتحسين تجربة الاستخدام

استخدام المعلومات:
• معالجة الطلبات والشحن والدعم
• تحسين الخدمة وتجربة المستخدم
• إرسال تحديثات حالة الطلب

مشاركة البيانات:
• نشارك الحد الأدنى اللازم للتشغيل (الدفع/الشحن)
• لا نبيع البيانات لأي طرف ثالث

حقوق المستخدم:
• يمكنكم طلب الوصول/التعديل/الحذف من خلال التواصل معنا.`,
    sortOrder: 40,
    isActive: true,
  },

  // =========================================================
  // COOKIES (OPTIONAL BUT VERY GOOD)
  // =========================================================
  {
    slug: "cookies",
    titleHe: "מדיניות קבצי Cookie",
    titleAr: "سياسة ملفات الكوكيز",
    contentHe: `מדיניות Cookie — Barber Bang

אנחנו משתמשים בקבצי Cookie כדי:
• לשמור על חוויית גלישה חלקה
• לשפר ביצועים
• להציג תכנים רלוונטיים

ניתן לשלוט ב-Cookies דרך הגדרות הדפדפן.
חלק מה-Cookies חיוניים לפעילות תקינה של האתר.`,
    contentAr: `سياسة ملفات الكوكيز — Barber Bang

نستخدم ملفات Cookies بهدف:
• الحفاظ على تجربة تصفح سلسة
• تحسين الأداء
• عرض محتوى مناسب

يمكن التحكم بملفات الكوكيز من إعدادات المتصفح.
بعض ملفات الكوكيز ضرورية لعمل الموقع بشكل صحيح.`,
    sortOrder: 42,
    isActive: true,
  },

  // =========================================================
  // ACCESSIBILITY STATEMENT
  // =========================================================
  {
    slug: "accessibility",
    titleHe: "הצהרת נגישות",
    titleAr: "بيان إمكانية الوصول",
    contentHe: `הצהרת נגישות — Barber Bang

אנחנו עושים מאמצים להנגיש את האתר לכלל המשתמשים, כולל ניווט מקלדת, טקסטים קריאים והתאמה למובייל.

אם נתקלתם בקושי:
• פנו אלינו בוואטסאפ/טלפון
• תארו את הבעיה + באיזו עמוד נתקלתם בה
ונשמח לעזור במהירות.`,
    contentAr: `بيان إمكانية الوصول — Barber Bang

نعمل على تحسين إمكانية الوصول بالموقع لجميع المستخدمين، بما يشمل التنقل بالكيبورد، وضوح النصوص، والتوافق مع الموبايل.

إذا واجهتم أي صعوبة:
• تواصلوا معنا عبر واتساب/هاتف
• اذكروا المشكلة والصفحة التي ظهرت بها
وسنساعدكم بسرعة.`,
    sortOrder: 25,
    isActive: true,
  },

  // =========================================================
  // CONTACT
  // =========================================================
  {
    slug: "contact",
    titleHe: "צור קשר",
    titleAr: "اتصل بنا",
    contentHe: `צור קשר — Barber Bang

אנחנו כאן כדי לעזור במהירות.

דרכי התקשרות:
• וואטסאפ: 050-0000000
• טלפון: 050-0000000
• אימייל: support@barberbang.co.il

שעות פעילות:
א׳–ה׳: 09:00–18:00
ו׳: 09:00–14:00
שבת: סגור

מומלץ לפנות בוואטסאפ לקבלת מענה מהיר.`,
    contentAr: `اتصل بنا — Barber Bang

نحن جاهزون لمساعدتكم بسرعة.

طرق التواصل:
• واتساب: 050-0000000
• هاتف: 050-0000000
• بريد إلكتروني: support@barberbang.co.il

ساعات العمل:
الأحد–الخميس: 09:00–18:00
الجمعة: 09:00–14:00
السبت: مغلق

ننصح بالتواصل عبر واتساب للحصول على رد أسرع.`,
    sortOrder: 50,
    isActive: true,
  },
];

for (const p of pages) {
  await upsertByFilter(ContentPage, { slug: p.slug }, {
    ...p,
    createdAt: new Date(),
    updatedAt: new Date(),
  });
}

console.log(`✅ تم إضافة/تحديث ${pages.length} صفحات محتوى (Barber Bang)`);


  /* -------------------------
     11) قائمة الرغبات لمستخدم الاختبار
  ------------------------- */
  console.log("📝 إعداد قائمة الرغبات لمستخدم الاختبار...");

  const wishlistSkus = [
    "BP-WAHL-MAGIC-CLIP",
    "BP-BABYLISS-SKELETON",
    "BP-BEARD-OIL-PREMIUM",
    "BP-HAIR-WAX",
  ];

  const wishlistProductIds = wishlistSkus
    .map((sku) => productBySku.get(sku)?._id)
    .filter(Boolean);

  await User.updateOne(
    { _id: testUser._id },
    { $set: { wishlist: wishlistProductIds, updatedAt: new Date() } }
  );

  console.log(`✅ تمت إضافة ${wishlistProductIds.length} منتج لقائمة رغبات مستخدم الاختبار`);

  /* -------------------------
     12) عينات التقييمات
  ------------------------- */
  console.log("📝 إضافة عينات التقييمات...");

  const reviewTargets = [
    {
      productSku: "BP-WAHL-MAGIC-CLIP",
      rating: 5,
      commentHe:
        "מכונה מצוינת! עובדת כמו חדשה כבר שנה. ממליץ בחום לכל ספר מתחיל או מקצועי.",
      commentAr:
        "ماكينة ممتازة! تعمل مثل الجديدة منذ سنة. أنصح بها بشدة لكل حلاق مبتدئ أو محترف.",
    },
    {
      productSku: "BP-BEARD-OIL-PREMIUM",
      rating: 5,
      commentHe:
        "שמן זקן מעולה! הריח נעים ולא דומיננטי, הזקן רך ובריא. קניתי כבר בפעם השנייה.",
      commentAr:
        "زيت لحية رائع! الرائحة لطيفة وغير مسيطرة، اللحية ناعمة وصحية. اشتريت للمرة الثانية.",
    },
    {
      productSku: "BP-HAIR-WAX",
      rating: 4,
      commentHe:
        "ווקס טוב מאוד, אחיזה חזקה אבל לא משאיר שאריות לבנות. חסרון קטן - נספג מהר מדי.",
      commentAr:
        "واكس جيد جداً، تثبيت قوي لكن لا يترك بقايا بيضاء. عيب صغير - يمتص بسرعة كبيرة.",
    },
    {
      productSku: "BP-GILLETTE-FUSION5",
      rating: 5,
      commentHe:
        "הסכינים הטובים ביותר שניסיתי. גילוח חלק ללא גירויים. שווה כל שקל.",
      commentAr:
        "أفضل الشفرات التي جربتها. حلاقة ناعمة بدون تهيج. يستحق كل قرش.",
    },
    {
      productSku: "BP-SCISSORS-PRO",
      rating: 5,
      commentHe:
        "מספריים מקצועיות אמיתיות. חדות מאוד ומאזן מושלם. מומלץ לכל ספר.",
      commentAr:
        "مقص احترافي حقيقي. حاد جداً وتوازن مثالي. موصى به لكل حلاق.",
    },
  ];

  for (const r of reviewTargets) {
    const prod = productBySku.get(r.productSku);
    if (!prod) continue;

    const comment = `${r.commentHe}\n\n${r.commentAr}`;

    await Review.findOneAndUpdate(
      { productId: prod._id, userId: testUser._id },
      {
        $set: {
          productId: prod._id,
          userId: testUser._id,
          rating: Number(r.rating || 5),
          comment: String(comment || "").trim(),
          isVerified: true,
          helpfulCount: Math.floor(Math.random() * 20) + 5,
          createdAt: new Date(
            Date.now() - Math.floor(Math.random() * 30) * 24 * 60 * 60 * 1000
          ),
          updatedAt: new Date(),
        },
      },
      { upsert: true, new: true }
    );
  }

  console.log(`✅ تم إضافة ${reviewTargets.length} تقييم عينة`);

  /* -------------------------
     الملخص
  ------------------------- */
  console.log("\n🎉 اكتملت عملية بذر البيانات بنجاح!");
  console.log("=".repeat(60));
  console.log("📊 ملخص البيانات:");
  console.log("=".repeat(60));
  console.log("👥 المستخدمون:");
  console.log(`  • المشرف: ${adminEmail} (${adminPass})`);
  console.log(`  • الاختبار: ${testEmail} (${testPass})`);
  console.log("\n🏷️  سمات المنتج:");
  console.log(`  • ${attributes.length} سمة`);
  console.log("\n📁 الفئات:");
  categories.forEach((cat, i) => {
    console.log(`  • ${i + 1}. ${cat.nameHe} / ${cat.nameAr}`);
  });
  console.log("\n🛒 المنتجات:");
  console.log(`  • ${products.length} منتج`);
  console.log(`  • ${productDocs.reduce((acc, p) => acc + (p.variants?.length || 0), 0)} متغير`);
  console.log("\n🚚 الشحن:");
  console.log(`  • ${deliveryAreas.length} منطقة توصيل`);
  console.log(`  • ${pickupPoints.length} نقطة استلام`);
  console.log("\n🎟️  التخفيضات والعروض:");
  console.log(`  • ${coupons.length} كوبون`);
  console.log(`  • ${campaigns.length} حملة`);
  console.log(`  • ${savedGiftsCount} عرض هدايا`);
  console.log(`  • ${offers.length} عرض موسمي`);
  console.log("\n📄 المحتوى:");
  console.log(`  • ${pages.length} صفحة محتوى`);
  console.log("\n💬 التقييمات:");
  console.log(`  • ${reviewTargets.length} تقييم عينة`);
  console.log("=".repeat(60));
  console.log("\n✅ اكتمل سكريبت البذر بنجاح!");
  console.log("\n💡 ملاحظة: يمكن التحكم في سلوك التنظيف باستخدام متغير البيئة SEED_CLEANUP:");
  console.log("   • 'smart' - حذف البيانات غير الإدارية (الافتراضي)");
  console.log("   • 'all' - حذف جميع البيانات بما في ذلك المستخدمين الإداريين");
  console.log("   • 'none' - تخطي التنظيف");
}

main()
  .catch((err) => {
    console.error("❌ فشل سكريبت البذر:", err);
    process.exitCode = 1;
  })
  .finally(async () => {
    try {
      await mongoose.disconnect();
      console.log("🔌 تم إغلاق اتصال MongoDB");
    } catch (e) {
      console.warn("[best-effort] فشل قطع اتصال mongoose:", String(e?.message || e));
    }
  });
