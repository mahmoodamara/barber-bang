import express from "express";
import { z } from "zod";
import { HomeLayout } from "../models/HomeLayout.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { auditAdmin } from "../middleware/audit.js";

const router = express.Router();

// Validation Schema for Sections
const sectionSchema = z.object({
    id: z.string(),
    type: z.enum(["hero", "categories", "featured-products", "banner", "text", "grid-products"]),
    enabled: z.boolean(),
    order: z.number(),
    payload: z.record(z.any()).optional(), // Allow flexible payload but ensure object
});

const layoutUpdateSchema = z.object({
    sections: z.array(sectionSchema),
    __v: z.number().optional(),
});

router.use(requireAuth());
router.use(requireRole("admin"));
router.use(auditAdmin());

/**
 * GET /api/admin/home-layout
 * Get home layout configuration (creates default if missing)
 */
router.get("/", async (req, res, next) => {
    try {
        let layout = await HomeLayout.findOne();
        if (!layout) {
            layout = await HomeLayout.create({ sections: [] });
        }

        res.json({
            success: true,
            data: layout,
        });
    } catch (error) {
        next(error);
    }
});

/**
 * PUT /api/admin/home-layout
 * Update home layout configuration
 */
router.put("/", async (req, res, next) => {
    try {
        const validation = layoutUpdateSchema.safeParse(req.body);
        if (!validation.success) {
            return res.status(400).json({
                success: false,
                error: {
                    code: "VALIDATION_ERROR",
                    message: "Invalid layout data",
                    details: validation.error.format(),
                },
            });
        }

        const { sections, __v } = validation.data;

        let layout = await HomeLayout.findOne();
        if (!layout) {
            layout = new HomeLayout({});
        }

        if (typeof __v === 'number' && layout.__v !== undefined && layout.__v !== __v) {
            return res.status(409).json({
                success: false,
                error: {
                    code: "CONFLICT",
                    message: "Layout has been updated by another user. Please refresh.",
                },
            });
        }

        layout.sections = sections;

        await layout.save();

        res.json({
            success: true,
            data: layout,
        });
    } catch (error) {
        if (error.name === "VersionError") {
            return res.status(409).json({
                success: false,
                error: {
                    code: "CONFLICT",
                    message: "Layout has been updated by another user. Please refresh.",
                },
            });
        }
        next(error);
    }
});

export default router;
