import "dotenv/config";
import { app } from "./app.js";
import { connectDB } from "./config/db.js";
import mongoose from "mongoose";

const PORT = Number(process.env.PORT || 4000);

await connectDB();

const server = app.listen(PORT, () => {
  console.log(`[server] running on http://localhost:${PORT}`);
});

/* ============================
   Graceful Shutdown
============================ */
let isShuttingDown = false;

async function gracefulShutdown(signal) {
  if (isShuttingDown) return;
  isShuttingDown = true;

  console.log(`[server] ${signal} received, shutting down gracefully...`);

  server.close(async () => {
    console.log("[server] HTTP server closed");
    try {
      await mongoose.disconnect();
      console.log("[server] MongoDB disconnected");
      process.exit(0);
    } catch (err) {
      console.error("[server] Error during MongoDB disconnect:", err);
      process.exit(1);
    }
  });
}

process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
process.on("SIGINT", () => gracefulShutdown("SIGINT"));
