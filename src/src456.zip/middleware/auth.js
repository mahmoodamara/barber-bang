import { verifyToken } from "../utils/jwt.js";
import { User } from "../models/User.js";
import { getRequestId } from "./error.js";

function authError(req, code, message) {
  return {
    ok: false,
    error: {
      code,
      message,
      requestId: getRequestId(req),
      path: req.originalUrl || req.url || "",
    },
  };
}

export function requireAuth() {
  return async (req, res, next) => {
    try {
      const header = req.headers.authorization || "";
      const token = header.startsWith("Bearer ") ? header.slice(7) : null;
      if (!token) {
        return res.status(401).json(authError(req, "UNAUTHORIZED", "Missing token"));
      }

      const payload = verifyToken(token);
      const userId = payload.userId || payload.sub;
      if (!userId) {
        return res.status(401).json(authError(req, "UNAUTHORIZED", "Invalid token"));
      }

      const user = await User.findById(userId).select("_id name email role tokenVersion isBlocked permissions");

      if (!user) {
        return res.status(401).json(authError(req, "UNAUTHORIZED", "User not found"));
      }

      if (Number(payload?.tokenVersion || 0) !== Number(user?.tokenVersion || 0)) {
        return res.status(401).json(authError(req, "UNAUTHORIZED", "Invalid token"));
      }

      // Check if user is blocked
      if (user.isBlocked) {
        return res.status(403).json(authError(req, "USER_BLOCKED", "Your account has been blocked"));
      }

      req.user = user;
      next();
    } catch {
      return res.status(401).json(authError(req, "UNAUTHORIZED", "Invalid token"));
    }
  };
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json(authError(req, "UNAUTHORIZED", "Not authenticated"));
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json(authError(req, "FORBIDDEN", "Access denied"));
    }

    next();
  };
}

/**
 * Staff Permissions:
 * - ORDERS_WRITE: Create, update, cancel orders
 * - PRODUCTS_WRITE: Create, update, delete products
 * - PROMOS_WRITE: Manage coupons, campaigns, offers, gifts
 * - SETTINGS_WRITE: Manage site settings, delivery areas, pickup points
 */
export const PERMISSIONS = {
  ORDERS_WRITE: "ORDERS_WRITE",
  PRODUCTS_WRITE: "PRODUCTS_WRITE",
  PROMOS_WRITE: "PROMOS_WRITE",
  SETTINGS_WRITE: "SETTINGS_WRITE",
};

/**
 * Check if user has specific permission(s).
 * Admin always has all permissions.
 * Staff must have the permission explicitly granted.
 * @param {...string} requiredPermissions - One or more permission strings
 */
export function requirePermission(...requiredPermissions) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json(authError(req, "UNAUTHORIZED", "Not authenticated"));
    }

    // Admin has all permissions
    if (req.user.role === "admin") {
      return next();
    }

    // Staff must have explicit permissions
    if (req.user.role === "staff") {
      const userPermissions = new Set(req.user.permissions || []);
      const hasAll = requiredPermissions.every((p) => userPermissions.has(p));

      if (hasAll) {
        return next();
      }

      return res.status(403).json(
        authError(
          req,
          "INSUFFICIENT_PERMISSIONS",
          `Missing required permission(s): ${requiredPermissions.join(", ")}`
        )
      );
    }

    // Regular users don't have admin permissions
    return res.status(403).json(authError(req, "FORBIDDEN", "Access denied"));
  };
}

/**
 * Check if user has any of the specified permissions.
 * Admin always passes.
 * Staff must have at least one of the permissions.
 * @param {...string} permissions - One or more permission strings
 */
export function requireAnyPermission(...permissions) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json(authError(req, "UNAUTHORIZED", "Not authenticated"));
    }

    // Admin has all permissions
    if (req.user.role === "admin") {
      return next();
    }

    // Staff must have at least one permission
    if (req.user.role === "staff") {
      const userPermissions = new Set(req.user.permissions || []);
      const hasAny = permissions.some((p) => userPermissions.has(p));

      if (hasAny) {
        return next();
      }

      return res.status(403).json(
        authError(
          req,
          "INSUFFICIENT_PERMISSIONS",
          `Requires one of: ${permissions.join(", ")}`
        )
      );
    }

    // Regular users don't have admin permissions
    return res.status(403).json(authError(req, "FORBIDDEN", "Access denied"));
  };
}
