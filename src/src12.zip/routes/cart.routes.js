import express from "express";
import { z } from "zod";

import { requireAuth } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { User } from "../models/User.js";
import { Product } from "../models/Product.js";
import { computeEffectiveUnitPriceMinor } from "../services/pricing.service.js";
import { getRequestId } from "../middleware/error.js";

const router = express.Router();

function errorPayload(req, code, message) {
  return {
    ok: false,
    error: {
      code,
      message,
      requestId: getRequestId(req),
      path: req.originalUrl || req.url || "",
    },
  };
}

function fromMinor(minor) {
  const n = Number(minor || 0);
  if (!Number.isFinite(n)) return 0;
  return Math.round(n) / 100;
}

function normalizeKey(raw) {
  const v = String(raw || "").trim().toLowerCase();
  if (!v) return "";
  return v
    .replace(/\s+/g, "_")
    .replace(/[^a-z0-9_]/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function buildLegacyAttributes(variant) {
  if (!variant) return [];
  const legacy = [
    { key: "volume_ml", type: "number", value: variant.volumeMl, unit: "ml" },
    { key: "weight_g", type: "number", value: variant.weightG, unit: "g" },
    { key: "pack_count", type: "number", value: variant.packCount, unit: "" },
    { key: "scent", type: "text", value: variant.scent },
    { key: "hold_level", type: "text", value: variant.holdLevel },
    { key: "finish_type", type: "text", value: variant.finishType },
    { key: "skin_type", type: "text", value: variant.skinType },
  ];

  return legacy
    .map((a) => {
      if (a.type === "number") {
        const n = Number(a.value);
        if (!Number.isFinite(n)) return null;
        return { ...a, value: n };
      }
      const s = String(a.value || "").trim();
      if (!s) return null;
      return { ...a, value: s };
    })
    .filter(Boolean);
}

function normalizeAttributesList(variant) {
  const attrs = Array.isArray(variant?.attributes) ? variant.attributes : [];
  const normalized = attrs
    .map((a) => ({
      key: normalizeKey(a?.key),
      type: String(a?.type || ""),
      value: a?.value ?? null,
      valueKey: normalizeKey(a?.valueKey),
      unit: String(a?.unit || ""),
    }))
    .filter((a) => a.key && a.type);

  const keys = new Set(normalized.map((a) => a.key));
  for (const la of buildLegacyAttributes(variant)) {
    if (!keys.has(la.key)) normalized.push(la);
  }

  return normalized;
}

function legacyAttributesObject(list) {
  const obj = {
    volumeMl: null,
    weightG: null,
    packCount: null,
    scent: "",
    holdLevel: "",
    finishType: "",
    skinType: "",
  };

  for (const a of list || []) {
    const key = String(a?.key || "");
    const val = a?.value;
    if (key === "volume_ml" && Number.isFinite(Number(val))) obj.volumeMl = Number(val);
    if (key === "weight_g" && Number.isFinite(Number(val))) obj.weightG = Number(val);
    if (key === "pack_count" && Number.isFinite(Number(val))) obj.packCount = Number(val);
    if (key === "scent" && typeof val === "string") obj.scent = val;
    if (key === "hold_level" && typeof val === "string") obj.holdLevel = val;
    if (key === "finish_type" && typeof val === "string") obj.finishType = val;
    if (key === "skin_type" && typeof val === "string") obj.skinType = val;
  }

  return obj;
}

router.get("/", requireAuth(), async (req, res) => {
  const user = await User.findById(req.user._id).populate("cart.productId");
  const items = (user.cart || []).map((ci) => ({
    product: ci.productId,
    qty: ci.qty,
    variantId: ci.variantId || "",
    variantSnapshot: ci.variantSnapshot || null,
  }));
  res.json({ ok: true, data: items });
});

const addSchema = z.object({
  body: z.object({
    productId: z.string().min(1),
    qty: z.number().int().min(1).max(999),
    variantId: z.string().min(1).optional(),
  }),
});

router.post("/add", requireAuth(), validate(addSchema), async (req, res) => {
  const { productId, qty, variantId } = req.validated.body;

  const product = await Product.findById(productId);
  if (!product || !product.isActive) {
    return res.status(404).json(errorPayload(req, "NOT_FOUND", "Product not found"));
  }

  const hasVariants = Array.isArray(product.variants) && product.variants.length > 0;
  const variant = hasVariants
    ? product.variants.find((v) => String(v?._id || "") === String(variantId || ""))
    : null;

  if (hasVariants && !variant) {
    return res.status(400).json(errorPayload(req, "VARIANT_REQUIRED", "variantId is required"));
  }

  const user = await User.findById(req.user._id);
  const idMatch = String(variant?._id || "");
  const idx = user.cart.findIndex(
    (x) =>
      x.productId.toString() === productId &&
      String(x.variantId || "") === String(idMatch || "")
  );

  if (idx >= 0) user.cart[idx].qty = Math.min(user.cart[idx].qty + qty, 999);
  else {
    const unitMinor = computeEffectiveUnitPriceMinor(product, variant);
    const attributesList = variant ? normalizeAttributesList(variant) : [];
    user.cart.push({
      productId,
      qty,
      variantId: idMatch,
      variantSnapshot: variant
        ? {
            variantId: idMatch,
            sku: String(variant?.sku || ""),
            price: fromMinor(unitMinor),
            priceMinor: Math.max(0, Math.round(unitMinor)),
            attributesList,
            attributes: {
              ...legacyAttributesObject(attributesList),
            },
          }
        : null,
    });
  }

  await user.save();
  res.json({ ok: true, data: user.cart });
});

const setQtySchema = z.object({
  body: z.object({
    productId: z.string().min(1),
    qty: z.number().int().min(1).max(999),
    variantId: z.string().min(1).optional(),
  }),
});

router.post("/set-qty", requireAuth(), validate(setQtySchema), async (req, res) => {
  const { productId, qty, variantId } = req.validated.body;
  const user = await User.findById(req.user._id);
  const idx = user.cart.findIndex(
    (x) =>
      x.productId.toString() === productId &&
      String(x.variantId || "") === String(variantId || "")
  );
  if (idx < 0) {
    return res.status(404).json(errorPayload(req, "NOT_FOUND", "Item not found in cart"));
  }
  user.cart[idx].qty = qty;
  await user.save();
  res.json({ ok: true, data: user.cart });
});

const removeSchema = z.object({
  body: z.object({
    productId: z.string().min(1),
    variantId: z.string().min(1).optional(),
  }),
});

router.post("/remove", requireAuth(), validate(removeSchema), async (req, res) => {
  const { productId, variantId } = req.validated.body;

  const user = await User.findById(req.user._id);
  if (variantId) {
    user.cart = user.cart.filter(
      (x) =>
        x.productId.toString() !== productId ||
        String(x.variantId || "") !== String(variantId || "")
    );
  } else {
    user.cart = user.cart.filter((x) => x.productId.toString() !== productId);
  }
  await user.save();

  res.json({ ok: true, data: user.cart });
});

router.post("/clear", requireAuth(), async (req, res) => {
  const user = await User.findById(req.user._id);
  user.cart = [];
  await user.save();
  res.json({ ok: true, data: [] });
});

export default router;
