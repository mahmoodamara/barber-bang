import "dotenv/config";
import { app } from "./app.js";
import { connectDB } from "./config/db.js";
import mongoose from "mongoose";

const PORT = Number(process.env.PORT || 4000);

if (!Number.isFinite(PORT) || PORT <= 0) {
  console.error(`[server] Invalid PORT value: ${process.env.PORT}`);
  process.exit(1);
}

await connectDB();

const server = app.listen(PORT, () => {
  console.log(`[server] running on http://localhost:${PORT}`);
});

/* ============================
   Server Error Handling
============================ */
server.on("error", (err) => {
  if (err?.code === "EADDRINUSE") {
    console.error(
      `[server] Port ${PORT} is already in use. Stop the other process or change PORT in .env`
    );
    process.exit(1);
  }

  if (err?.code === "EACCES") {
    console.error(
      `[server] No permission to bind to port ${PORT}. Try a higher port (e.g., 4001).`
    );
    process.exit(1);
  }

  console.error("[server] Server failed to start:", err);
  process.exit(1);
});

/* ============================
   Graceful Shutdown
============================ */
let isShuttingDown = false;

async function gracefulShutdown(signal) {
  if (isShuttingDown) return;
  isShuttingDown = true;

  console.log(`[server] ${signal} received, shutting down gracefully...`);

  // stop accepting new connections
  server.close(async (closeErr) => {
    if (closeErr) {
      console.error("[server] Error closing HTTP server:", closeErr);
    } else {
      console.log("[server] HTTP server closed");
    }

    try {
      await mongoose.disconnect();
      console.log("[server] MongoDB disconnected");
      process.exit(closeErr ? 1 : 0);
    } catch (err) {
      console.error("[server] Error during MongoDB disconnect:", err);
      process.exit(1);
    }
  });

  // hard-exit fallback (prevents hanging if something stuck)
  setTimeout(() => {
    console.error("[server] Force exit (shutdown timeout)");
    process.exit(1);
  }, 10_000).unref();
}

process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
process.on("SIGINT", () => gracefulShutdown("SIGINT"));

/* ============================
   Process-level safety
============================ */
process.on("unhandledRejection", (reason) => {
  console.error("[server] Unhandled Rejection:", reason);
  gracefulShutdown("unhandledRejection");
});

process.on("uncaughtException", (err) => {
  console.error("[server] Uncaught Exception:", err);
  gracefulShutdown("uncaughtException");
});
