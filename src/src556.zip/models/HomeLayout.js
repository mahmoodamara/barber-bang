import mongoose from "mongoose";

const sectionSchema = new mongoose.Schema({
    id: { type: String, required: true }, // unique UI id
    type: {
        type: String,
        required: true,
        enum: ["hero", "categories", "featured-products", "banner", "text", "grid-products"]
    },
    enabled: { type: Boolean, default: true },
    order: { type: Number, default: 0 },
    payload: { type: mongoose.Schema.Types.Mixed, default: {} }, // Flexible content
}, { _id: false });

const homeLayoutSchema = new mongoose.Schema(
    {
        sections: {
            type: [sectionSchema],
            default: [],
        },
    },
    {
        timestamps: true,
        optimisticConcurrency: true,
        autoCreate: true,
    }
);

// Ensure only one layout doc exists typically
export const HomeLayout = mongoose.model("HomeLayout", homeLayoutSchema);
