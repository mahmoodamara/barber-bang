// src/models/Order.js
import mongoose from "mongoose";

/* ============================
   Sub-schemas
============================ */

const orderItemSchema = new mongoose.Schema(
  {
    productId: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },

    // ✅ bilingual titles (recommended)
    titleHe: { type: String, default: "" },
    titleAr: { type: String, default: "" },

    // ✅ additive unified title (some services may use it)
    // not required to avoid breaking old code
    title: { type: String, default: "" },

    unitPrice: { type: Number, required: true, min: 0 }, // ILS major
    qty: { type: Number, required: true, min: 1, max: 999 },

    categoryId: { type: mongoose.Schema.Types.ObjectId, ref: "Category", default: null },
  },
  { _id: false }
);

const giftItemSchema = new mongoose.Schema(
  {
    productId: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },

    // ✅ bilingual titles
    titleHe: { type: String, default: "" },
    titleAr: { type: String, default: "" },

    // ✅ additive unified title
    title: { type: String, default: "" },

    qty: { type: Number, required: true, min: 1, max: 50, default: 1 },
  },
  { _id: false }
);

/**
 * ✅ Pricing contract aligned with quotePricing():
 * quote returns:
 * {
 *   subtotal,
 *   shippingFee,
 *   discounts: {
 *     coupon: { code?, amount },
 *     campaign: { amount },
 *     offer: { amount }
 *   },
 *   gifts,
 *   total
 * }
 */
const pricingSchema = new mongoose.Schema(
  {
    subtotal: { type: Number, required: true, min: 0 },
    shippingFee: { type: Number, required: true, min: 0 },

    discounts: {
      coupon: {
        code: { type: String, default: null },
        amount: { type: Number, default: 0, min: 0 },
      },
      campaign: {
        amount: { type: Number, default: 0, min: 0 },
      },
      offer: {
        amount: { type: Number, default: 0, min: 0 },
      },
    },

    total: { type: Number, required: true, min: 0 },

    // ✅ Additive legacy fields (safe)
    discountTotal: { type: Number, default: 0, min: 0 },
    couponCode: { type: String, default: "" },
    campaignId: { type: mongoose.Schema.Types.ObjectId, ref: "Campaign", default: null },
  },
  { _id: false }
);

const shippingSchema = new mongoose.Schema(
  {
    mode: { type: String, enum: ["DELIVERY", "PICKUP_POINT", "STORE_PICKUP"], required: true },

    deliveryAreaId: { type: mongoose.Schema.Types.ObjectId, ref: "DeliveryArea", default: null },
    pickupPointId: { type: mongoose.Schema.Types.ObjectId, ref: "PickupPoint", default: null },

    // ✅ Root phone for guest tracking comparisons
    phone: { type: String, default: "" },

    // ✅ Delivery address (required by runtime validation for DELIVERY)
    address: {
      fullName: { type: String, default: "" },

      // ✅ IMPORTANT: needed for /orders/track + stored data integrity
      phone: { type: String, default: "" },

      city: { type: String, default: "" },
      street: { type: String, default: "" },
      notes: { type: String, default: "" },
    },
  },
  { _id: false }
);

const stripeSchema = new mongoose.Schema(
  {
    sessionId: { type: String, default: "" },
    paymentIntentId: { type: String, default: "" },
  },
  { _id: false }
);

/* ============================
   Main Order Schema
============================ */

const orderSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },

    items: { type: [orderItemSchema], required: true },
    gifts: { type: [giftItemSchema], default: [] },

    status: {
      type: String,
      enum: [
        // Stripe lifecycle
        "pending_payment",
        "paid",
        "confirmed",
        "shipped",
        "delivered",

        // COD lifecycle
        "pending_cod",

        // common
        "cancelled",
      ],
      default: "pending_payment",
      index: true,
    },

    paymentMethod: { type: String, enum: ["stripe", "cod"], required: true, index: true },

    // ✅ Source of truth pricing
    pricing: { type: pricingSchema, required: true },

    // ✅ Shipping for tracking + fulfillment
    shipping: { type: shippingSchema, required: true },

    // Stripe refs
    stripe: { type: stripeSchema, default: () => ({}) },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

/* ============================
   Virtuals (Legacy compatibility)
============================ */

orderSchema.virtual("subtotal").get(function subtotalVirtual() {
  return this?.pricing?.subtotal ?? 0;
});

orderSchema.virtual("shippingFee").get(function shippingFeeVirtual() {
  return this?.pricing?.shippingFee ?? 0;
});

orderSchema.virtual("total").get(function totalVirtual() {
  return this?.pricing?.total ?? 0;
});

/* ============================
   Indexes
============================ */

orderSchema.index({ userId: 1, createdAt: -1 });
orderSchema.index({ status: 1, createdAt: -1 });

// ✅ helpful for guest tracking
orderSchema.index({ "shipping.phone": 1, createdAt: -1 });

export const Order = mongoose.model("Order", orderSchema);
