import hpp from "hpp";

export const hppMiddleware = hpp({
  checkQuery: true,
  checkBody: true,
});
