// src/routes/orders.routes.js
import express from "express";
import { z } from "zod";
import mongoose from "mongoose";

import { requireAuth } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { Order } from "../models/Order.js";

const router = express.Router();

/* -------------------------------- Helpers -------------------------------- */

function normalizePhone(raw) {
  let v = String(raw || "").trim();
  if (!v) return "";

  // keep digits + leading +
  v = v.replace(/[^\d+]/g, "");

  // normalize Israeli patterns:
  // +9725XXXXXXXX => 05XXXXXXXX
  // 9725XXXXXXXX  => 05XXXXXXXX
  // 5XXXXXXXX     => 05XXXXXXXX
  if (v.startsWith("+972")) v = v.replace("+972", "0");
  if (v.startsWith("972")) v = v.replace("972", "0");
  if (/^5\d{8,9}$/.test(v)) v = "0" + v;

  return v;
}

function shippingLabel(mode, lang = "he") {
  const he = {
    DELIVERY: "משלוח עד הבית",
    PICKUP_POINT: "נקודת איסוף",
    STORE_PICKUP: "איסוף מהחנות",
  };

  const ar = {
    DELIVERY: "توصيل للبيت",
    PICKUP_POINT: "نقطة استلام",
    STORE_PICKUP: "استلام من المتجر",
  };

  const L = String(lang || "he").toLowerCase() === "ar" ? "ar" : "he";
  const dict = L === "ar" ? ar : he;
  return dict[mode] || (L === "ar" ? "شحن" : "משלוח");
}

function pickItemTitle(it, lang = "he") {
  const L = String(lang || "he").toLowerCase() === "ar" ? "ar" : "he";

  const heTitle = it?.titleHe || it?.title || "";
  const arTitle = it?.titleAr || "";

  if (L === "ar") return arTitle || heTitle || it?.title || "";
  return heTitle || arTitle || it?.title || "";
}

function pickItemUnitPrice(it) {
  // Compatible with old shapes
  const v = it?.unitPrice ?? it?.price ?? it?.linePrice ?? 0;
  return Number(v || 0);
}

function safe404(res) {
  return res.status(404).json({
    ok: false,
    error: { code: "ORDER_NOT_FOUND", message: "Order not found" },
  });
}

function jsonErr(res, e) {
  return res.status(e.statusCode || 500).json({
    ok: false,
    error: {
      code: e.code || "INTERNAL_ERROR",
      message: e.message || "Unexpected error",
    },
  });
}

/* ----------------------------- Schemas ----------------------------- */

const trackSchema = z.object({
  body: z.object({
    orderId: z.string().min(1),
    phone: z.string().min(7).max(30),
  }),
});

/* ----------------------------- Routes ----------------------------- */

/**
 * GET /api/orders/me
 * Authenticated user orders
 */
router.get("/me", requireAuth(), async (req, res) => {
  try {
    const items = await Order.find({ userId: req.user._id })
      .sort({ createdAt: -1 });

    return res.json({ ok: true, data: items });
  } catch (e) {
    return jsonErr(res, e);
  }
});

/**
 * POST /api/orders/track?lang=he|ar
 * Guest safe tracking (NO leakage)
 *
 * IMPORTANT: must be BEFORE "/:id"
 */
router.post("/track", validate(trackSchema), async (req, res) => {
  try {
    const { orderId, phone } = req.validated.body;

    // invalid id -> 404 (no leak)
    if (!mongoose.Types.ObjectId.isValid(orderId)) {
      return safe404(res);
    }

    // lean() for speed (virtuals won't exist)
    const order = await Order.findById(orderId).lean();
    if (!order) return safe404(res);

    // Prefer shipping.phone (new schema), fallback to address.phone (old)
    const storedRaw =
      order?.shipping?.phone ||
      order?.shipping?.address?.phone ||
      "";

    const stored = normalizePhone(storedRaw);
    const provided = normalizePhone(phone);

    if (!stored || !provided || stored !== provided) {
      return safe404(res);
    }

    const safeItems = (order.items || []).map((it) => ({
      title: pickItemTitle(it, req.lang),
      qty: Number(it?.qty || 1),
      price: pickItemUnitPrice(it),
    }));

    const mode = order?.shipping?.mode || "DELIVERY";

    const safe = {
      id: order._id,
      status: order.status,
      createdAt: order.createdAt,

      // ✅ use pricing.total because lean() won't include virtuals
      total: Number(order?.pricing?.total ?? order?.total ?? 0),

      items: safeItems,
      shipping: {
        mode,
        label: shippingLabel(mode, req.lang),
      },
    };

    return res.json({ ok: true, data: safe });
  } catch (e) {
    return jsonErr(res, e);
  }
});

/**
 * GET /api/orders/:id
 * Authenticated user order by id
 */
router.get("/:id", requireAuth(), async (req, res) => {
  try {
    const id = String(req.params.id || "");
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(404).json({
        ok: false,
        error: { code: "NOT_FOUND", message: "Order not found" },
      });
    }

    const item = await Order.findOne({ _id: id, userId: req.user._id });
    if (!item) {
      return res.status(404).json({
        ok: false,
        error: { code: "NOT_FOUND", message: "Order not found" },
      });
    }

    return res.json({ ok: true, data: item });
  } catch (e) {
    return jsonErr(res, e);
  }
});

export default router;
