// src/routes/checkout.routes.js

import express from "express";
import { z } from "zod";

import { requireAuth } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";

import { User } from "../models/User.js";
import { Order } from "../models/Order.js";
import { Product } from "../models/Product.js";
import { Coupon } from "../models/Coupon.js";

import { quotePricing } from "../services/pricing.service.js";
import { createCheckoutSession } from "../services/stripe.service.js";

const router = express.Router();

/* ============================
   Zod Schemas
============================ */

const addressSchema = z.object({
  fullName: z.string().min(2).max(80),
  phone: z.string().min(7).max(30),
  city: z.string().min(2).max(60),
  street: z.string().min(2).max(120),
  notes: z.string().max(300).optional(),
});

const baseCheckoutBodySchema = z
  .object({
    shippingMode: z.enum(["DELIVERY", "PICKUP_POINT", "STORE_PICKUP"]),
    deliveryAreaId: z.string().min(1).optional(),
    pickupPointId: z.string().min(1).optional(),
    address: addressSchema.optional(),
    couponCode: z.string().max(40).optional(),
  })
  .superRefine((b, ctx) => {
    if (b.shippingMode === "DELIVERY") {
      if (!b.deliveryAreaId) {
        ctx.addIssue({
          code: "custom",
          path: ["deliveryAreaId"],
          message: "deliveryAreaId is required for DELIVERY",
        });
      }
      if (!b.address) {
        ctx.addIssue({
          code: "custom",
          path: ["address"],
          message: "address is required for DELIVERY",
        });
      }
      return;
    }

    if (b.shippingMode === "PICKUP_POINT") {
      if (!b.pickupPointId) {
        ctx.addIssue({
          code: "custom",
          path: ["pickupPointId"],
          message: "pickupPointId is required for PICKUP_POINT",
        });
      }
      return;
    }

    // STORE_PICKUP: no additional requirements
  });

const quoteSchema = z.object({
  body: baseCheckoutBodySchema,
});

/* ============================
   Helpers
============================ */

function makeErr(statusCode, code, message) {
  const err = new Error(message);
  err.statusCode = statusCode;
  err.code = code;
  return err;
}

async function getCartItemsOrThrow(userId) {
  const user = await User.findById(userId).select("cart").lean();
  const cart = user?.cart || [];

  const items = cart.map((x) => ({
    productId: x.productId?.toString?.() || String(x.productId),
    qty: Number(x.qty || 1),
  }));

  if (!items.length) throw makeErr(400, "CART_EMPTY", "Cart is empty");
  return items;
}

function toShippingInput(body) {
  const address = body.address || null;
  const phone = address?.phone ? String(address.phone) : "";

  return {
    mode: body.shippingMode,
    deliveryAreaId: body.deliveryAreaId || null,
    pickupPointId: body.pickupPointId || null,

    // ✅ keep phone in both root + address for tracking compatibility
    phone,
    address: address
      ? {
          fullName: String(address.fullName || ""),
          phone: String(address.phone || ""),
          city: String(address.city || ""),
          street: String(address.street || ""),
          notes: String(address.notes || ""),
        }
      : null,
  };
}

/**
 * Atomic stock decrement for COD:
 * Uses bulkWrite conditional update to prevent negative stock
 */
async function decrementStockAtomicOrThrow(items) {
  const ops = (items || []).map((it) => ({
    updateOne: {
      filter: {
        _id: it.productId,
        isActive: true,
        stock: { $gte: Number(it.qty || 0) },
      },
      update: { $inc: { stock: -Number(it.qty || 0) } },
    },
  }));

  if (!ops.length) return;

  const result = await Product.bulkWrite(ops, { ordered: true });
  const matched = Number(result?.matchedCount || 0);

  if (matched !== ops.length) {
    throw makeErr(400, "OUT_OF_STOCK", "One or more items are out of stock");
  }
}

/**
 * Best-effort stock validation for Stripe (no decrement here)
 */
async function validateStockBestEffortOrThrow(items) {
  const ids = [...new Set((items || []).map((x) => String(x.productId)))];
  if (!ids.length) return;

  const prods = await Product.find({ _id: { $in: ids }, isActive: true })
    .select("_id stock isActive titleHe title")
    .lean();

  const byId = new Map(prods.map((p) => [p._id.toString(), p]));

  for (const it of items || []) {
    const p = byId.get(String(it.productId));
    if (!p || !p.isActive) {
      throw makeErr(400, "INVALID_PRODUCT", "Product not available");
    }
    if (Number(p.stock || 0) < Number(it.qty || 0)) {
      throw makeErr(400, "OUT_OF_STOCK", `${p.titleHe || p.title || "Item"} is out of stock`);
    }
  }
}

function roundMoney(n) {
  return Math.round((Number(n) + Number.EPSILON) * 100) / 100;
}

function calcDiscountTotal(quote) {
  const c = Number(quote?.discounts?.coupon?.amount || 0);
  const ca = Number(quote?.discounts?.campaign?.amount || 0);
  const o = Number(quote?.discounts?.offer?.amount || 0);
  return roundMoney(c + ca + o);
}

/**
 * ✅ Order Model wants bilingual titles (titleHe/titleAr) + optional title.
 * quotePricing already returns titleHe/titleAr in items/gifts.
 */
function mapOrderItemsFromQuote(quote) {
  return (quote.items || []).map((it) => ({
    productId: it.productId,

    titleHe: String(it.titleHe || ""),
    titleAr: String(it.titleAr || ""),

    // additive unified title (fallback for old consumers)
    title: String(it.titleHe || it.titleAr || ""),

    unitPrice: Number(it.unitPrice || 0),
    qty: Number(it.qty || 1),

    categoryId: it.categoryId || null,
  }));
}

function mapGiftItemsFromQuote(quote) {
  return (quote.gifts || [])
    .filter((g) => g?.productId)
    .map((g) => ({
      productId: g.productId,

      titleHe: String(g.titleHe || ""),
      titleAr: String(g.titleAr || ""),

      // additive unified title
      title: String(g.titleHe || g.titleAr || ""),

      qty: Number(g.qty || 1),
    }));
}

/**
 * ✅ Compatibility layer for stripe.service.js (old versions):
 * Some implementations expect:
 * - quote.lang
 * - quote.shipping
 * - quote.pricing.shippingFee
 */
function buildStripeQuote(quote, shipping, lang) {
  return {
    ...quote,
    lang,
    shipping,
    pricing: {
      subtotal: Number(quote.subtotal || 0),
      shippingFee: Number(quote.shippingFee || 0),
      total: Number(quote.total || 0),
    },
  };
}

/* ============================
   Routes
============================ */

/**
 * POST /api/checkout/quote
 * ✅ Single truth pricing for UI
 */
router.post("/quote", requireAuth(), validate(quoteSchema), async (req, res, next) => {
  try {
    const cartItems = await getCartItemsOrThrow(req.user._id);
    const b = req.validated.body;

    const quote = await quotePricing({
      cartItems,
      shipping: toShippingInput(b),
      couponCode: b.couponCode,
    });

    return res.json({ ok: true, data: quote });
  } catch (e) {
    return next(e);
  }
});

/**
 * POST /api/checkout/cod
 * ✅ MUST reuse quotePricing
 * ✅ Atomic stock decrement
 * ✅ Coupon usedCount increment NOW (COD order is placed)
 * ✅ Clear cart NOW
 */
router.post("/cod", requireAuth(), validate(quoteSchema), async (req, res, next) => {
  try {
    const cartItems = await getCartItemsOrThrow(req.user._id);
    const b = req.validated.body;

    const shipping = toShippingInput(b);

    const quote = await quotePricing({
      cartItems,
      shipping,
      couponCode: b.couponCode,
    });

    await decrementStockAtomicOrThrow(quote.items);

    const discountTotal = calcDiscountTotal(quote);
    const couponAppliedCode = String(quote?.discounts?.coupon?.code || "");

    const orderItems = mapOrderItemsFromQuote(quote);
    const giftItems = mapGiftItemsFromQuote(quote);

    const order = await Order.create({
      userId: req.user._id,

      items: orderItems,
      gifts: giftItems,

      status: "pending_cod",
      paymentMethod: "cod",

      // ✅ Pricing contract aligned with quotePricing()
      pricing: {
        subtotal: Number(quote.subtotal || 0),
        shippingFee: Number(quote.shippingFee || 0),
        discounts: quote.discounts || {
          coupon: { code: null, amount: 0 },
          campaign: { amount: 0 },
          offer: { amount: 0 },
        },
        total: Number(quote.total || 0),

        // ✅ additive legacy (safe)
        discountTotal: Number(discountTotal || 0),
        couponCode: couponAppliedCode,
        campaignId: quote?.meta?.campaignId || null,
      },

      shipping,

      stripe: { sessionId: "", paymentIntentId: "" },
    });

    // ✅ Coupon usedCount increment for COD only
    if (couponAppliedCode) {
      await Coupon.updateOne({ code: couponAppliedCode }, { $inc: { usedCount: 1 } });
    }

    // ✅ Clear cart (order placed)
    await User.updateOne({ _id: req.user._id }, { $set: { cart: [] } });

    return res.status(201).json({ ok: true, data: order });
  } catch (e) {
    return next(e);
  }
});

/**
 * POST /api/checkout/stripe
 * ✅ MUST reuse quotePricing
 * ✅ Create pending_payment order
 * ✅ DO NOT increment coupon usedCount here (webhook after payment)
 * ✅ DO NOT clear cart here (safer UX)
 */
router.post("/stripe", requireAuth(), validate(quoteSchema), async (req, res, next) => {
  try {
    const cartItems = await getCartItemsOrThrow(req.user._id);
    const b = req.validated.body;

    const shipping = toShippingInput(b);

    const quote = await quotePricing({
      cartItems,
      shipping,
      couponCode: b.couponCode,
    });

    await validateStockBestEffortOrThrow(quote.items);

    const discountTotal = calcDiscountTotal(quote);
    const couponAppliedCode = String(quote?.discounts?.coupon?.code || "");

    const orderItems = mapOrderItemsFromQuote(quote);
    const giftItems = mapGiftItemsFromQuote(quote);

    const order = await Order.create({
      userId: req.user._id,

      items: orderItems,
      gifts: giftItems,

      status: "pending_payment",
      paymentMethod: "stripe",

      pricing: {
        subtotal: Number(quote.subtotal || 0),
        shippingFee: Number(quote.shippingFee || 0),
        discounts: quote.discounts || {
          coupon: { code: null, amount: 0 },
          campaign: { amount: 0 },
          offer: { amount: 0 },
        },
        total: Number(quote.total || 0),

        discountTotal: Number(discountTotal || 0),
        couponCode: couponAppliedCode,
        campaignId: quote?.meta?.campaignId || null,
      },

      shipping,

      stripe: { sessionId: "", paymentIntentId: "" },
    });

    const idempotencyKey = req.get("Idempotency-Key") || undefined;

    const stripeQuote = buildStripeQuote(quote, shipping, req.lang);

    const session = await createCheckoutSession({
      orderId: order._id.toString(),
      quote: stripeQuote,
      lang: req.lang,
      idempotencyKey,
    });

    order.stripe = order.stripe || {};
    order.stripe.sessionId = session.id;
    await order.save();

    return res.json({
      ok: true,
      data: {
        orderId: order._id,
        checkoutUrl: session.url,
      },
    });
  } catch (e) {
    return next(e);
  }
});

export default router;
