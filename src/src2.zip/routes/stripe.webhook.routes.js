// src/routes/stripe.webhook.routes.js
import express from "express";

import { constructWebhookEvent } from "../services/stripe.service.js";
import { Order } from "../models/Order.js";
import { Product } from "../models/Product.js";
import { Coupon } from "../models/Coupon.js";

const router = express.Router();

/* ============================
   Helpers
============================ */

function safe200(res) {
  return res.status(200).json({ received: true });
}

function normalizeCoupon(code) {
  const v = String(code || "").trim();
  return v ? v.toUpperCase() : "";
}

/**
 * ✅ Atomic stock decrement:
 * Prevents negative stock and race conditions.
 * If ANY item fails -> throws OUT_OF_STOCK
 */
async function decrementStockAtomicOrThrow(orderItems) {
  const ops = (orderItems || []).map((it) => ({
    updateOne: {
      filter: {
        _id: it.productId,
        isActive: true,
        stock: { $gte: Number(it.qty || 0) },
      },
      update: { $inc: { stock: -Number(it.qty || 0) } },
    },
  }));

  if (!ops.length) return;

  const result = await Product.bulkWrite(ops, { ordered: true });
  const matched = Number(result?.matchedCount || 0);

  // If any update didn't match -> invalid/inactive/out of stock
  if (matched !== ops.length) {
    const err = new Error("One or more items are out of stock");
    err.statusCode = 400;
    err.code = "OUT_OF_STOCK";
    throw err;
  }
}

/* ============================
   Webhook Route
============================ */

router.post("/", express.raw({ type: "application/json" }), async (req, res) => {
  try {
    const sig = req.headers["stripe-signature"];
    if (!sig) return res.status(400).send("Missing stripe-signature header");

    const event = constructWebhookEvent(req.body, sig);

    // We care about:
    // - checkout.session.completed
    // - checkout.session.async_payment_succeeded
    // - checkout.session.async_payment_failed
    const type = event?.type || "";

    const accepted = new Set([
      "checkout.session.completed",
      "checkout.session.async_payment_succeeded",
      "checkout.session.async_payment_failed",
    ]);

    if (!accepted.has(type)) return safe200(res);

    const session = event?.data?.object || {};
    const sessionId = String(session?.id || "");
    if (!sessionId) return safe200(res);

    // Find order by Stripe sessionId (stored in checkout/stripe route)
    const order = await Order.findOne({
      paymentMethod: "stripe",
      "stripe.sessionId": sessionId,
    });

    // Always 200 (do not leak)
    if (!order) return safe200(res);

    // ✅ Idempotency: only process when pending_payment
    if (order.status !== "pending_payment") return safe200(res);

    // Async failed => cancel (no stock changes)
    if (type === "checkout.session.async_payment_failed") {
      await Order.updateOne(
        { _id: order._id, status: "pending_payment" },
        { $set: { status: "cancelled" } }
      );
      return safe200(res);
    }

    // For completed/async_succeeded, ensure it's actually paid
    const paymentStatus = String(session?.payment_status || "").toLowerCase();
    if (paymentStatus && paymentStatus !== "paid") {
      // Payment not finalized yet → keep pending
      return safe200(res);
    }

    const paymentIntentId = session?.payment_intent ? String(session.payment_intent) : "";

    /**
     * ✅ Lock order first (idempotent guard)
     * We transition pending_payment -> paid exactly once.
     * If 2 webhooks race, only one will win the lock.
     */
    const locked = await Order.findOneAndUpdate(
      {
        _id: order._id,
        status: "pending_payment",
        paymentMethod: "stripe",
        "stripe.sessionId": sessionId,
      },
      {
        $set: {
          status: "paid",
          "stripe.paymentIntentId": paymentIntentId,
        },
      },
      { new: true }
    );

    if (!locked) return safe200(res);

    /**
     * ✅ Stock decrement AFTER lock
     * If stock fails -> cancel order (payment already succeeded)
     * Note: This implies you may need manual refund later (business decision).
     */
    try {
      await decrementStockAtomicOrThrow(locked.items);
    } catch (e) {
      await Order.updateOne(
        { _id: locked._id },
        { $set: { status: "cancelled" } }
      );
      return safe200(res);
    }

    /**
     * ✅ Coupon usedCount increment AFTER payment success (Stripe only)
     * Support both:
     * - pricing.couponCode (legacy additive)
     * - pricing.discounts.coupon.code (new contract)
     */
    const couponCode = normalizeCoupon(
      locked?.pricing?.couponCode ||
        locked?.pricing?.discounts?.coupon?.code
    );

    if (couponCode) {
      await Coupon.updateOne(
        { code: couponCode },
        { $inc: { usedCount: 1 } }
      );
    }

    return safe200(res);
  } catch (err) {
    console.error("[stripe.webhook] error", err);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
});

export default router;
