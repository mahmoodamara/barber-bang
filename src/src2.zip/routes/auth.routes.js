import express from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";

import { validate } from "../middleware/validate.js";
import { User } from "../models/User.js";
import { signToken } from "../utils/jwt.js";

const router = express.Router();

const registerSchema = z.object({
  body: z.object({
    name: z.string().min(2).max(60),
    email: z.string().email(),
    password: z.string().min(6).max(128),
  }),
});

router.post("/register", validate(registerSchema), async (req, res) => {
  const { name, email, password } = req.validated.body;

  const exists = await User.findOne({ email: email.toLowerCase().trim() });
  if (exists) {
    return res.status(409).json({
      ok: false,
      error: { code: "EMAIL_EXISTS", message: "Email already used" },
    });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const user = await User.create({
    name,
    email: email.toLowerCase().trim(),
    passwordHash,
    role: "user",
  });

  const token = signToken({ userId: user._id.toString(), role: user.role });

  return res.json({
    ok: true,
    data: {
      token,
      user: { id: user._id, name: user.name, email: user.email, role: user.role },
    },
  });
});

const loginSchema = z.object({
  body: z.object({
    email: z.string().email(),
    password: z.string().min(6).max(128),
  }),
});

router.post("/login", validate(loginSchema), async (req, res) => {
  const { email, password } = req.validated.body;

  const user = await User.findOne({ email: email.toLowerCase().trim() });
  if (!user) {
    return res.status(401).json({
      ok: false,
      error: { code: "INVALID_CREDENTIALS", message: "Invalid email/password" },
    });
  }

  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) {
    return res.status(401).json({
      ok: false,
      error: { code: "INVALID_CREDENTIALS", message: "Invalid email/password" },
    });
  }

  const token = signToken({ userId: user._id.toString(), role: user.role });

  return res.json({
    ok: true,
    data: {
      token,
      user: { id: user._id, name: user.name, email: user.email, role: user.role },
    },
  });
});

export default router;
