import express from "express";
import { z } from "zod";

import { requireAuth, requireRole } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";

import { DeliveryArea } from "../models/DeliveryArea.js";
import { PickupPoint } from "../models/PickupPoint.js";
import { StorePickupConfig } from "../models/StorePickupConfig.js";
import { Coupon } from "../models/Coupon.js";
import { Campaign } from "../models/Campaign.js";
import { Gift } from "../models/Gift.js";
import { Offer } from "../models/Offer.js";
import { Order } from "../models/Order.js";

const router = express.Router();

router.use(requireAuth());
router.use(requireRole("admin"));

// ---------- Delivery Areas ----------
router.get("/delivery-areas", async (req, res) => {
  const items = await DeliveryArea.find().sort({ createdAt: -1 });
  res.json({ ok: true, data: items });
});

const deliveryAreaSchema = z.object({
  body: z.object({
    nameHe: z.string().min(2).max(120).optional(),
    nameAr: z.string().max(120).optional(),
    name: z.string().min(2).max(120).optional(),
    fee: z.number().min(0),
    isActive: z.boolean().optional(),
  }),
});

router.post("/delivery-areas", validate(deliveryAreaSchema), async (req, res) => {
  const item = await DeliveryArea.create({
    nameHe: req.validated.body.nameHe || req.validated.body.name || "",
    nameAr: req.validated.body.nameAr || "",
    name: req.validated.body.name || req.validated.body.nameHe || "",
    fee: req.validated.body.fee,
    isActive: req.validated.body.isActive ?? true,
  });
  res.status(201).json({ ok: true, data: item });
});

router.put(
  "/delivery-areas/:id",
  validate(
    z.object({
      params: z.object({ id: z.string().min(1) }),
      body: z.object({
        nameHe: z.string().min(2).max(120).optional(),
        nameAr: z.string().max(120).optional(),
        name: z.string().min(2).max(120).optional(),
        fee: z.number().min(0).optional(),
        isActive: z.boolean().optional(),
      }),
      // Note: bilingual optional fields
    }),
  ),
  async (req, res) => {
    const item = await DeliveryArea.findByIdAndUpdate(req.params.id, req.validated.body, { new: true });
    if (!item) return res.status(404).json({ ok: false, error: { code: "NOT_FOUND", message: "DeliveryArea not found" } });
    res.json({ ok: true, data: item });
  },
);

router.delete("/delivery-areas/:id", async (req, res) => {
  const item = await DeliveryArea.findByIdAndDelete(req.params.id);
  if (!item) return res.status(404).json({ ok: false, error: { code: "NOT_FOUND", message: "DeliveryArea not found" } });
  res.json({ ok: true, data: { deleted: true } });
});

// ---------- Pickup Points ----------
router.get("/pickup-points", async (req, res) => {
  const items = await PickupPoint.find().sort({ createdAt: -1 });
  res.json({ ok: true, data: items });
});

const pickupPointSchema = z.object({
  body: z.object({
    nameHe: z.string().min(2).max(160).optional(),
    nameAr: z.string().max(160).optional(),
    addressHe: z.string().min(2).max(220).optional(),
    addressAr: z.string().max(220).optional(),
    // legacy
    name: z.string().min(2).max(160).optional(),
    address: z.string().min(2).max(220).optional(),
    fee: z.number().min(0),
    isActive: z.boolean().optional(),
  }),
});

router.post("/pickup-points", validate(pickupPointSchema), async (req, res) => {
  const item = await PickupPoint.create({
    nameHe: req.validated.body.nameHe || req.validated.body.name || "",
    nameAr: req.validated.body.nameAr || "",
    addressHe: req.validated.body.addressHe || req.validated.body.address || "",
    addressAr: req.validated.body.addressAr || "",
    name: req.validated.body.name || req.validated.body.nameHe || "",
    address: req.validated.body.address || req.validated.body.addressHe || "",
    fee: req.validated.body.fee,
    isActive: req.validated.body.isActive ?? true,
  });
  res.status(201).json({ ok: true, data: item });
});

router.put(
  "/pickup-points/:id",
  validate(
    z.object({
      params: z.object({ id: z.string().min(1) }),
      body: z.object({
        nameHe: z.string().min(2).max(160).optional(),
        nameAr: z.string().max(160).optional(),
        addressHe: z.string().min(2).max(220).optional(),
        addressAr: z.string().max(220).optional(),
        // legacy
        name: z.string().min(2).max(160).optional(),
        address: z.string().min(2).max(220).optional(),
        fee: z.number().min(0).optional(),
        isActive: z.boolean().optional(),
      }),
    }),
  ),
  async (req, res) => {
    const item = await PickupPoint.findByIdAndUpdate(req.params.id, req.validated.body, { new: true });
    if (!item) return res.status(404).json({ ok: false, error: { code: "NOT_FOUND", message: "PickupPoint not found" } });
    res.json({ ok: true, data: item });
  },
);

router.delete("/pickup-points/:id", async (req, res) => {
  const item = await PickupPoint.findByIdAndDelete(req.params.id);
  if (!item) return res.status(404).json({ ok: false, error: { code: "NOT_FOUND", message: "PickupPoint not found" } });
  res.json({ ok: true, data: { deleted: true } });
});

// ---------- Store Pickup Config (single doc) ----------
router.get("/store-pickup", async (req, res) => {
  const cfg = await StorePickupConfig.findOne().sort({ createdAt: -1 });
  res.json({
    ok: true,
    data:
      cfg || {
        isEnabled: true,
        fee: 0,
        addressHe: "",
        addressAr: "",
        notesHe: "",
        notesAr: "",
        address: "",
        notes: "",
      },
  });
});

router.put(
  "/store-pickup",
  validate(
    z.object({
      body: z.object({
        isEnabled: z.boolean().optional(),
        fee: z.number().min(0).optional(),
        addressHe: z.string().max(220).optional(),
        addressAr: z.string().max(220).optional(),
        notesHe: z.string().max(800).optional(),
        notesAr: z.string().max(800).optional(),
        // legacy
        address: z.string().max(220).optional(),
        notes: z.string().max(800).optional(),
      }),
    }),
  ),
  async (req, res) => {
    const cfg = await StorePickupConfig.findOne().sort({ createdAt: -1 });
    if (!cfg) {
      const created = await StorePickupConfig.create(req.validated.body);
      return res.json({ ok: true, data: created });
    }
    Object.assign(cfg, req.validated.body);
    await cfg.save();
    return res.json({ ok: true, data: cfg });
  },
);

// ---------- Coupons ----------
router.get("/coupons", async (req, res) => {
  const items = await Coupon.find().sort({ createdAt: -1 });
  res.json({ ok: true, data: items });
});

router.post(
  "/coupons",
  validate(
    z.object({
      body: z.object({
        code: z.string().min(2).max(40),
        type: z.enum(["percent", "fixed"]),
        value: z.number().min(0),
        minOrderTotal: z.number().min(0).optional(),
        maxDiscount: z.number().min(0).nullable().optional(),
        usageLimit: z.number().min(1).nullable().optional(),
        startAt: z.string().datetime().nullable().optional(),
        endAt: z.string().datetime().nullable().optional(),
        isActive: z.boolean().optional(),
      }),
    }),
  ),
  async (req, res) => {
    const b = req.validated.body;
    const item = await Coupon.create({
      code: b.code.trim().toUpperCase(),
      type: b.type,
      value: b.value,
      minOrderTotal: b.minOrderTotal || 0,
      maxDiscount: b.maxDiscount ?? null,
      usageLimit: b.usageLimit ?? null,
      startAt: b.startAt ? new Date(b.startAt) : null,
      endAt: b.endAt ? new Date(b.endAt) : null,
      isActive: b.isActive ?? true,
    });
    res.status(201).json({ ok: true, data: item });
  },
);

router.put(
  "/coupons/:id",
  validate(
    z.object({
      params: z.object({ id: z.string().min(1) }),
      body: z.object({
        code: z.string().min(2).max(40).optional(),
        type: z.enum(["percent", "fixed"]).optional(),
        value: z.number().min(0).optional(),
        minOrderTotal: z.number().min(0).optional(),
        maxDiscount: z.number().min(0).nullable().optional(),
        usageLimit: z.number().min(1).nullable().optional(),
        startAt: z.string().datetime().nullable().optional(),
        endAt: z.string().datetime().nullable().optional(),
        isActive: z.boolean().optional(),
      }),
    }),
  ),
  async (req, res) => {
    const patch = { ...req.validated.body };
    if (patch.code) patch.code = patch.code.trim().toUpperCase();
    if ("startAt" in patch) patch.startAt = patch.startAt ? new Date(patch.startAt) : null;
    if ("endAt" in patch) patch.endAt = patch.endAt ? new Date(patch.endAt) : null;

    const item = await Coupon.findByIdAndUpdate(req.params.id, patch, { new: true });
    if (!item) return res.status(404).json({ ok: false, error: { code: "NOT_FOUND", message: "Coupon not found" } });
    res.json({ ok: true, data: item });
  },
);

router.delete("/coupons/:id", async (req, res) => {
  const item = await Coupon.findByIdAndDelete(req.params.id);
  if (!item) return res.status(404).json({ ok: false, error: { code: "NOT_FOUND", message: "Coupon not found" } });
  res.json({ ok: true, data: { deleted: true } });
});

// ---------- Campaigns ----------
router.get("/campaigns", async (req, res) => {
  const items = await Campaign.find().sort({ createdAt: -1 });
  res.json({ ok: true, data: items });
});

router.post(
  "/campaigns",
  validate(
    z.object({
      body: z.object({
        nameHe: z.string().min(2).max(160).optional(),
        nameAr: z.string().max(160).optional(),
        name: z.string().min(2).max(160).optional(),
        type: z.enum(["percent", "fixed"]),
        value: z.number().min(0),
        appliesTo: z.enum(["all", "products", "categories"]).optional(),
        productIds: z.array(z.string().min(1)).optional(),
        categoryIds: z.array(z.string().min(1)).optional(),
        startAt: z.string().datetime().nullable().optional(),
        endAt: z.string().datetime().nullable().optional(),
        isActive: z.boolean().optional(),
      }),
    }),
  ),
  async (req, res) => {
    const b = req.validated.body;
    const item = await Campaign.create({
      nameHe: b.nameHe || b.name || "",
      nameAr: b.nameAr || "",
      name: b.name || b.nameHe || "",
      type: b.type,
      value: b.value,
      appliesTo: b.appliesTo || "all",
      productIds: b.productIds || [],
      categoryIds: b.categoryIds || [],
      startAt: b.startAt ? new Date(b.startAt) : null,
      endAt: b.endAt ? new Date(b.endAt) : null,
      isActive: b.isActive ?? true,
    });
    res.status(201).json({ ok: true, data: item });
  },
);

router.put(
  "/campaigns/:id",
  validate(
    z.object({
      params: z.object({ id: z.string().min(1) }),
      body: z.object({
        nameHe: z.string().min(2).max(160).optional(),
        nameAr: z.string().max(160).optional(),
        name: z.string().min(2).max(160).optional(),
        type: z.enum(["percent", "fixed"]).optional(),
        value: z.number().min(0).optional(),
        appliesTo: z.enum(["all", "products", "categories"]).optional(),
        productIds: z.array(z.string().min(1)).optional(),
        categoryIds: z.array(z.string().min(1)).optional(),
        startAt: z.string().datetime().nullable().optional(),
        endAt: z.string().datetime().nullable().optional(),
        isActive: z.boolean().optional(),
      }),
    }),
  ),
  async (req, res) => {
    const patch = { ...req.validated.body };
    if ("startAt" in patch) patch.startAt = patch.startAt ? new Date(patch.startAt) : null;
    if ("endAt" in patch) patch.endAt = patch.endAt ? new Date(patch.endAt) : null;

    const item = await Campaign.findByIdAndUpdate(req.params.id, patch, { new: true });
    if (!item) return res.status(404).json({ ok: false, error: { code: "NOT_FOUND", message: "Campaign not found" } });
    res.json({ ok: true, data: item });
  },
);

router.delete("/campaigns/:id", async (req, res) => {
  const item = await Campaign.findByIdAndDelete(req.params.id);
  if (!item) return res.status(404).json({ ok: false, error: { code: "NOT_FOUND", message: "Campaign not found" } });
  res.json({ ok: true, data: { deleted: true } });
});

// ---------- Gifts ----------
router.get("/gifts", async (req, res) => {
  const items = await Gift.find().sort({ createdAt: -1 });
  res.json({ ok: true, data: items });
});

router.post(
  "/gifts",
  validate(
    z.object({
      body: z.object({
        nameHe: z.string().min(2).max(160).optional(),
        nameAr: z.string().max(160).optional(),
        name: z.string().min(2).max(160).optional(),
        giftProductId: z.string().min(1),
        minOrderTotal: z.number().min(0).nullable().optional(),
        requiredProductId: z.string().min(1).nullable().optional(),
        requiredCategoryId: z.string().min(1).nullable().optional(),
        startAt: z.string().datetime().nullable().optional(),
        endAt: z.string().datetime().nullable().optional(),
        isActive: z.boolean().optional(),
      }),
    }),
  ),
  async (req, res) => {
    const b = req.validated.body;
    const item = await Gift.create({
      nameHe: b.nameHe || b.name || "",
      nameAr: b.nameAr || "",
      name: b.name || b.nameHe || "",
      giftProductId: b.giftProductId,
      minOrderTotal: b.minOrderTotal ?? null,
      requiredProductId: b.requiredProductId ?? null,
      requiredCategoryId: b.requiredCategoryId ?? null,
      startAt: b.startAt ? new Date(b.startAt) : null,
      endAt: b.endAt ? new Date(b.endAt) : null,
      isActive: b.isActive ?? true,
    });
    res.status(201).json({ ok: true, data: item });
  },
);

router.put(
  "/gifts/:id",
  validate(
    z.object({
      params: z.object({ id: z.string().min(1) }),
      body: z.object({
        nameHe: z.string().min(2).max(160).optional(),
        nameAr: z.string().max(160).optional(),
        name: z.string().min(2).max(160).optional(),
        giftProductId: z.string().min(1).optional(),
        minOrderTotal: z.number().min(0).nullable().optional(),
        requiredProductId: z.string().min(1).nullable().optional(),
        requiredCategoryId: z.string().min(1).nullable().optional(),
        startAt: z.string().datetime().nullable().optional(),
        endAt: z.string().datetime().nullable().optional(),
        isActive: z.boolean().optional(),
      }),
    }),
  ),
  async (req, res) => {
    const patch = { ...req.validated.body };
    if ("startAt" in patch) patch.startAt = patch.startAt ? new Date(patch.startAt) : null;
    if ("endAt" in patch) patch.endAt = patch.endAt ? new Date(patch.endAt) : null;

    const item = await Gift.findByIdAndUpdate(req.params.id, patch, { new: true });
    if (!item) return res.status(404).json({ ok: false, error: { code: "NOT_FOUND", message: "Gift not found" } });
    res.json({ ok: true, data: item });
  },
);

router.delete("/gifts/:id", async (req, res) => {
  const item = await Gift.findByIdAndDelete(req.params.id);
  if (!item) return res.status(404).json({ ok: false, error: { code: "NOT_FOUND", message: "Gift not found" } });
  res.json({ ok: true, data: { deleted: true } });
});

// ---------- Offers (seasonal / auto) ----------
router.get("/offers", async (req, res) => {
  const items = await Offer.find().sort({ priority: 1, createdAt: -1 });
  res.json({ ok: true, data: items });
});

router.post(
  "/offers",
  validate(
    z.object({
      body: z.object({
        nameHe: z.string().min(2).max(160).optional(),
        nameAr: z.string().max(160).optional(),
        name: z.string().min(2).max(160).optional(),
        type: z.enum(["PERCENT_OFF", "FIXED_OFF", "BUY_X_GET_Y", "FREE_SHIPPING"]),
        value: z.number().min(0).optional(),
        minTotal: z.number().min(0).optional(),
        productIds: z.array(z.string().min(1)).optional(),
        categoryIds: z.array(z.string().min(1)).optional(),
        buyProductId: z.string().min(1).nullable().optional(),
        buyQty: z.number().int().min(1).optional(),
        getProductId: z.string().min(1).nullable().optional(),
        getQty: z.number().int().min(1).optional(),
        maxDiscount: z.number().min(0).optional(),
        stackable: z.boolean().optional(),
        priority: z.number().int().min(0).optional(),
        startAt: z.string().datetime().nullable().optional(),
        endAt: z.string().datetime().nullable().optional(),
        isActive: z.boolean().optional(),
      }),
    }),
  ),
  async (req, res) => {
    const b = req.validated.body;
    const item = await Offer.create({
      nameHe: b.nameHe || b.name || "",
      nameAr: b.nameAr || "",
      name: b.name || b.nameHe || "",
      type: b.type,
      value: b.value ?? 0,
      minTotal: b.minTotal ?? 0,
      productIds: b.productIds || [],
      categoryIds: b.categoryIds || [],
      buyProductId: b.buyProductId ?? null,
      buyQty: b.buyQty ?? 1,
      getProductId: b.getProductId ?? null,
      getQty: b.getQty ?? 1,
      maxDiscount: b.maxDiscount ?? 0,
      stackable: b.stackable ?? true,
      priority: b.priority ?? 100,
      startAt: b.startAt ? new Date(b.startAt) : null,
      endAt: b.endAt ? new Date(b.endAt) : null,
      isActive: b.isActive ?? true,
    });
    res.status(201).json({ ok: true, data: item });
  },
);

router.put(
  "/offers/:id",
  validate(
    z.object({
      params: z.object({ id: z.string().min(1) }),
      body: z.object({
        nameHe: z.string().min(2).max(160).optional(),
        nameAr: z.string().max(160).optional(),
        name: z.string().min(2).max(160).optional(),
        type: z.enum(["PERCENT_OFF", "FIXED_OFF", "BUY_X_GET_Y", "FREE_SHIPPING"]).optional(),
        value: z.number().min(0).optional(),
        minTotal: z.number().min(0).optional(),
        productIds: z.array(z.string().min(1)).optional(),
        categoryIds: z.array(z.string().min(1)).optional(),
        buyProductId: z.string().min(1).nullable().optional(),
        buyQty: z.number().int().min(1).optional(),
        getProductId: z.string().min(1).nullable().optional(),
        getQty: z.number().int().min(1).optional(),
        maxDiscount: z.number().min(0).optional(),
        stackable: z.boolean().optional(),
        priority: z.number().int().min(0).optional(),
        startAt: z.string().datetime().nullable().optional(),
        endAt: z.string().datetime().nullable().optional(),
        isActive: z.boolean().optional(),
      }),
    }),
  ),
  async (req, res) => {
    const patch = { ...req.validated.body };
    if ("startAt" in patch) patch.startAt = patch.startAt ? new Date(patch.startAt) : null;
    if ("endAt" in patch) patch.endAt = patch.endAt ? new Date(patch.endAt) : null;

    const item = await Offer.findByIdAndUpdate(req.params.id, patch, { new: true });
    if (!item) return res.status(404).json({ ok: false, error: { code: "NOT_FOUND", message: "Offer not found" } });
    res.json({ ok: true, data: item });
  },
);

router.delete("/offers/:id", async (req, res) => {
  const item = await Offer.findByIdAndDelete(req.params.id);
  if (!item) return res.status(404).json({ ok: false, error: { code: "NOT_FOUND", message: "Offer not found" } });
  res.json({ ok: true, data: { deleted: true } });
});

// ---------- Orders (admin view) ----------
router.get("/orders", async (req, res) => {
  const items = await Order.find().sort({ createdAt: -1 }).limit(200);
  res.json({ ok: true, data: items });
});

router.put(
  "/orders/:id/status",
  validate(
    z.object({
      params: z.object({ id: z.string().min(1) }),
      body: z.object({
        status: z.enum(["pending_payment", "pending_cod", "paid", "confirmed", "shipped", "delivered", "cancelled"]),
      }),
    }),
  ),
  async (req, res) => {
    const item = await Order.findByIdAndUpdate(req.params.id, { status: req.validated.body.status }, { new: true });
    if (!item) return res.status(404).json({ ok: false, error: { code: "NOT_FOUND", message: "Order not found" } });
    res.json({ ok: true, data: item });
  },
);

export default router;
