// src/services/stripe.service.js
import Stripe from "stripe";

let stripeClient = null;

function makeErr(statusCode, code, message) {
  const err = new Error(message);
  err.statusCode = statusCode;
  err.code = code;
  return err;
}

function getStripe() {
  if (stripeClient) return stripeClient;

  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) throw makeErr(500, "STRIPE_NOT_CONFIGURED", "STRIPE_SECRET_KEY is required");

  stripeClient = new Stripe(key, { apiVersion: "2024-06-20" });
  return stripeClient;
}

/**
 * Money helpers (ILS major -> minor)
 */
function toMinorUnits(major) {
  const n = Number(major || 0);
  return Math.max(0, Math.round((n + Number.EPSILON) * 100));
}

function fromMinorUnits(minor) {
  const n = Number(minor || 0);
  return Math.round((n + Number.EPSILON)) / 100;
}

function safeLang(lang) {
  const v = String(lang || "he").toLowerCase();
  return v === "ar" ? "ar" : "he";
}

function pickTitle(it, lang) {
  const l = safeLang(lang);
  if (l === "ar") return it?.titleAr || it?.titleHe || it?.title || "Item";
  return it?.titleHe || it?.titleAr || it?.title || "Item";
}

/**
 * Allocate order-level discount across items proportionally,
 * to keep Stripe total EXACTLY equal to quote.total.
 *
 * We allocate in minor units to avoid floating drift.
 */
function allocateDiscountAcrossItems({ linesMinor, totalDiscountMinor }) {
  if (totalDiscountMinor <= 0) {
    return { perLineDiscountMinor: linesMinor.map(() => 0), remainderMinor: 0 };
  }

  const subtotalMinor = linesMinor.reduce((a, b) => a + b, 0);
  if (subtotalMinor <= 0) {
    return { perLineDiscountMinor: linesMinor.map(() => 0), remainderMinor: totalDiscountMinor };
  }

  const raw = linesMinor.map((line) => (totalDiscountMinor * line) / subtotalMinor);
  const floors = raw.map((x) => Math.floor(x));
  let used = floors.reduce((a, b) => a + b, 0);
  let remainder = totalDiscountMinor - used;

  const fractional = raw.map((x, idx) => ({ idx, frac: x - Math.floor(x) }));
  fractional.sort((a, b) => b.frac - a.frac);

  const perLineDiscountMinor = [...floors];
  for (let i = 0; i < fractional.length && remainder > 0; i++) {
    perLineDiscountMinor[fractional[i].idx] += 1;
    remainder -= 1;
  }

  return { perLineDiscountMinor, remainderMinor: remainder };
}

/**
 * ✅ Creates Stripe Checkout session from quote truth
 * Ensures:
 * sum(line_items) == quote.total
 *
 * Expected quote shape:
 * {
 *   subtotal,
 *   shippingFee,
 *   discounts: { coupon:{code,amount}, campaign:{amount}, offer:{amount} },
 *   total,
 *   items:[{ productId, qty, unitPrice, lineTotal, titleHe, titleAr }]
 * }
 */
export async function createCheckoutSession({ orderId, quote, lang, idempotencyKey }) {
  const stripe = getStripe();

  if (!orderId) throw makeErr(400, "MISSING_ORDER_ID", "orderId is required");
  if (!quote || !Array.isArray(quote.items) || quote.items.length === 0) {
    throw makeErr(400, "INVALID_QUOTE", "quote.items is required");
  }

  const currency = String(process.env.STRIPE_CURRENCY || "ils").toLowerCase();
  const L = safeLang(lang);

  const subtotalMinor = toMinorUnits(quote.subtotal);
  const shippingMinor = toMinorUnits(quote.shippingFee);
  const totalMinor = toMinorUnits(quote.total);

  if (totalMinor <= 0) {
    throw makeErr(400, "INVALID_TOTAL", "quote.total must be > 0");
  }

  const totalBeforeShippingMinor = Math.max(0, totalMinor - shippingMinor);
  const totalDiscountMinor = Math.max(0, subtotalMinor - totalBeforeShippingMinor);

  const linesMinor = quote.items.map((it) => {
    const qty = Math.max(1, Math.min(999, Number(it.qty || 1)));
    const unitMinor = toMinorUnits(it.unitPrice);
    return unitMinor * qty;
  });

  const { perLineDiscountMinor } = allocateDiscountAcrossItems({
    linesMinor,
    totalDiscountMinor,
  });

  const line_items = [];

  for (let i = 0; i < quote.items.length; i++) {
    const it = quote.items[i];
    const qty = Math.max(1, Math.min(999, Number(it.qty || 1)));

    const originalLineMinor = linesMinor[i];
    const discountMinor = Math.min(perLineDiscountMinor[i] || 0, originalLineMinor);
    const adjustedLineMinor = Math.max(0, originalLineMinor - discountMinor);

    const unitMinor = Math.floor(adjustedLineMinor / qty);
    const remainder = adjustedLineMinor - unitMinor * qty;

    const name = pickTitle(it, L);

    if (unitMinor > 0) {
      line_items.push({
        price_data: {
          currency,
          product_data: { name },
          unit_amount: unitMinor,
        },
        quantity: qty,
      });
    }

    if (remainder > 0) {
      line_items.push({
        price_data: {
          currency,
          product_data: { name: `${name} (adj)` },
          unit_amount: remainder,
        },
        quantity: 1,
      });
    }
  }

  // Add shipping as separate line item
  if (shippingMinor > 0) {
    const shippingLabel = L === "ar" ? "الشحن" : "משלוח";
    line_items.push({
      price_data: {
        currency,
        product_data: { name: shippingLabel },
        unit_amount: shippingMinor,
      },
      quantity: 1,
    });
  }

  // If everything got discounted to zero and shipping is zero => Stripe would reject empty line_items
  if (line_items.length === 0) {
    const label = L === "ar" ? "إجمالي الطلب" : "סך ההזמנה";
    line_items.push({
      price_data: {
        currency,
        product_data: { name: label },
        unit_amount: totalMinor,
      },
      quantity: 1,
    });
  }

  // Ensure sum(line_items) === totalMinor
  const sumMinor = line_items.reduce((acc, li) => {
    const unit = Number(li?.price_data?.unit_amount || 0);
    const q = Number(li?.quantity || 1);
    return acc + unit * q;
  }, 0);

  const diff = totalMinor - sumMinor;

  if (diff !== 0) {
    if (diff < 0) {
      throw makeErr(
        500,
        "STRIPE_TOTAL_MISMATCH",
        `Stripe line items exceed quote.total (diff=${fromMinorUnits(diff)})`
      );
    }

    const adjLabel = L === "ar" ? "تسوية" : "התאמה";
    line_items.push({
      price_data: {
        currency,
        product_data: { name: adjLabel },
        unit_amount: diff,
      },
      quantity: 1,
    });
  }

  const base = process.env.CLIENT_URL || process.env.FRONTEND_URL || "http://localhost:5173";
  const successPath = process.env.STRIPE_SUCCESS_PATH || "/checkout/success";
  const cancelPath = process.env.STRIPE_CANCEL_PATH || "/checkout/cancel";

  const metadata = {
    orderId: String(orderId),
    lang: L,
    total: String(quote.total),
    couponCode: String(quote?.discounts?.coupon?.code || ""),
  };

  const session = await stripe.checkout.sessions.create(
    {
      mode: "payment",
      line_items,
      success_url: `${base}${successPath}?orderId=${orderId}`,
      cancel_url: `${base}${cancelPath}?orderId=${orderId}`,
      metadata,
    },
    idempotencyKey ? { idempotencyKey: String(idempotencyKey) } : undefined
  );

  return session;
}

/**
 * ✅ Webhook constructor (RAW BODY REQUIRED)
 */
export function constructWebhookEvent(rawBody, signature) {
  const stripe = getStripe();
  const secret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!secret) throw makeErr(500, "STRIPE_WEBHOOK_NOT_CONFIGURED", "STRIPE_WEBHOOK_SECRET is required");

  return stripe.webhooks.constructEvent(rawBody, signature, secret);
}
