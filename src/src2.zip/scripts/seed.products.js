// src/scripts/seed.products.js
// Idempotent seed script - safe to re-run (uses upserts / bulkWrite)
import "dotenv/config";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import { toMinorUnits } from "../utils/stripe.js";

// ---- Model imports (robust fallback for default/named exports) ----
import * as UserMod from "../models/User.js";
import * as CategoryMod from "../models/Category.js";
import * as ProductMod from "../models/Product.js";
import * as VariantMod from "../models/Variant.js";
import * as CouponMod from "../models/Coupon.js";
import * as ShippingMethodMod from "../models/ShippingMethod.js";
import * as DeliveryAreaMod from "../models/DeliveryArea.js";
import * as PickupPointMod from "../models/PickupPoint.js";
import * as StorePickupConfigMod from "../models/StorePickupConfig.js";

function pickModel(mod, fallbackName) {
  return mod?.default ?? mod?.[fallbackName] ?? mod?.model ?? null;
}

const User = pickModel(UserMod, "User");
const Category = pickModel(CategoryMod, "Category");
const Product = pickModel(ProductMod, "Product");
const Variant = pickModel(VariantMod, "Variant");
const Coupon = pickModel(CouponMod, "Coupon");
const ShippingMethod = pickModel(ShippingMethodMod, "ShippingMethod");
const DeliveryArea = pickModel(DeliveryAreaMod, "DeliveryArea");
const PickupPoint = pickModel(PickupPointMod, "PickupPoint");
const StorePickupConfig = pickModel(StorePickupConfigMod, "StorePickupConfig");

if (!User || !Category || !Product || !Variant) {
  throw new Error(
    "Missing required models. Ensure these exist: User, Category, Product, Variant.",
  );
}

// ---- Connection ----
function getMongoUri() {
  return process.env.MONGO_URI || process.env.MONGODB_URI || process.env.DATABASE_URL || "";
}

async function connectDb() {
  const uri = getMongoUri();
  if (!uri) {
    throw new Error("Missing Mongo URI. Set MONGO_URI (or MONGODB_URI / DATABASE_URL).");
  }

  await mongoose.connect(uri, {
    autoIndex: false,
    maxPoolSize: 10,
    serverSelectionTimeoutMS: 10_000,
  });
}

// ---- Helpers ----
const now = () => new Date();
const CURRENCY = "ILS"; // server default

// money() returns minor units (agorot) for DB storage
function money(majorUnits) {
  return toMinorUnits(majorUnits, CURRENCY);
}

// IMPORTANT: Category.slug must be URL-friendly: [-a-z0-9]+
function toSlugAscii(s) {
  return String(s)
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function makeCat({
  key,
  nameHe,
  nameAr,
  slug,
  parentKey = null,
  sortOrder = 0,
  isActive = true,
  image = "",
}) {
  return {
    key,
    nameHe,
    nameAr,
    slug: slug || toSlugAscii(key),
    parentKey,
    sortOrder,
    isActive,
    image: image || "",
  };
}

/**
 * Build category tree and upsert using upserts by fullSlug (unique index with partialFilter isDeleted:false).
 * Category supports soft delete (isDeleted/deletedAt).
 */
async function upsertCategoriesTree(categoriesInput) {
  const mapByKey = new Map(categoriesInput.map((c) => [c.key, c]));
  const insertedByKey = new Map();

  function computePathKeys(key) {
    const out = [];
    let cur = mapByKey.get(key);
    while (cur) {
      out.unshift(cur.key);
      cur = cur.parentKey ? mapByKey.get(cur.parentKey) : null;
    }
    return out;
  }

  // Sort by depth so parents come first
  const sorted = [...categoriesInput].sort((a, b) => {
    const da = computePathKeys(a.key).length;
    const db = computePathKeys(b.key).length;
    return da - db;
  });

  for (const c of sorted) {
    const parent = c.parentKey ? insertedByKey.get(c.parentKey) : null;

    const level = parent ? (parent.level ?? 0) + 1 : 0;
    const fullSlug = parent ? `${parent.fullSlug}/${c.slug}` : c.slug;
    const ancestors = parent ? [...(parent.ancestors ?? []), parent._id] : [];

    const filter = { fullSlug };
    const update = {
      $set: {
        nameHe: c.nameHe,
        nameAr: c.nameAr,
        slug: c.slug,
        fullSlug,
        parentId: parent?._id ?? null,
        ancestors,
        level,
        sortOrder: c.sortOrder ?? 0,
        isActive: c.isActive ?? true,
        image: c.image ?? "",
        // soft-delete reset (supported in Category schema)
        isDeleted: false,
        deletedAt: null,
      },
      $setOnInsert: {
        createdAt: now(),
      },
    };

    const result = await Category.findOneAndUpdate(filter, update, {
      upsert: true,
      new: true,
      setDefaultsOnInsert: true,
    });

    insertedByKey.set(c.key, result);
  }

  return insertedByKey;
}

/**
 * Upsert products by slug (unique partial index where isDeleted:false).
 * Product supports soft delete.
 * Returns Map<slug, { doc, variants }>
 */
async function upsertProducts(products) {
  const productsBySlug = new Map();

  for (const p of products) {
    const filter = { slug: p.slug, isDeleted: { $ne: true } };
    const update = {
      $set: {
        nameHe: p.nameHe,
        nameAr: p.nameAr,
        descriptionHe: p.descriptionHe,
        descriptionAr: p.descriptionAr,
        brand: p.brand,
        categoryIds: p.categoryIds,
        images: p.images,
        slug: p.slug,
        isActive: p.isActive ?? true,
        inStock: p.inStock ?? true,
        attributes: p.attributes ?? {},
        // soft-delete reset (supported in Product schema)
        isDeleted: false,
        deletedAt: null,
      },
      $setOnInsert: {
        reviewsCount: 0,
        ratingAvg: null,
        createdAt: now(),
      },
    };

    const result = await Product.findOneAndUpdate(filter, update, {
      upsert: true,
      new: true,
      setDefaultsOnInsert: true,
    });

    productsBySlug.set(p.slug, { doc: result, variants: p.variants ?? [] });
  }

  return productsBySlug;
}

/**
 * Upsert variants by sku (unique partial index where isDeleted:false).
 * Variant supports soft delete.
 */
async function upsertVariants(productsBySlug) {
  const ops = [];

  for (const [, { doc, variants }] of productsBySlug) {
    for (const v of variants) {
      ops.push({
        updateOne: {
          filter: { sku: v.sku, isDeleted: { $ne: true } },
          update: {
            $set: {
              productId: doc._id,
              sku: v.sku,
              barcode: v.barcode || null,
              price: money(v.price), // Variant.price is minor units in server schema
              currency: (v.currency || CURRENCY).toUpperCase(),
              stock: v.stock ?? 0,
              stockReserved: 0,
              options: v.options ?? {},
              sortOrder: v.sortOrder ?? 0,
              // soft-delete reset (supported in Variant schema)
              isDeleted: false,
              deletedAt: null,
            },
            $setOnInsert: {
              createdAt: now(),
            },
          },
          upsert: true,
        },
      });
    }
  }

  if (ops.length > 0) {
    await Variant.bulkWrite(ops, { ordered: false });
  }

  return ops.length;
}

/**
 * Upsert coupons by code (unique).
 * Coupon model does NOT support isDeleted/deletedAt in this server.
 * Values:
 * - percent: value = 0..100
 * - fixed: value = minor units
 * - minOrderTotal = minor units
 */
async function upsertCoupons(coupons) {
  if (!Coupon) return 0;

  const ops = coupons.map((c) => ({
    updateOne: {
      filter: { code: c.code.toUpperCase() },
      update: {
        $set: {
          code: c.code.toUpperCase(),
          type: c.type,
          value: c.value,
          currency: (c.currency || CURRENCY).toUpperCase(),
          minOrderTotal: c.minOrderTotal ?? 0,
          maxUsesTotal: c.maxUsesTotal ?? null,
          maxUsesPerUser: c.maxUsesPerUser ?? null,
          allowedUserIds: c.allowedUserIds ?? [],
          allowedRoles: c.allowedRoles ?? [],
          startsAt: c.startsAt ?? null,
          endsAt: c.endsAt ?? null,
          isActive: c.isActive ?? true,
        },
        $setOnInsert: {
          usesTotal: 0,
          createdAt: now(),
        },
      },
      upsert: true,
    },
  }));

  if (ops.length > 0) {
    await Coupon.bulkWrite(ops, { ordered: false });
  }

  return ops.length;
}

/**
 * Upsert shipping methods by code (unique).
 * ShippingMethod model does NOT support soft delete in this server.
 * All prices are minor units.
 */
async function upsertShippingMethods(methods) {
  if (!ShippingMethod) {
    console.warn("⚠️ ShippingMethod model not loaded, skipping");
    return 0;
  }

  for (const m of methods) {
    const filter = { code: m.code.toUpperCase() };
    const update = {
      $set: {
        code: m.code.toUpperCase(),
        nameHe: m.nameHe,
        nameAr: m.nameAr,
        descHe: m.descHe ?? "",
        descAr: m.descAr ?? "",
        basePrice: m.basePrice ?? 0,
        freeAbove: m.freeAbove ?? null,
        minSubtotal: m.minSubtotal ?? null,
        maxSubtotal: m.maxSubtotal ?? null,
        cities: m.cities ?? [],
        sort: m.sort ?? 100,
        isActive: m.isActive ?? true,
      },
      $setOnInsert: {
        createdAt: now(),
      },
    };

    await ShippingMethod.findOneAndUpdate(filter, update, {
      upsert: true,
      new: true,
      setDefaultsOnInsert: true,
    });
  }

  return methods.length;
}

/**
 * Upsert delivery areas by code (unique).
 * DeliveryArea model does NOT support soft delete in this server.
 */
async function upsertDeliveryAreas(areas) {
  if (!DeliveryArea) {
    console.warn("⚠️ DeliveryArea model not loaded, skipping");
    return new Map();
  }

  const areasByCode = new Map();

  for (const a of areas) {
    const filter = { code: a.code.toUpperCase() };
    const update = {
      $set: {
        code: a.code.toUpperCase(),
        nameHe: a.nameHe,
        nameAr: a.nameAr,
        deliveryEnabled: a.deliveryEnabled ?? true,
        deliveryPriceMinor: a.deliveryPriceMinor ?? 0,
        pickupPointsEnabled: a.pickupPointsEnabled ?? true,
        freeDeliveryAboveMinor: a.freeDeliveryAboveMinor ?? null,
        minSubtotalMinor: a.minSubtotalMinor ?? null,
        sort: a.sort ?? 100,
        isActive: a.isActive ?? true,
      },
      $setOnInsert: {
        createdAt: now(),
      },
    };

    const result = await DeliveryArea.findOneAndUpdate(filter, update, {
      upsert: true,
      new: true,
      setDefaultsOnInsert: true,
    });

    areasByCode.set(a.code.toUpperCase(), result);
  }

  return areasByCode;
}

/**
 * Upsert pickup points (unique by areaId + nameHe).
 * PickupPoint model does NOT support soft delete in this server.
 */
async function upsertPickupPoints(points, areasByCode) {
  if (!PickupPoint) {
    console.warn("⚠️ PickupPoint model not loaded, skipping");
    return 0;
  }

  let count = 0;

  for (const p of points) {
    const area = areasByCode.get(p.areaCode?.toUpperCase());
    if (!area) {
      console.warn(`⚠️ Area not found for pickup point: ${p.nameHe} (areaCode: ${p.areaCode})`);
      continue;
    }

    const filter = { areaId: area._id, nameHe: p.nameHe };
    const update = {
      $set: {
        areaId: area._id,
        nameHe: p.nameHe,
        nameAr: p.nameAr || "",
        addressHe: p.addressHe,
        addressAr: p.addressAr || "",
        notesHe: p.notesHe ?? "",
        notesAr: p.notesAr ?? "",
        hoursHe: p.hoursHe ?? "",
        hoursAr: p.hoursAr ?? "",
        feeMinor: p.feeMinor ?? 0,
        phone: p.phone ?? "",
        coordinates: p.coordinates ?? { lat: null, lng: null },
        sort: p.sort ?? 100,
        isActive: p.isActive ?? true,
      },
      $setOnInsert: {
        createdAt: now(),
      },
    };

    await PickupPoint.findOneAndUpdate(filter, update, {
      upsert: true,
      new: true,
      setDefaultsOnInsert: true,
    });

    count++;
  }

  return count;
}

/**
 * Upsert store pickup config (singleton by configKey).
 * StorePickupConfig model does NOT support soft delete in this server.
 */
async function upsertStorePickupConfig(config) {
  if (!StorePickupConfig) {
    console.warn("⚠️ StorePickupConfig model not loaded, skipping");
    return false;
  }

  const filter = { configKey: "main" };
  const update = {
    $set: {
      configKey: "main",
      nameHe: config.nameHe ?? "החנות הראשית",
      nameAr: config.nameAr ?? "المتجر الرئيسي",
      addressHe: config.addressHe ?? "",
      addressAr: config.addressAr ?? "",
      hoursHe: config.hoursHe ?? "",
      hoursAr: config.hoursAr ?? "",
      notesHe: config.notesHe ?? "",
      notesAr: config.notesAr ?? "",
      phone: config.phone ?? "",
      coordinates: config.coordinates ?? { lat: null, lng: null },
      isActive: config.isActive ?? true,
    },
    $setOnInsert: {
      createdAt: now(),
    },
  };

  await StorePickupConfig.findOneAndUpdate(filter, update, {
    upsert: true,
    new: true,
    setDefaultsOnInsert: true,
  });

  return true;
}

/**
 * Upsert admin user by emailLower (unique index).
 * User supports fields used here.
 */
async function upsertAdminUser(email, password) {
  const emailLower = String(email).toLowerCase().trim();
  const passwordHash = await bcrypt.hash(password, 10);

  const filter = { emailLower };
  const update = {
    $set: {
      email: email.trim(),
      emailLower,
      passwordHash,
      roles: ["admin"],
      isActive: true,
    },
    $setOnInsert: {
      addresses: [],
      segments: [],
      permissions: [],
      tokenVersion: 0,
      emailVerified: false,
      failedLoginCount: 0,
      loginAttempts: 0,
      createdAt: now(),
    },
  };

  await User.findOneAndUpdate(filter, update, {
    upsert: true,
    setDefaultsOnInsert: true,
  });

  return emailLower;
}

// =====================================================
// 🖼️ IMAGE COLLECTIONS - Professional Barber Equipment
// =====================================================

const IMAGES = {
  categories: {
    clippers:
      "https://images.unsplash.com/photo-1621607512022-6aecc4fed814?w=800&h=600&fit=crop&q=80",
    clippers_wired:
      "https://images.unsplash.com/photo-1582095133179-bfd08e2fc6b3?w=800&h=600&fit=crop&q=80",
    clippers_wireless:
      "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=800&h=600&fit=crop&q=80",
    trimmers:
      "https://images.unsplash.com/photo-1621605815971-fbc98d665033?w=800&h=600&fit=crop&q=80",
    trimmers_zero:
      "https://images.unsplash.com/photo-1599351431202-1e0f0137899a?w=800&h=600&fit=crop&q=80",
    trimmers_nose:
      "https://images.unsplash.com/photo-1626808642875-0aa545482dfb?w=800&h=600&fit=crop&q=80",
    shavers:
      "https://images.unsplash.com/photo-1621607505837-4c5fe8a63d63?w=800&h=600&fit=crop&q=80",
    blades:
      "https://images.unsplash.com/photo-1585747860715-2ba37e788b70?w=800&h=600&fit=crop&q=80",
    care: "https://images.unsplash.com/photo-1598524374912-6b0b0bdb9dd6?w=800&h=600&fit=crop&q=80",
    care_oils:
      "https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?w=800&h=600&fit=crop&q=80",
    care_balms:
      "https://images.unsplash.com/photo-1626808642875-0aa545482dfb?w=800&h=600&fit=crop&q=80",
    accessories:
      "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=800&h=600&fit=crop&q=80",
    accessories_combs:
      "https://images.unsplash.com/photo-1527799820374-dcf8d9d4a388?w=800&h=600&fit=crop&q=80",
    accessories_cap:
      "https://images.unsplash.com/photo-1585747860715-2ba37e788b70?w=800&h=600&fit=crop&q=80",
  },
  products: {
    wahlMagicClip: [
      "https://images.unsplash.com/photo-1621607512022-6aecc4fed814?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1582095133179-bfd08e2fc6b3?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=800&h=600&fit=crop&q=80",
    ],
    andisTOutliner: [
      "https://images.unsplash.com/photo-1621605815971-fbc98d665033?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1599351431202-1e0f0137899a?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1622286342621-4bd786c2447c?w=800&h=600&fit=crop&q=80",
    ],
    babylissFoil: [
      "https://images.unsplash.com/photo-1621607505837-4c5fe8a63d63?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1626808642875-0aa545482dfb?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1585747860715-2ba37e788b70?w=800&h=600&fit=crop&q=80",
    ],
    bladeSet: [
      "https://images.unsplash.com/photo-1585747860715-2ba37e788b70?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1621607512022-6aecc4fed814?w=800&h=600&fit=crop&q=80",
    ],
    beardOil: [
      "https://images.unsplash.com/photo-1598524374912-6b0b0bdb9dd6?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1626808642875-0aa545482dfb?w=800&h=600&fit=crop&q=80",
    ],
    carbonComb: [
      "https://images.unsplash.com/photo-1527799820374-dcf8d9d4a388?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=800&h=600&fit=crop&q=80",
    ],
    osterClassic: [
      "https://images.unsplash.com/photo-1582095133179-bfd08e2fc6b3?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1621607512022-6aecc4fed814?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=800&h=600&fit=crop&q=80",
    ],
    moserChromini: [
      "https://images.unsplash.com/photo-1599351431202-1e0f0137899a?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1621605815971-fbc98d665033?w=800&h=600&fit=crop&q=80",
    ],
    gammaErgo: [
      "https://images.unsplash.com/photo-1621607512022-6aecc4fed814?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1582095133179-bfd08e2fc6b3?w=800&h=600&fit=crop&q=80",
    ],
    noseTrimmer: [
      "https://images.unsplash.com/photo-1626808642875-0aa545482dfb?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1621605815971-fbc98d665033?w=800&h=600&fit=crop&q=80",
    ],
    beardBalm: [
      "https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1598524374912-6b0b0bdb9dd6?w=800&h=600&fit=crop&q=80",
    ],
    barberCape: [
      "https://images.unsplash.com/photo-1585747860715-2ba37e788b70?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=800&h=600&fit=crop&q=80",
    ],
    clipperOil: [
      "https://images.unsplash.com/photo-1598524374912-6b0b0bdb9dd6?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1621607512022-6aecc4fed814?w=800&h=600&fit=crop&q=80",
    ],
    stylingBrush: [
      "https://images.unsplash.com/photo-1527799820374-dcf8d9d4a388?w=800&h=600&fit=crop&q=80",
      "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=800&h=600&fit=crop&q=80",
    ],
  },
};

// ---- Seed Data Generators ----
function seedCategories() {
  return [
    makeCat({ key: "clippers", nameHe: "מכונות תספורת", nameAr: "ماكينات قص", slug: "clippers", sortOrder: 10, image: IMAGES.categories.clippers }),
    makeCat({ key: "trimmers", nameHe: "טרימרים", nameAr: "تريمر", slug: "trimmers", sortOrder: 20, image: IMAGES.categories.trimmers }),
    makeCat({ key: "shavers", nameHe: "מכונות גילוח", nameAr: "ماكينات حلاقة", slug: "shavers", sortOrder: 30, image: IMAGES.categories.shavers }),
    makeCat({ key: "blades", nameHe: "סכינים וראשים", nameAr: "شفرات ورؤوس", slug: "blades", sortOrder: 40, image: IMAGES.categories.blades }),
    makeCat({ key: "care", nameHe: "טיפוח זקן", nameAr: "العناية باللحية", slug: "beard-care", sortOrder: 50, image: IMAGES.categories.care }),
    makeCat({ key: "accessories", nameHe: "אביזרים", nameAr: "اكسسوارات", slug: "accessories", sortOrder: 60, image: IMAGES.categories.accessories }),

    makeCat({ key: "clippers_wired", parentKey: "clippers", nameHe: "חוטי", nameAr: "سلكي", slug: "wired", sortOrder: 11, image: IMAGES.categories.clippers_wired }),
    makeCat({ key: "clippers_wireless", parentKey: "clippers", nameHe: "אלחוטי", nameAr: "لاسلكي", slug: "wireless", sortOrder: 12, image: IMAGES.categories.clippers_wireless }),
    makeCat({ key: "trimmers_zero", parentKey: "trimmers", nameHe: "אפס/דיוק", nameAr: "زيرو/دقة", slug: "zero", sortOrder: 21, image: IMAGES.categories.trimmers_zero }),
    makeCat({ key: "trimmers_nose", parentKey: "trimmers", nameHe: "אף ואוזניים", nameAr: "أنف وأذن", slug: "nose-ear", sortOrder: 22, image: IMAGES.categories.trimmers_nose }),
    makeCat({ key: "care_oils", parentKey: "care", nameHe: "שמנים", nameAr: "زيوت", slug: "oils", sortOrder: 51, image: IMAGES.categories.care_oils }),
    makeCat({ key: "care_balms", parentKey: "care", nameHe: "בלמים/קרם", nameAr: "بلسم/كريم", slug: "balms", sortOrder: 52, image: IMAGES.categories.care_balms }),
    makeCat({ key: "accessories_combs", parentKey: "accessories", nameHe: "מסרקים", nameAr: "أمشاط", slug: "combs", sortOrder: 61, image: IMAGES.categories.accessories_combs }),
    makeCat({ key: "accessories_cap", parentKey: "accessories", nameHe: "גלימות", nameAr: "أغطية/مراييل", slug: "capes", sortOrder: 62, image: IMAGES.categories.accessories_cap }),
  ];
}

/**
 * Deterministic inStock mix: every 3rd product is out of stock.
 */
function withStockFlag(products) {
  return products.map((p, i) => {
    const inStock = i % 3 !== 0;
    const variants = (p.variants ?? []).map((v) => {
      const baseQty = Number(v.stock ?? 0);
      return { ...v, stock: inStock ? Math.max(0, baseQty) : 0 };
    });
    return { ...p, inStock, variants };
  });
}

function seedProducts({ catsByKey }) {
  const catId = (k) => catsByKey.get(k)?._id;

  const base = [
    {
      nameHe: "Wahl Magic Clip אלחוטי",
      nameAr: "Wahl Magic Clip لاسلكي",
      descriptionHe: "מכונת תספורת אלחוטית מקצועית עם מנוע חזק וסוללה עמידה. מושלמת לפייד ותספורות מדויקות.",
      descriptionAr: "ماكينة قص احترافية لاسلكية بمحرك قوي وبطارية طويلة الأمد. مثالية للفيد والقصات الدقيقة.",
      brand: "Wahl",
      categoryIds: [catId("clippers_wireless")].filter(Boolean),
      images: IMAGES.products.wahlMagicClip,
      slug: "wahl-magic-clip",
      isActive: true,
      attributes: { type: "clipper", power: "wireless" },
      variants: [
        { sku: "WAHL-MAGIC-STD", price: 499, options: { kit: "standard" }, stock: 25 },
        { sku: "WAHL-MAGIC-PRO", price: 549, options: { kit: "pro" }, stock: 18 },
      ],
    },
    // ... (باقي المنتجات كما هي)
  ];

  return withStockFlag(base);
}

function seedCoupons() {
  return [
    {
      code: "WELCOME10",
      type: "percent",
      value: 10, // 10%
      currency: CURRENCY,
      minOrderTotal: money(150),
      maxUsesTotal: 200,
      maxUsesPerUser: 1,
      startsAt: now(),
      endsAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 90),
      isActive: true,
    },
    {
      code: "FREESHIP",
      type: "fixed",
      value: money(30), // fixed discount in minor units
      currency: CURRENCY,
      minOrderTotal: money(250),
      maxUsesTotal: 500,
      maxUsesPerUser: null,
      startsAt: now(),
      endsAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 120),
      isActive: true,
    },
  ];
}

function seedShippingMethods() {
  return [
    {
      code: "SELF_PICKUP",
      nameHe: "איסוף עצמי",
      nameAr: "استلام ذاتي",
      descHe: "איסוף מהחנות ללא עלות",
      descAr: "استلام من المتجر بدون تكلفة",
      basePrice: 0,
      freeAbove: null,
      sort: 10,
      isActive: true,
    },
    {
      code: "STANDARD",
      nameHe: "משלוח רגיל",
      nameAr: "توصيل عادي",
      descHe: "משלוח תוך 3-5 ימי עסקים",
      descAr: "التوصيل خلال 3-5 أيام عمل",
      basePrice: money(25),
      freeAbove: money(300),
      sort: 20,
      isActive: true,
    },
  ];
}

function seedDeliveryAreas() {
  return [
    {
      code: "TEL_AVIV",
      nameHe: "תל אביב והסביבה",
      nameAr: "تل أبيب والمنطقة",
      deliveryEnabled: true,
      deliveryPriceMinor: money(20),
      pickupPointsEnabled: true,
      freeDeliveryAboveMinor: money(200),
      minSubtotalMinor: null,
      sort: 10,
      isActive: true,
    },
  ];
}

function seedPickupPoints() {
  return [
    {
      areaCode: "TEL_AVIV",
      nameHe: "נקודת איסוף דיזנגוף סנטר",
      nameAr: "نقطة استلام ديزنغوف سنتر",
      addressHe: "דיזנגוף 50, תל אביב",
      addressAr: "ديزنغوف 50، تل أبيب",
      hoursHe: "א'-ה' 09:00-21:00, ו' 09:00-14:00",
      hoursAr: "أحد-خميس 09:00-21:00، جمعة 09:00-14:00",
      notesHe: "קומה 2, ליד הקולנוע",
      notesAr: "الطابق 2، بجانب السينما",
      feeMinor: 0,
      phone: "03-1234567",
      coordinates: { lat: 32.0775, lng: 34.7747 },
      sort: 10,
      isActive: true,
    },
  ];
}

function seedStorePickupConfig() {
  return {
    nameHe: "חנות BarberPro הראשית",
    nameAr: "متجر BarberPro الرئيسي",
    addressHe: "רחוב הרצל 100, תל אביב",
    addressAr: "شارع هرتسل 100، تل أبيב",
    hoursHe: "א'-ה' 09:00-19:00, ו' 09:00-13:00",
    hoursAr: "أحد-خميس 09:00-19:00، جمعة 09:00-13:00",
    notesHe: "חניה חינם ללקוחות",
    notesAr: "موقف مجاني للعملاء",
    phone: "03-9876543",
    coordinates: { lat: 32.0853, lng: 34.7818 },
    isActive: true,
  };
}

// ---- Main ----
async function main() {
  await connectDb();
  console.log("✅ Mongo connected");

  const catsByKey = await upsertCategoriesTree(seedCategories());
  console.log(`✅ Categories upserted: ${catsByKey.size}`);

  const shippingCount = await upsertShippingMethods(seedShippingMethods());
  console.log(`✅ ShippingMethods upserted: ${shippingCount}`);

  const areasByCode = await upsertDeliveryAreas(seedDeliveryAreas());
  console.log(`✅ DeliveryAreas upserted: ${areasByCode.size}`);

  const pickupPointCount = await upsertPickupPoints(seedPickupPoints(), areasByCode);
  console.log(`✅ PickupPoints upserted: ${pickupPointCount}`);

  const storePickupOk = await upsertStorePickupConfig(seedStorePickupConfig());
  console.log(`✅ StorePickupConfig upserted: ${storePickupOk}`);

  const couponCount = await upsertCoupons(seedCoupons());
  console.log(`✅ Coupons upserted: ${couponCount}`);

  const productsBySlug = await upsertProducts(seedProducts({ catsByKey }));
  console.log(`✅ Products upserted: ${productsBySlug.size}`);

  const variantCount = await upsertVariants(productsBySlug);
  console.log(`✅ Variants upserted: ${variantCount}`);

  const adminEmail = process.env.SEED_ADMIN_EMAIL || "admin@local.test";
  const adminPass = process.env.SEED_ADMIN_PASSWORD || "Admin12345!";
  const adminCreated = await upsertAdminUser(adminEmail, adminPass);
  console.log("✅ Admin user upserted:", adminCreated);

  console.log("\n🎉 SEED COMPLETE (idempotent - safe to re-run)\n");
}

main()
  .then(async () => {
    await mongoose.disconnect();
    process.exit(0);
  })
  .catch(async (err) => {
    console.error("❌ Seed failed:", err);
    try {
      await mongoose.disconnect();
    } catch {}
    process.exit(1);
  });
