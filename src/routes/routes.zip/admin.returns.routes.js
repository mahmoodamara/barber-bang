// src/routes/admin.returns.routes.js
import express from "express";
import { z } from "zod";
import mongoose from "mongoose";

import { requireAuth, requirePermission, PERMISSIONS } from "../middleware/auth.js";
import { auditAdmin } from "../middleware/audit.js";
import { validate } from "../middleware/validate.js";

import { ReturnRequest } from "../models/ReturnRequest.js";
import { Order } from "../models/Order.js";

import { refundStripeOrder } from "../services/refunds.service.js";
import { computeReturnRefundAmountMajor } from "../utils/returns.policy.js";
import { getRequestId } from "../middleware/error.js";
import { sendOk, sendError } from "../utils/response.js";

const router = express.Router();
router.use(requireAuth());
router.use(requirePermission(PERMISSIONS.ORDERS_WRITE));
router.use(auditAdmin());

/* =========================
   Helpers
========================= */

function isValidObjectId(id) {
  return mongoose.Types.ObjectId.isValid(String(id || ""));
}

function makeErr(statusCode, code, message, extra = {}) {
  const err = new Error(message);
  err.statusCode = statusCode;
  err.code = code;
  Object.assign(err, extra);
  return err;
}

function jsonErr(res, e) {
  return sendError(
    res,
    e.statusCode || 500,
    e.code || "INTERNAL_ERROR",
    e.message || "Unexpected error"
  );
}

function clampLimit(v, def = 200, max = 300) {
  const n = Number(v || def);
  if (!Number.isFinite(n)) return def;
  return Math.max(1, Math.min(max, Math.floor(n)));
}

/**
 * Generate deterministic idempotency key from return request + payment intent.
 * This ensures the same refund operation cannot be executed twice.
 */
function buildDeterministicIdempotencyKey(returnRequestId, paymentIntentId) {
  const rrId = String(returnRequestId || "");
  const piId = String(paymentIntentId || "");
  if (!rrId || !piId) return "";
  return `refund:return:${rrId}:${piId}`.slice(0, 200);
}

/**
 * Order.return.status enum عندك:
 * ["none","requested","approved","rejected","received","refunded"]
 *
 * ReturnRequest.status عندك:
 * ["requested","approved","rejected","received","refund_pending","refunded","closed"]
 *
 * لذلك "refund_pending / closed" ما بنحطها بـ Order.return.status
 */
function mapReturnRequestStatusToOrderReturnStatus(rrStatus) {
  const s = String(rrStatus || "");
  if (s === "requested") return "requested";
  if (s === "approved") return "approved";
  if (s === "rejected") return "rejected";
  if (s === "received") return "received";
  if (s === "refunded") return "refunded";
  return null; // refund_pending / closed
}

async function syncOrderReturn(orderId, rr, adminNote = "") {
  if (!orderId) return;

  const mapped = mapReturnRequestStatusToOrderReturnStatus(rr?.status);
  const patch = {};

  if (mapped) {
    patch["return.status"] = mapped;
    patch["return.processedAt"] = new Date();

    // لما يكون في عملية ارجاع جارية
    if (["requested", "approved", "received"].includes(mapped)) {
      patch.status = "return_requested";
    }
  }

  if (adminNote) {
    patch.internalNote = String(adminNote).slice(0, 800);
  }

  if (!Object.keys(patch).length) return;
  await Order.updateOne({ _id: orderId }, { $set: patch });
}

/* =========================
   Schemas
========================= */

const listSchema = z.object({
  query: z.object({
    status: z
      .enum(["requested", "approved", "rejected", "received", "refund_pending", "refunded", "closed"])
      .optional(),
    limit: z.string().optional(),
    orderId: z.string().optional(),
    userId: z.string().optional(),
  }),
});

const patchSchema = z.object({
  params: z.object({ id: z.string().min(1) }), // ReturnRequest ID
  body: z.object({
    action: z.enum(["approve", "reject", "mark_received", "close"]),
    adminNote: z.string().max(800).optional(),
  }),
});

const refundSchema = z.object({
  params: z.object({ id: z.string().min(1) }), // ReturnRequest ID
  body: z.object({
    // optional override
    amount: z.number().min(0).optional(), // ILS major
    includeShipping: z.boolean().optional(),

    // optional override items (for partial refund by selected products)
    items: z
      .array(
        z.object({
          productId: z.string().min(1),
          qty: z.number().int().min(1).max(999),
        })
      )
      .optional(),

    note: z.string().max(800).optional(),
    reason: z.enum(["return", "customer_cancel", "out_of_stock", "fraud", "duplicate", "other"]).optional(),
  }),
});

/* =========================
   Routes
========================= */

/**
 * GET /api/v1/admin/returns?status=&limit=&orderId=&userId=
 */
router.get("/", validate(listSchema), async (req, res) => {
  try {
    const { status, limit, orderId, userId } = req.validated.query || {};
    const lim = clampLimit(limit, 200, 300);

    const filter = {};
    if (status) filter.status = status;

    if (orderId) {
      if (!isValidObjectId(orderId)) throw makeErr(400, "INVALID_ID", "Invalid orderId");
      filter.orderId = orderId;
    }

    if (userId) {
      if (!isValidObjectId(userId)) throw makeErr(400, "INVALID_ID", "Invalid userId");
      filter.userId = userId;
    }

    const items = await ReturnRequest.find(filter).sort({ requestedAt: -1 }).limit(lim);
    return sendOk(res, items);
  } catch (e) {
    return jsonErr(res, e);
  }
});

/**
 * GET /api/v1/admin/returns/:id
 */
router.get("/:id", async (req, res) => {
  try {
    const id = String(req.params.id || "");
    if (!isValidObjectId(id)) throw makeErr(404, "NOT_FOUND", "Return request not found");

    const item = await ReturnRequest.findById(id);
    if (!item) throw makeErr(404, "NOT_FOUND", "Return request not found");

    return sendOk(res, item);
  } catch (e) {
    return jsonErr(res, e);
  }
});

/**
 * PATCH /api/v1/admin/returns/:id
 * approve / reject / mark_received / close
 */
router.patch("/:id", validate(patchSchema), async (req, res) => {
  try {
    const id = String(req.params.id || "");
    if (!isValidObjectId(id)) throw makeErr(400, "INVALID_ID", "Invalid return request id");

    const { action, adminNote } = req.validated.body;

    const rr = await ReturnRequest.findById(id);
    if (!rr) throw makeErr(404, "NOT_FOUND", "Return request not found");

    const cur = String(rr.status || "requested");

    const note = typeof adminNote === "string" ? adminNote.trim().slice(0, 800) : "";

    if (note) rr.adminNote = note;

    if (action === "approve") {
      if (cur !== "requested") throw makeErr(400, "INVALID_STATE", "Return must be in requested state");
      rr.status = "approved";
      rr.decidedAt = new Date();
    }

    if (action === "reject") {
      if (cur !== "requested") throw makeErr(400, "INVALID_STATE", "Return must be in requested state");
      rr.status = "rejected";
      rr.decidedAt = new Date();
    }

    if (action === "mark_received") {
      if (!["approved", "requested"].includes(cur)) {
        throw makeErr(400, "INVALID_STATE", "Return must be approved/requested to mark received");
      }
      rr.status = "received";
      rr.receivedAt = new Date();
    }

    if (action === "close") {
      if (!["rejected", "refunded", "received", "approved"].includes(cur)) {
        throw makeErr(400, "INVALID_STATE", "Return must be approved/received/refunded/rejected to close");
      }
      rr.status = "closed";
    }

    await rr.save();

    // Sync into Order.return (best effort)
    try {
      if (rr.orderId) {
        await syncOrderReturn(
          rr.orderId,
          rr,
          note ? `Return(${action}): ${note}` : `Return(${action})`
        );
      }
    } catch (syncErr) {
      console.warn("[admin.returns] syncOrderReturn failed:", syncErr?.message || syncErr);
    }

    return sendOk(res, rr);
  } catch (e) {
    return jsonErr(res, e);
  }
});

/**
 * POST /api/v1/admin/returns/:id/refund
 * Stripe refund linked to ReturnRequest
 *
 * Uses deterministic idempotency key derived from returnRequestId + paymentIntentId.
 * This prevents duplicate refunds even if the endpoint is called multiple times.
 */
router.post("/:id/refund", validate(refundSchema), async (req, res) => {
  try {
    const id = String(req.params.id || "");
    if (!isValidObjectId(id)) throw makeErr(400, "INVALID_ID", "Invalid return request id");

    const { amount, includeShipping, items, note, reason } = req.validated.body;

    const rr = await ReturnRequest.findById(id);
    if (!rr) throw makeErr(404, "NOT_FOUND", "Return request not found");

    // STRONG duplicate protection: check both ReturnRequest and Order refund status
    if (rr.status === "refunded" || rr?.refund?.status === "succeeded") {
      // Already refunded - return current state (idempotent)
      return sendOk(res, rr);
    }

    const order = await Order.findById(rr.orderId);
    if (!order) throw makeErr(404, "ORDER_NOT_FOUND", "Order not found");

    // Check if order already has a successful refund for this return
    if (order.status === "refunded" && order?.refund?.status === "succeeded") {
      // Order already refunded - sync return request status and return
      rr.status = "refunded";
      rr.refundedAt = order.refund?.refundedAt || new Date();
      rr.set("refund.status", "succeeded");
      rr.set("refund.amount", order.refund?.amount || 0);
      rr.set("refund.stripeRefundId", order.refund?.stripeRefundId || "");
      await rr.save();
      return sendOk(res, rr);
    }

    if (order.paymentMethod !== "stripe") {
      throw makeErr(400, "REFUND_NOT_SUPPORTED", "Refunds are only supported for Stripe orders");
    }

    const paymentIntentId = String(order?.stripe?.paymentIntentId || "");
    if (!paymentIntentId) throw makeErr(400, "MISSING_PAYMENT_INTENT", "Order has no paymentIntentId");

    // DETERMINISTIC idempotency key - derived from data, NOT from headers
    const idempotencyKey = buildDeterministicIdempotencyKey(rr._id, paymentIntentId);

    // Compute refund amount:
    // 1) if admin passed amount => use it directly
    // 2) else use policy function based on rr.items or override items
    let refundAmountMajor = undefined;

    if (typeof amount === "number") {
      refundAmountMajor = amount;
    } else {
      const returnItems = Array.isArray(items) && items.length ? items : rr.items || [];
      refundAmountMajor = computeReturnRefundAmountMajor({
        order,
        returnItems,
        includeShipping,
      });
    }

    // Mark return refund pending using findById + save
    rr.status = "refund_pending";
    rr.set("refund.status", "pending");
    if (note) rr.adminNote = String(note).slice(0, 800);
    await rr.save();

    // Perform refund via service (this updates Order.refund + status)
    let updatedOrder = null;
    try {
      updatedOrder = await refundStripeOrder({
        orderId: order._id,
        amountMajor: typeof refundAmountMajor === "number" ? refundAmountMajor : undefined,
        reason: reason || "return",
        note: note || "Refund due to return request",
        idempotencyKey,
      });
    } catch (rfErr) {
      // Refund failed - update return request with failure
      rr.status = "refund_pending";
      rr.set("refund.status", "failed");
      rr.set("refund.failureMessage", String(rfErr?.message || "Refund failed").slice(0, 400));
      await rr.save();

      const rrObj = rr.toObject ? rr.toObject() : rr;
      return res.status(202).json({
        ok: true,
        success: true,
        data: {
          ...rrObj,
          warning: "REFUND_PENDING_MANUAL_ACTION",
        },
      });
    }

    // Mark ReturnRequest refunded
    rr.status = "refunded";
    rr.refundedAt = new Date();
    rr.set("refund.status", "succeeded");
    rr.set("refund.amount", Number(refundAmountMajor || order?.pricing?.total || 0));
    rr.set("refund.currency", "ils");
    rr.set("refund.stripeRefundId", String(updatedOrder?.refund?.stripeRefundId || ""));
    await rr.save();

    // Best-effort: sync Order.return.refunded
    try {
      const orderToSync = await Order.findById(order._id);
      if (orderToSync) {
        orderToSync.set("return.status", "refunded");
        orderToSync.set("return.processedAt", new Date());
        await orderToSync.save();
      }
    } catch (e) {
      console.warn("[best-effort] admin returns sync order refund status failed:", String(e?.message || e));
    }

    return sendOk(res, rr);
  } catch (e) {
    return jsonErr(res, e);
  }
});

export default router;
