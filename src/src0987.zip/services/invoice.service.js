// src/services/invoice.service.js
import { getReceiptUrlByPaymentIntent } from "./stripe.service.js";
import { computeAllocationRequirement } from "../utils/allocation.js";
import { createInvoiceForOrder as icountCreate } from "./invoice/providers/icount.provider.js";
import { createInvoiceForOrder as greeninvoiceCreate } from "./invoice/providers/greeninvoice.provider.js";

function makeErr(statusCode, code, message) {
  const err = new Error(message);
  err.statusCode = statusCode;
  err.code = code;
  return err;
}

function normalizeProvider(raw) {
  const v = String(raw || "").trim().toLowerCase();
  if (!v) return "";
  const allowed = new Set(["none", "stripe", "manual", "icount", "greeninvoice", "other"]);
  return allowed.has(v) ? v : "other";
}

function normalizeUrlBase(raw) {
  const base = String(raw || "").trim();
  if (!base) return "";
  return base.replace(/\/+$/, "");
}

export function resolveInvoiceProvider(order) {
  const envProvider = normalizeProvider(process.env.INVOICE_PROVIDER);
  if (envProvider) return envProvider;

  const method = String(order?.paymentMethod || "").trim().toLowerCase();
  return method === "stripe" ? "stripe" : "manual";
}

/**
 * Adapter interface: createInvoiceForOrder(order, { provider?, idempotencyKey })
 * @returns {Promise<{ invoiceNumber, providerDocId, url, issuedAt, raw, provider, docId, docType, number, status, error, allocation }>}
 * Legacy shape (provider, docId, docType, number, status, error, allocation) is included for backward compatibility.
 */
export async function createInvoiceForOrder(order, options = {}) {
  if (!order || !order._id) {
    throw makeErr(400, "ORDER_REQUIRED", "order is required to issue invoice");
  }

  const provider = options.provider ?? resolveInvoiceProvider(order);
  const docId = String(order._id);
  const idempotencyKey = options.idempotencyKey ?? "";

  if (provider === "none") {
    throw makeErr(400, "INVOICE_DISABLED", "Invoice issuing is disabled");
  }

  const allocation = computeAllocationRequirement({ order, pricing: order?.pricing });
  const allocationPayload = {
    required: allocation.required,
    status: allocation.status,
    thresholdBeforeVat: allocation.thresholdBeforeVat,
    requestedAt: null,
  };

  if (provider === "stripe") {
    let receiptUrl = String(order?.stripe?.receiptUrl || "");

    if (!receiptUrl) {
      const paymentIntentId = String(order?.stripe?.paymentIntentId || "");
      if (paymentIntentId) {
        receiptUrl = await getReceiptUrlByPaymentIntent(paymentIntentId);
      }
    }

    if (!receiptUrl) {
      throw makeErr(400, "STRIPE_RECEIPT_NOT_AVAILABLE", "Stripe receipt URL not available");
    }

    return {
      invoiceNumber: "",
      providerDocId: docId,
      url: receiptUrl,
      issuedAt: new Date(),
      raw: {},
      provider,
      docId,
      docType: "receipt_link",
      number: "",
      status: "issued",
      error: "",
      allocation: allocationPayload,
    };
  }

  if (provider === "manual") {
    const base = normalizeUrlBase(process.env.INVOICE_BASE_URL);
    const url = base ? `${base}/${encodeURIComponent(docId)}` : "";

    return {
      invoiceNumber: "",
      providerDocId: docId,
      url,
      issuedAt: url ? new Date() : null,
      raw: {},
      provider,
      docId,
      docType: "invoice",
      number: "",
      status: url ? "issued" : "pending",
      error: "",
      allocation: allocationPayload,
    };
  }

  if (provider === "icount") {
    const result = await icountCreate(order, { idempotencyKey });
    return {
      ...result,
      provider,
      docId: result.providerDocId || docId,
      docType: "invoice",
      number: result.invoiceNumber,
      status: "issued",
      error: "",
      allocation: allocationPayload,
    };
  }

  if (provider === "greeninvoice") {
    const result = await greeninvoiceCreate(order, { idempotencyKey });
    return {
      ...result,
      provider,
      docId: result.providerDocId || docId,
      docType: "invoice",
      number: result.invoiceNumber,
      status: "issued",
      error: "",
      allocation: allocationPayload,
    };
  }

  throw makeErr(501, "INVOICE_PROVIDER_NOT_IMPLEMENTED", `Invoice provider "${provider}" not implemented`);
}
