﻿// src/scripts/seed.js
// سكريبت بذور البيانات لمتجر حلاقة الرجال - ثنائي اللغة (عبرية/عربية)
// ✅ متوافق مع السيرفير الجديد (NO MANUAL FLAGS + Category isActive/sortOrder + Product indexes/ranking ready)

import "dotenv/config";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import { connectDB } from "../config/db.js";

import { User } from "../models/User.js";
import { Category } from "../models/Category.js";
import { Product } from "../models/Product.js";
import { DeliveryArea } from "../models/DeliveryArea.js";
import { PickupPoint } from "../models/PickupPoint.js";
import { StorePickupConfig } from "../models/StorePickupConfig.js";
import { Coupon } from "../models/Coupon.js";
import { Campaign } from "../models/Campaign.js";
import { Gift } from "../models/Gift.js";
import { Offer } from "../models/Offer.js";
import { ContentPage } from "../models/ContentPage.js";
import { Review } from "../models/Review.js";
import { ProductAttribute } from "../models/ProductAttribute.js";

/* =========================
   Helpers
========================= */

function nowPlusDays(days) {
  const d = new Date();
  d.setDate(d.getDate() + Number(days || 0));
  return d;
}

async function upsertByFilter(Model, filter, doc) {
  const setDoc = { ...doc };
  delete setDoc.createdAt;

  // Let mongoose timestamps handle updatedAt if enabled,
  // but keep this for models that don't use timestamps.
  setDoc.updatedAt = new Date();

  return Model.findOneAndUpdate(
    filter,
    { $set: setDoc, $setOnInsert: { createdAt: doc.createdAt || new Date() } },
    { upsert: true, new: true }
  );
}

function roundMoney(n) {
  return Math.round((Number(n || 0) + Number.EPSILON) * 100) / 100;
}

function toMinorSafe(major) {
  const n = Number(major || 0);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.round((n + Number.EPSILON) * 100));
}

function normalizeKey(raw) {
  const v = String(raw || "").trim().toLowerCase();
  if (!v) return "";
  return v
    .replace(/\s+/g, "_")
    .replace(/[^a-z0-9_]/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function deriveSalePriceFromDiscount(price, discountPercent) {
  const p = Number(price || 0);
  const pct = Number(discountPercent || 0);
  if (!(p > 0)) return null;
  if (!(pct > 0 && pct < 100)) return null;

  const sale = roundMoney(p * (1 - pct / 100));
  if (!(sale < p)) return null;
  return sale;
}

function computeVariantKeyFromAttributes(attrs) {
  const list = Array.isArray(attrs) ? attrs : [];
  const normalized = list
    .map((a) => ({
      key: normalizeKey(a?.key),
      val: normalizeKey(a?.valueKey) || String(a?.value ?? "").trim(),
    }))
    .filter((x) => x.key && x.val);

  normalized.sort((a, b) => (a.key + ":" + a.val).localeCompare(b.key + ":" + b.val));
  return normalized.map((x) => `${x.key}:${x.val}`).join("|");
}

/**
 * ✅ IMPORTANT:
 * NO MANUAL FLAGS RULE
 * - Do not set or rely on isFeatured/isBestSeller
 * - Rankings MUST be computed by ranking job / stats endpoints
 */
function normalizeProductDoc(p) {
  const doc = { ...p };

  // Legacy fallback fields
  doc.title = doc.titleHe || doc.title || "";
  doc.description = doc.descriptionHe || doc.description || "";

  // Public visibility
  doc.isActive = doc.isActive ?? true;

  // Sale: only valid if salePrice < price
  if (doc.salePrice == null && doc.discountPercent != null) {
    const derived = deriveSalePriceFromDiscount(doc.price, doc.discountPercent);
    if (derived != null) doc.salePrice = derived;
  }

  if (doc.salePrice != null) {
    const sp = Number(doc.salePrice);
    const pr = Number(doc.price);
    if (!(sp < pr)) doc.salePrice = null;
  }

  // Money minors
  doc.priceMinor = toMinorSafe(doc.price);
  doc.salePriceMinor = doc.salePrice != null ? toMinorSafe(doc.salePrice) : null;

  // Clean optional
  if (doc.salePrice === undefined) delete doc.salePrice;
  if (doc.discountPercent === undefined) delete doc.discountPercent;

  if (doc.saleStartAt === undefined || doc.saleStartAt === null) delete doc.saleStartAt;
  if (doc.saleEndAt === undefined || doc.saleEndAt === null) delete doc.saleEndAt;

  // Tags
  doc.tags = Array.isArray(doc.tags) ? doc.tags.filter(Boolean).map(String) : [];

  // Variants normalization
  if (Array.isArray(doc.variants) && doc.variants.length > 0) {
    doc.variants = doc.variants.map((v) => {
      const attrs = Array.isArray(v?.attributes) ? v.attributes : [];
      const variantKey = v.variantKey || computeVariantKeyFromAttributes(attrs);

      const priceOverride =
        v.priceOverride != null && Number.isFinite(Number(v.priceOverride))
          ? Number(v.priceOverride)
          : null;

      const priceOverrideMinor = priceOverride != null ? toMinorSafe(priceOverride) : null;

      return {
        ...v,
        variantKey,
        priceOverride,
        priceOverrideMinor,
        stock: Number.isFinite(Number(v.stock)) ? Number(v.stock) : 0,
        attributes: attrs
          .map((a) => ({
            key: normalizeKey(a?.key),
            type: String(a?.type || "text"),
            value: a?.value ?? null,
            valueKey: normalizeKey(a?.valueKey) || "",
            unit: String(a?.unit || ""),
          }))
          .filter((a) => a.key && a.type),
      };
    });
  } else {
    doc.variants = [];
  }

  // ✅ If product has variants, derive base stock from variants
  if (Array.isArray(doc.variants) && doc.variants.length > 0) {
    const sum = doc.variants.reduce(
      (acc, v) => acc + (Number.isFinite(Number(v?.stock)) ? Number(v.stock) : 0),
      0
    );
    doc.stock = sum;
  } else {
    doc.stock = Number.isFinite(Number(doc.stock)) ? Number(doc.stock) : 0;
  }

  // ✅ Multi images compatibility (optional)
  // Keep imageUrl for legacy storefront, but prefer to also insert images[] (primary)
  if (doc.imageUrl && (!Array.isArray(doc.images) || doc.images.length === 0)) {
    doc.images = [
      {
        assetId: null,
        url: String(doc.imageUrl),
        secureUrl: String(doc.imageUrl),
        altHe: doc.titleHe || "",
        altAr: doc.titleAr || "",
        isPrimary: true,
        sortOrder: 0,
      },
    ];
  }

  return doc;
}

/* =========================
   CLEANUP
========================= */

async function clearExistingData() {
  console.log("🚮 بدء عملية تنظيف البيانات (SMART)...");

  const deletionOrder = [
    { model: Review, name: "التقييمات" },
    { model: Gift, name: "الهدايا" },
    { model: Offer, name: "العروض" },
    { model: Campaign, name: "الحملات" },
    { model: Coupon, name: "الكوبونات" },
    { model: ContentPage, name: "صفحات المحتوى" },
    { model: StorePickupConfig, name: "إعدادات الاستلام من المتجر" },
    { model: PickupPoint, name: "نقاط الاستلام" },
    { model: DeliveryArea, name: "مناطق التوصيل" },
    { model: Product, name: "المنتجات" },
    { model: Category, name: "الفئات" },
    { model: ProductAttribute, name: "سمات المنتج" },
    {
      model: User,
      name: "المستخدمين (غير الإداريين المحددين)",
      filter: {
        email: {
          $nin: [
            process.env.SEED_ADMIN_EMAIL || "admin@shop.local",
            process.env.SEED_TEST_EMAIL || "test@shop.local",
          ],
        },
      },
    },
  ];

  let totalDeleted = 0;
  for (const { model, name, filter = {} } of deletionOrder) {
    try {
      const result = await model.deleteMany(filter);
      console.log(`✅ تم حذف ${result.deletedCount} ${name}`);
      totalDeleted += result.deletedCount;
    } catch (error) {
      console.warn(`⚠️  تحذير عند حذف ${name}:`, error.message);
    }
  }

  console.log(`📊 إجمالي الوثائق المحذوفة: ${totalDeleted}`);
  console.log("✅ اكتملت عملية تنظيف البيانات بنجاح");
  return totalDeleted;
}

/* =========================
   MAIN
========================= */

async function main() {
  await connectDB();
  mongoose.set("strictQuery", true);

  // ✅ Default: delete EVERYTHING as requested
  // Options:
  // - all   => dropDatabase (FULL RESET)
  // - smart => selective deletes
  // - none  => no cleanup
  const cleanupOption = (process.env.SEED_CLEANUP || "all").toLowerCase();

  if (cleanupOption === "all") {
    console.log("🔥 SEED_CLEANUP=all => حذف قاعدة البيانات بالكامل...");
    await mongoose.connection.dropDatabase();
    console.log("✅ تم حذف قاعدة البيانات بالكامل");
  } else if (cleanupOption === "smart") {
    await clearExistingData();
  } else {
    console.log("⏭️  SEED_CLEANUP=none => تخطي عملية التنظيف");
  }

  /* -------------------------
     1) Users
  ------------------------- */
  const adminEmail = process.env.SEED_ADMIN_EMAIL || "admin@shop.local";
  const adminPass = process.env.SEED_ADMIN_PASSWORD || "Admin123!";
  const adminNameHe = "אדמין ראשי";
  const adminNameAr = "المشرف الرئيسي";

  const testEmail = process.env.SEED_TEST_EMAIL || "test@shop.local";
  const testPass = process.env.SEED_TEST_PASSWORD || "Test123!";
  const testNameHe = "משתמש בדיקה";
  const testNameAr = "مستخدم تجريبي";

  const [adminHash, testHash] = await Promise.all([
    bcrypt.hash(adminPass, 10),
    bcrypt.hash(testPass, 10),
  ]);

  const adminUser = await upsertByFilter(User, { email: adminEmail }, {
    name: adminNameHe,
    nameHe: adminNameHe,
    nameAr: adminNameAr,
    email: adminEmail,
    passwordHash: adminHash,
    role: "admin",
    phone: "+972501234567",
    address: {
      streetHe: "רחוב הארבעה 12, תל אביב",
      streetAr: "شارع الأربعة 12، تل أبيب",
      cityHe: "תל אביב",
      cityAr: "تل أبيب",
      zipCode: "12345",
    },
    createdAt: new Date(),
    updatedAt: new Date(),
  });

  const testUser = await upsertByFilter(User, { email: testEmail }, {
    name: testNameHe,
    nameHe: testNameHe,
    nameAr: testNameAr,
    email: testEmail,
    passwordHash: testHash,
    role: "user",
    phone: "+972501234568",
    cart: [],
    wishlist: [],
    address: {
      streetHe: "דרך השלום 34, ירושלים",
      streetAr: "طريق السلام 34، القدس",
      cityHe: "ירושלים",
      cityAr: "القدس",
      zipCode: "54321",
    },
    createdAt: new Date(),
    updatedAt: new Date(),
  });

  console.log(`👤 المستخدم الإداري: ${adminEmail}`);
  console.log(`👤 مستخدم الاختبار: ${testEmail}`);

  /* -------------------------
     2) Product Attributes
  ------------------------- */
  console.log("📝 إضافة سمات المنتج...");

  const attrDocs = [
    { key: "volume_ml", nameHe: "נפח (מ״ל)", nameAr: "الحجم (مل)", type: "number", unit: "ml", options: [], isActive: true },
    { key: "weight_g", nameHe: "משקל (גרם)", nameAr: "الوزن (غرام)", type: "number", unit: "g", options: [], isActive: true },
    {
      key: "blade_size",
      nameHe: "גודל להב",
      nameAr: "حجم الشفرة",
      type: "enum",
      unit: "",
      options: [
        { valueKey: "small", labelHe: "קטן", labelAr: "صغير", isActive: true },
        { valueKey: "medium", labelHe: "בינוני", labelAr: "وسط", isActive: true },
        { valueKey: "large", labelHe: "גדול", labelAr: "كبير", isActive: true },
      ],
      isActive: true,
    },
    { key: "scent", nameHe: "ריח", nameAr: "العطر", type: "text", unit: "", options: [], isActive: true },
    {
      key: "hold_level",
      nameHe: "רמת אחיזה",
      nameAr: "مستوى التثبيت",
      type: "enum",
      unit: "",
      options: [
        { valueKey: "low", labelHe: "חלשה", labelAr: "ضعيف", isActive: true },
        { valueKey: "medium", labelHe: "בינונית", labelAr: "متوسط", isActive: true },
        { valueKey: "strong", labelHe: "חזקה", labelAr: "قوي", isActive: true },
        { valueKey: "extra_strong", labelHe: "חזקה מאוד", labelAr: "قوي جداً", isActive: true },
      ],
      isActive: true,
    },
    {
      key: "skin_type",
      nameHe: "סוג עור",
      nameAr: "نوع البشرة",
      type: "enum",
      unit: "",
      options: [
        { valueKey: "sensitive", labelHe: "רגיש", labelAr: "حساس", isActive: true },
        { valueKey: "normal", labelHe: "רגיל", labelAr: "عادي", isActive: true },
        { valueKey: "oily", labelHe: "שמנוני", labelAr: "دهني", isActive: true },
        { valueKey: "dry", labelHe: "יבש", labelAr: "جاف", isActive: true },
      ],
      isActive: true,
    },
    {
      key: "size",
      nameHe: "גודל",
      nameAr: "الحجم",
      type: "enum",
      unit: "",
      options: [
        { valueKey: "30ml", labelHe: "30 מ״ל", labelAr: "30 مل", isActive: true },
        { valueKey: "50ml", labelHe: "50 מ״ל", labelAr: "50 مل", isActive: true },
        { valueKey: "100ml", labelHe: "100 מ״ל", labelAr: "100 مل", isActive: true },
        { valueKey: "150ml", labelHe: "150 מ״ל", labelAr: "150 مل", isActive: true },
        { valueKey: "200ml", labelHe: "200 מ״ל", labelAr: "200 مل", isActive: true },
      ],
      isActive: true,
    },
    {
      key: "power_source",
      nameHe: "מקור כוח",
      nameAr: "مصدر الطاقة",
      type: "enum",
      unit: "",
      options: [
        { valueKey: "corded", labelHe: "חשמלי", labelAr: "كهربائي", isActive: true },
        { valueKey: "cordless", labelHe: "סוללה", labelAr: "بطارية", isActive: true },
        { valueKey: "both", labelHe: "שניהם", labelAr: "كلاهما", isActive: true },
      ],
      isActive: true,
    },

    // Extras for variants compatibility
    { key: "color", nameHe: "צבע", nameAr: "اللون", type: "text", unit: "", options: [], isActive: true },
    { key: "pack_count", nameHe: "כמות בחבילה", nameAr: "عدد القطع في العبوة", type: "number", unit: "pcs", options: [], isActive: true },
    { key: "finish_type", nameHe: "סוג גימור", nameAr: "نوع اللمعة", type: "text", unit: "", options: [], isActive: true },
  ];

  const attributes = [];
  for (const a of attrDocs) {
    const attr = await upsertByFilter(ProductAttribute, { key: normalizeKey(a.key) }, {
      key: normalizeKey(a.key),
      nameHe: a.nameHe,
      nameAr: a.nameAr,
      name: a.nameHe,
      type: a.type,
      unit: a.unit || "",
      options: Array.isArray(a.options)
        ? a.options.map((o) => ({
            valueKey: normalizeKey(o.valueKey),
            labelHe: o.labelHe,
            labelAr: o.labelAr,
            isActive: o.isActive ?? true,
          }))
        : [],
      isActive: a.isActive ?? true,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    attributes.push(attr);
  }

  console.log(`✅ تم إضافة ${attributes.length} سمة منتج`);

  /* -------------------------
     3) Categories (isActive + sortOrder + SEO)
  ------------------------- */
  console.log("📝 إضافة الفئات...");

  const categoryImages = {
    clippers: "https://images.unsplash.com/photo-1622287162716-f311baa1a2b8?auto=format&fit=crop&w=800&h=600&q=80",
    trimmers: "https://images.unsplash.com/photo-1595476108010-b4d1f102b1b1?auto=format&fit=crop&w=800&h=600&q=80",
    shaving: "https://images.unsplash.com/photo-1607452231257-77686cd90c9e?auto=format&fit=crop&w=800&h=600&q=80",
    hairCare: "https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=800&h=600&q=80",
    beardCare: "https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&w=800&h=600&q=80",
    accessories: "https://images.unsplash.com/photo-1621604048412-5b2e0c5e8d27?auto=format&fit=crop&w=800&h=600&q=80",
    skincare: "https://images.unsplash.com/photo-1556228578-9c360e1d458d?auto=format&fit=crop&w=800&h=600&q=80",
  };

  const categoryDocs = [
    { key: "CLIPPERS", nameHe: "מכונות תספורת", nameAr: "ماكينات قص الشعر", slug: "clippers", imageUrl: categoryImages.clippers,
      descriptionHe: "מכונות תספורת מקצועיות לבית ולסלון", descriptionAr: "ماكينات قص شعر احترافية للمنزل والصالون" },
    { key: "TRIMMERS", nameHe: "טרימרים", nameAr: "ماكينات تهذيب", slug: "trimmers", imageUrl: categoryImages.trimmers,
      descriptionHe: "טרימרים לקווים מדויקים ועיצוב זקן", descriptionAr: "ماكينات تهذيب لخطوط دقيقة وتشكيل اللحية" },
    { key: "SHAVING", nameHe: "גילוח", nameAr: "الحلاقة", slug: "shaving", imageUrl: categoryImages.shaving,
      descriptionHe: "סכיני גילוח, קצף וג'לים לגילוח חלק", descriptionAr: "شفرات حلاقة، رغوة وجل للحلاقة الناعمة" },
    { key: "HAIR_CARE", nameHe: "טיפוח שיער", nameAr: "عناية بالشعر", slug: "hair-care", imageUrl: categoryImages.hairCare,
      descriptionHe: "שמפו, מרכך ומוצרי עיצוב לשיער", descriptionAr: "شامبو، بلسم ومنتجات تصفيف للشعر" },
    { key: "BEARD_CARE", nameHe: "טיפוח זקן", nameAr: "عناية باللحية", slug: "beard-care", imageUrl: categoryImages.beardCare,
      descriptionHe: "שמני זקן, מסרקים ומוצרים לטיפוח זקן", descriptionAr: "زيوت اللحية، أمشاط ومنتجات العناية باللحية" },
    { key: "ACCESSORIES", nameHe: "אביזרים", nameAr: "إكسسوارات", slug: "accessories", imageUrl: categoryImages.accessories,
      descriptionHe: "אביזרי עזר לחיתוך, טיפוח וניקוי", descriptionAr: "إكسسوارات مساعدة للقص، العناية والتنظيف" },
    { key: "SKINCARE", nameHe: "טיפוח עור", nameAr: "عناية بالبشرة", slug: "skincare", imageUrl: categoryImages.skincare,
      descriptionHe: "קרמים, סרומים ומוצרים לטיפוח עור הגבר", descriptionAr: "كريمات، سيروم ومنتجات لعناية بشرة الرجل" },
  ];

  const categories = [];
  for (let i = 0; i < categoryDocs.length; i++) {
    const c = categoryDocs[i];
    const sortOrder = (i + 1) * 10;

    const payload = {
      nameHe: c.nameHe,
      nameAr: c.nameAr,
      name: c.nameHe,

      slug: c.slug, // safe with new slug generation, and unique sparse index
      imageUrl: c.imageUrl || "",

      isActive: true,
      sortOrder,

      descriptionHe: c.descriptionHe,
      descriptionAr: c.descriptionAr,
      description: c.descriptionHe,

      metaTitleHe: c.nameHe,
      metaTitleAr: c.nameAr,
      metaDescriptionHe: c.descriptionHe,
      metaDescriptionAr: c.descriptionAr,

      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const saved = await upsertByFilter(Category, { slug: c.slug }, payload);
    categories.push(saved);
  }

  const normCatKey = (s) =>
    String(s || "")
      .trim()
      .toUpperCase()
      .replace(/[-\s]+/g, "_");

  const catByKey = new Map();
  for (let i = 0; i < categoryDocs.length; i++) {
    const doc = categoryDocs[i];
    const saved = categories[i];
    catByKey.set(normCatKey(doc.key), saved);
    catByKey.set(normCatKey(doc.slug), saved);
  }

  const getCatId = (key) => {
    const c = catByKey.get(normCatKey(key));
    if (!c?._id) throw new Error(`[seed] فئة مفقودة للمفتاح=${key}`);
    return c._id;
  };

  console.log(`✅ تم إضافة ${categories.length} فئة`);

  /* -------------------------
     4) Products (NO flags)
  ------------------------- */
  console.log("📝 إضافة المنتجات...");

  const img = {
    wahlMagic: "https://images.unsplash.com/photo-1622287162716-f311baa1a2b8?auto=format&fit=crop&w=800&h=800&q=80",
    andisMaster: "https://images.unsplash.com/photo-1585747860715-2ba37e788b70?auto=format&fit=crop&w=800&h=800&q=80",
    osterFastFeed: "https://images.unsplash.com/photo-1562243061-2046c8bb60e7?auto=format&fit=crop&w=800&h=800&q=80",

    babylissSkeleton: "https://images.unsplash.com/photo-1595476108010-b4d1f102b1b1?auto=format&fit=crop&w=800&h=800&q=80",
    philipsMultigroom: "https://images.unsplash.com/photo-1515377905703-c4788e51af15?auto=format&fit=crop&w=800&h=800&q=80",
    wahlDetailer: "https://images.unsplash.com/photo-1562243061-2046c8bb60e7?auto=format&fit=crop&w=800&h=800&q=80",

    gilletteFusion: "https://images.unsplash.com/photo-1607452231257-77686cd90c9e?auto=format&fit=crop&w=800&h=800&q=80",
    harrysRazor: "https://images.unsplash.com/photo-1600033823210-0ff56e5e9c09?auto=format&fit=crop&w=800&h=800&q=80",
    shavingCream: "https://images.unsplash.com/photo-1604336737429-4897e55e76b3?auto=format&fit=crop&w=800&h=800&q=80",

    hairWax: "https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=800&h=800&q=80",
    pomade: "https://images.unsplash.com/photo-1621607512214-68297480165e?auto=format&fit=crop&w=800&h=800&q=80",
    hairSpray: "https://images.unsplash.com/photo-1591084728795-1149f32d9866?auto=format&fit=crop&w=800&h=800&q=80",

    beardOil: "https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&w=800&h=800&q=80",
    beardComb: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=800&h=800&q=80",
    beardBrush: "https://images.unsplash.com/photo-1621604048412-5b2e0c5e8d27?auto=format&fit=crop&w=800&h=800&q=80",

    barberScissors: "https://images.unsplash.com/photo-1631085216051-b6e2783d7077?auto=format&fit=crop&w=800&h=800&q=80",
    barberCape: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=800&h=800&q=80",
    cleaningBrush: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=800&h=800&q=80",

    aftershave: "https://images.unsplash.com/photo-1556228578-9c360e1d458d?auto=format&fit=crop&w=800&h=800&q=80",
    faceCream: "https://images.unsplash.com/photo-1571875257727-256c39da42af?auto=format&fit=crop&w=800&h=800&q=80",
    faceWash: "https://images.unsplash.com/photo-1556228578-9c360e1d458d?auto=format&fit=crop&w=800&h=800&q=80",
  };

  const baseCompliance = {
    brand: "BarberPro",
    sku: "",
    barcode: "",
    sizeLabel: "",
    unit: null,
    netQuantity: null,
    tags: ["حلاقة", "رجالي", "عناية"],
    ingredients: "—",
    usage: "—",
    warnings: "—",
    manufacturerName: "BarberPro LTD",
    importerName: "BarberPro Import",
    countryOfOrigin: "Various",
    warrantyInfo: "ضمان سنة واحدة من تاريخ الشراء",
  };

  const productDocs = [
    {
      titleHe: "WAHL Magic Clip - מכונת תספורת אלחוטית",
      titleAr: "WAHL Magic Clip - ماكينة قص شعر لاسلكية",
      descriptionHe: `מכונת התספורת האלחוטית WAHL Magic Clip היא כלי חיוני לכל ספר מקצועי ולכל מי שרוצה להשיג תוצאות מושלמות בבית.
עם זמן עבודה של עד 120 דקות מטען אחד, היא מושלמת ליום עבודה שלם.
הלהבים המותאמים אישית מאפשרים חיתוך מדויק ונוח.`,
      descriptionAr: `ماكينة قص الشعر اللاسلكية WAHL Magic Clip هي أداة أساسية لكل حلاق محترف وأي شخص يريد تحقيق نتائج مثالية في المنزل.
مع وقت عمل يصل إلى 120 دقيقة بشحنة واحدة، إنها مثالية ليوم عمل كامل.
الشفرات القابلة للتعديل تتيح قصاً دقيقاً ومريحاً.`,
      price: 549,
      stock: 25,
      categoryId: getCatId("CLIPPERS"),
      imageUrl: img.wahlMagic,
      discountPercent: 15,
      saleStartAt: new Date(),
      saleEndAt: nowPlusDays(30),

      ...baseCompliance,
      sku: "BP-WAHL-MAGIC-CLIP",
      barcode: "729001000001",
      sizeLabel: "لاسلكي",
      unit: "pcs",
      netQuantity: 1,
      tags: [...baseCompliance.tags, "wahl", "لاسلكي", "احترافي"],
      ingredients: "بلاستيك عالي الجودة، فولاذ لا يصدأ",
      usage: "استخدم على شعر جاف. نظف الشفرات بعد كل استخدام",
      warnings: "بعيداً عن متناول الأطفال. لا تستخدم على شعر مبلل",

      variants: [
        {
          sku: "BP-WAHL-MAGIC-CLIP-BLK",
          barcode: "729001000011",
          stock: 15,
          priceOverride: null,
          attributes: [
            { key: "power_source", type: "enum", value: null, valueKey: "cordless", unit: "" },
            { key: "color", type: "text", value: "أسود", valueKey: "", unit: "" },
          ],
        },
        {
          sku: "BP-WAHL-MAGIC-CLIP-SLV",
          barcode: "729001000012",
          stock: 10,
          priceOverride: null,
          attributes: [
            { key: "power_source", type: "enum", value: null, valueKey: "cordless", unit: "" },
            { key: "color", type: "text", value: "فضي", valueKey: "", unit: "" },
          ],
        },
      ],
    },

    {
      titleHe: "Andis Master - מכונת תספורת מקצועית",
      titleAr: "Andis Master - ماكينة قص شعر احترافية",
      descriptionHe: `מכונת התספורת Andis Master היא סטנדרט הזהב בתעשיית הספרים.
עם מנוע מגנטי חזק, היא מספקת ביצועים עקביים לאורך כל היום.
מתאימה לכל סוגי השיער, משיער דק ועד לשיער עבה וקשה.`,
      descriptionAr: `ماكينة قص الشعر Andis Master هي المعيار الذهبي في صناعة الحلاقة.
بمحرك مغناطيسي قوي، توفر أداءً متسقاً طوال اليوم.
مناسبة لجميع أنواع الشعر، من الشعر الناعم إلى الشعر السميك والخشن.`,
      price: 799,
      stock: 18,
      categoryId: getCatId("CLIPPERS"),
      imageUrl: img.andisMaster,

      ...baseCompliance,
      sku: "BP-ANDIS-MASTER",
      barcode: "729001000002",
      sizeLabel: "احترافي",
      unit: "pcs",
      netQuantity: 1,
      tags: [...baseCompliance.tags, "andis", "احترافي", "صالون"],
      usage: "للشعر الجاف فقط. نظف الشفرات بانتظام",
      warnings: "للاستخدام المهني. لا تغمر في الماء",
      variants: [],
    },

    {
      titleHe: "BabylissPRO Skeleton Trimmer - טרימר מקצועי",
      titleAr: "BabylissPRO Skeleton Trimmer - ماكينة تهذيب احترافية",
      descriptionHe: `הטרימר BabylissPRO Skeleton הוא הטרימר המושלם לקווים מדויקים ועיצוב זקן.
עם להבי טיטניום חדים במיוחד, הוא מספק דיוק שאין שני לו.
עיצוב ארגונומי להחזקה נוחה לאורך זמן.`,
      descriptionAr: `ماكينة تهذيب BabylissPRO Skeleton هي الأداة المثالية للخطوط الدقيقة وتشكيل اللحية.
بشفرات تيتانيوم حادة جداً، توفر دقة لا مثيل لها.
تصميم مريح يسهل الإمساك به لفترات طويلة.`,
      price: 399,
      stock: 30,
      categoryId: getCatId("TRIMMERS"),
      imageUrl: img.babylissSkeleton,
      discountPercent: 20,
      saleStartAt: new Date(),
      saleEndAt: nowPlusDays(14),

      ...baseCompliance,
      sku: "BP-BABYLISS-SKELETON",
      barcode: "729001000003",
      sizeLabel: "تهذيب",
      unit: "pcs",
      netQuantity: 1,
      tags: [...baseCompliance.tags, "babyliss", "تهذيب", "دقيق"],
      usage: "لتهذيب الشعر واللحية. نظف بعد كل استخدام",
      variants: [],
    },

    {
      titleHe: "פיליפס מולטיגרום 7000 - מכונת גילוח רב תכליתית",
      titleAr: "فيليبس مولتي جرم 7000 - ماكينة حلاقة متعددة الاستخدامات",
      descriptionHe: `מכונת הגילוח הרב-תכליתית פיליפס מולטיגרום 7000 היא הפיתרון המושלם לכל צרכי הגילוח והטיפוח.
כוללת 5 מתקנים להחלפה: מכונת תספורת, טרימר, מכונת גילוח, מסרק עיצוב ומברשת ניקוי.
סוללה המספיקה ל-120 דקות עבודה.`,
      descriptionAr: `ماكينة الحلاقة متعددة الاستخدامات فيليبس مولتي جرم 7000 هي الحل المثالي لجميع احتياجات الحلاقة والعناية.
تشمل 5 ملحقات قابلة للتبديل: ماكينة قص شعر، ماكينة تهذيب، ماكينة حلاقة، مشط تشكيل وفرشة تنظيف.
بطارية تكفي لـ 120 دقيقة عمل.`,
      price: 699,
      stock: 22,
      categoryId: getCatId("TRIMMERS"),
      imageUrl: img.philipsMultigroom,

      ...baseCompliance,
      sku: "BP-PHILIPS-MG7000",
      barcode: "729001000004",
      sizeLabel: "متعدد",
      unit: "set",
      netQuantity: 1,
      tags: [...baseCompliance.tags, "philips", "متعدد", "شامل"],
      usage: "للحلاقة والتهذيب والتشكيل. نظف الملحقات بانتظام",
      variants: [],
    },

    {
      titleHe: "ג'ילט פיוז'ן 5 - סכיני גילוח עם 5 להבים",
      titleAr: "جيلت فيوجن 5 - شفرات حلاقة بـ 5 شفرات",
      descriptionHe: `סכיני הגילוח ג'ילט פיוז'ן 5 עם 5 להבים מספקים גילוח חלק ללא גירויים.
הטכנולוגיה המיוחדת מפחיתה את החיכוך עם העור ומבטיחה גילוח נוח.
מתאים לכל סוגי העור, כולל עור רגיש.`,
      descriptionAr: `شفرات الحلاقة جيلت فيوجن 5 بـ 5 شفرات توفر حلاقة ناعمة بدون تهيج.
التقنية الخاصة تقلل الاحتكاك مع الجلد وتضمن حلاقة مريحة.
مناسبة لجميع أنواع البشرة، بما في ذلك البشرة الحساسة.`,
      price: 129,
      stock: 150,
      categoryId: getCatId("SHAVING"),
      imageUrl: img.gilletteFusion,
      discountPercent: 25,
      saleStartAt: new Date(),
      saleEndAt: nowPlusDays(7),

      ...baseCompliance,
      sku: "BP-GILLETTE-FUSION5",
      barcode: "729001000005",
      sizeLabel: "4 قطع",
      unit: "pcs",
      netQuantity: 4,
      tags: [...baseCompliance.tags, "gillette", "شفرات", "حلاقة"],
      usage: "استخدم مع رغوة أو جل حلاقة. استبدل الشفرة كل 5-7 استخدامات",
      warnings: "حفظ بعيداً عن متناول الأطفال. الشفرات حادة",

      variants: [
        {
          sku: "BP-GILLETTE-FUSION5-4P",
          barcode: "729001000051",
          stock: 80,
          priceOverride: null,
          attributes: [{ key: "pack_count", type: "number", value: 4, valueKey: "", unit: "pcs" }],
        },
        {
          sku: "BP-GILLETTE-FUSION5-8P",
          barcode: "729001000052",
          stock: 70,
          priceOverride: 239,
          attributes: [{ key: "pack_count", type: "number", value: 8, valueKey: "", unit: "pcs" }],
        },
      ],
    },

    {
      titleHe: "ווקס לשיער - אחיזה חזקה מאוד, גימור מט",
      titleAr: "واكس للشعر - تثبيت قوي جداً، مظهر غير لامع",
      descriptionHe: `הווקס לשיער שלנו עם אחיזה חזקה מאוד וגימור מט טבעי מתאים לכל סוגי השיער.
אינו משאיר שאריות לבנות, נשטף בקלות ואינו מייקר את השיער.
מכיל מרכיבים טבעיים ושומר על בריאות השיער.`,
      descriptionAr: `واكس الشعر لدينا بتثبيت قوي جداً ومظهر غير لامع طبيعي يناسب جميع أنواع الشعر.
لا يترك بقايا بيضاء، يغسل بسهولة ولا يثقل الشعر.
يحتوي على مكونات طبيعية ويحافظ على صحة الشعر.`,
      price: 49,
      stock: 0,
      categoryId: getCatId("HAIR_CARE"),
      imageUrl: img.hairWax,

      ...baseCompliance,
      sku: "BP-HAIR-WAX",
      barcode: "729001000007",
      sizeLabel: "متغير",
      unit: "ml",
      netQuantity: null,
      tags: [...baseCompliance.tags, "واكس", "تثبيت", "شعر"],
      ingredients: "شمع النحل، زبدة الشيا، زيوت طبيعية",
      usage: "ضع كمية صغيرة على راحة اليد، دلك ثم وزع على الشعر",

      variants: [
        {
          sku: "BP-HAIR-WAX-100-MATTE",
          barcode: "729001000071",
          stock: 60,
          priceOverride: 49,
          attributes: [
            { key: "size", type: "enum", value: null, valueKey: "100ml", unit: "" },
            { key: "hold_level", type: "enum", value: null, valueKey: "extra_strong", unit: "" },
            { key: "finish_type", type: "text", value: "غير لامع", valueKey: "", unit: "" },
          ],
        },
        {
          sku: "BP-HAIR-WAX-200-MATTE",
          barcode: "729001000073",
          stock: 40,
          priceOverride: 79,
          attributes: [
            { key: "size", type: "enum", value: null, valueKey: "200ml", unit: "" },
            { key: "hold_level", type: "enum", value: null, valueKey: "extra_strong", unit: "" },
            { key: "finish_type", type: "text", value: "غير لامع", valueKey: "", unit: "" },
          ],
        },
      ],
    },

    {
      titleHe: "שמן זקן פרימיום - שמן ארגן וזית",
      titleAr: "زيت لحية فاخر - زيت الأرجان والزيتون",
      descriptionHe: `שמן הזקן הפרימיום שלנו מכיל שמן ארגן אורגני ושמן זית בכבישה קרה.
מרכך את הזקן, מונע קשקשים וגירויים, ומעניק ריח עדין וטבעי.
מתאים לכל סוגי העור והזקן.`,
      descriptionAr: `زيت اللحية الفاخر لدينا يحتوي على زيت الأرجان العضوي وزيت الزيتون البكر.
يلين اللحية، يمنع القشرة والتهيج، ويعطي رائحة خفيفة وطبيعية.
مناسب لجميع أنواع البشرة واللحى.`,
      price: 79,
      stock: 120,
      categoryId: getCatId("BEARD_CARE"),
      imageUrl: img.beardOil,

      ...baseCompliance,
      sku: "BP-BEARD-OIL-PREMIUM",
      barcode: "729001000009",
      sizeLabel: "30ml",
      unit: "ml",
      netQuantity: 30,
      tags: [...baseCompliance.tags, "لحية", "زيت", "عناية"],
      ingredients: "زيت الأرجان العضوي، زيت الزيتون البكر، فيتامين E",
      usage: "ضع 3-4 قطرات على راحة اليد، دلك ثم وزع على اللحية والجلد تحتها",

      variants: [
        {
          sku: "BP-BEARD-OIL-30-SANDAL",
          barcode: "729001000091",
          stock: 65,
          priceOverride: null,
          attributes: [
            { key: "size", type: "enum", value: null, valueKey: "30ml", unit: "" },
            { key: "scent", type: "text", value: "خشب الصندل", valueKey: "", unit: "" },
          ],
        },
        {
          sku: "BP-BEARD-OIL-30-CEDAR",
          barcode: "729001000092",
          stock: 55,
          priceOverride: null,
          attributes: [
            { key: "size", type: "enum", value: null, valueKey: "30ml", unit: "" },
            { key: "scent", type: "text", value: "أرز", valueKey: "", unit: "" },
          ],
        },
        {
          sku: "BP-BEARD-OIL-50-SANDAL",
          barcode: "729001000093",
          stock: 40,
          priceOverride: 129,
          attributes: [
            { key: "size", type: "enum", value: null, valueKey: "50ml", unit: "" },
            { key: "scent", type: "text", value: "خشب الصندل", valueKey: "", unit: "" },
          ],
        },
      ],
    },

    {
      titleHe: "מסרק מתנה - עם רכישה מעל 300 ש״ח",
      titleAr: "مشط هدية - مع شراء فوق 300 شيكل",
      descriptionHe: `מסרק איכותי מעץ - מתנה לרכישה מעל 300 ש״ח.
מתאים לשיער ולזקן, בעיצוב קלאסי ואיכותי.
*מחיר המוצר 0 ש״ח - ניתן רק כמתנה עם רכישה.`,
      descriptionAr: `مشط خشب عالي الجودة - هدية مع شراء فوق 300 شيكل.
مناسب للشعر واللحية، بتصميم كلاسيكي وعالي الجودة.
*سعر المنتج 0 شيكل - متاح فقط كهدية مع الشراء.`,
      price: 0,
      stock: 999,
      categoryId: getCatId("ACCESSORIES"),
      imageUrl: img.beardComb,
      isActive: true,

      ...baseCompliance,
      sku: "BP-GIFT-COMB",
      barcode: "729001000099",
      sizeLabel: "هدية",
      unit: "pcs",
      netQuantity: 1,
      tags: [...baseCompliance.tags, "هدية", "مجاني"],
      variants: [],
    },
  ];

  const products = [];
  for (const p of productDocs) {
    const doc = normalizeProductDoc(p);
    doc.createdAt = new Date();
    doc.updatedAt = new Date();

    const saved = await upsertByFilter(Product, { sku: doc.sku }, doc);
    products.push(saved);
  }

  const productBySku = new Map(products.map((p) => [p.sku, p]));

  console.log(`✅ تم إضافة ${products.length} منتج`);

  /* -------------------------
     5) Shipping
  ------------------------- */
  console.log("📝 إضافة خيارات الشحن...");

  const deliveryAreas = await Promise.all(
    [
      { nameHe: "מרכז (תל אביב והסביבה)", nameAr: "المركز (تل أبيب والمنطقة)", fee: 25, isActive: true },
      { nameHe: "צפון (חיפה, נצרת והגליל)", nameAr: "الشمال (حيفا، الناصرة والجليل)", fee: 30, isActive: true },
      { nameHe: "דרום (באר שבע, אילת והנגב)", nameAr: "الجنوب (بئر السبع، إيلات والنقب)", fee: 35, isActive: true },
      { nameHe: "ירושלים והסביבה", nameAr: "القدس والمنطقة", fee: 28, isActive: true },
    ].map((a) =>
      upsertByFilter(DeliveryArea, { nameHe: a.nameHe }, {
        ...a,
        name: a.nameHe,
        fee: Number(a.fee),
        createdAt: new Date(),
        updatedAt: new Date(),
      })
    )
  );

  const pickupPoints = await Promise.all(
    [
      {
        nameHe: "נקודת איסוף — קניון עזריאלי, תל אביב",
        nameAr: "نقطة استلام - مركز عزرائيلي التجاري، تل أبيب",
        addressHe: "תל אביב, קניון עזריאלי, קומה 2, חנות 205",
        addressAr: "تل أبيب، مركز عزرائيلي التجاري، الطابق 2، محل 205",
        fee: 10,
        isActive: true,
      },
      {
        nameHe: "נקודת איסוף — מלון דן פנורמה, ירושלים",
        nameAr: "نقطة استلام - فندق دان بانوراما، القدس",
        addressHe: "ירושלים, רחוב קרן היסוד 39, לובי המלון",
        addressAr: "القدس، شارع كيرين هيسود 39، لوبي الفندق",
        fee: 12,
        isActive: true,
      },
      {
        nameHe: "נקודת איסוף — קניון חיפה, חיפה",
        nameAr: "نقطة استلام - مركز حيفا التجاري، حيفا",
        addressHe: "חיפה, קניון חיפה, קומה 1, ליד הכניסה הראשית",
        addressAr: "حيفا، مركز حيفا التجاري، الطابق 1، بجانب المدخل الرئيسي",
        fee: 10,
        isActive: true,
      },
    ].map((p) =>
      upsertByFilter(PickupPoint, { nameHe: p.nameHe }, {
        ...p,
        name: p.nameHe,
        address: p.addressHe,
        fee: Number(p.fee),
        createdAt: new Date(),
        updatedAt: new Date(),
      })
    )
  );

  await StorePickupConfig.findOneAndUpdate(
    {},
    {
      $set: {
        isEnabled: true,
        fee: 0,
        addressHe: "תל אביב, רחוב המסגר 12",
        addressAr: "تل أبيب، شارع هامسغير 12",
        notesHe: "שעות פעילות: א׳–ה׳ 9:00–18:00, ו' 9:00–14:00. יש לתאם הגעה מראש בטלפון.",
        notesAr: "ساعات العمل: الأحد-الخميس 9:00-18:00، الجمعة 9:00-14:00. يجب التنسيق على الهاتف مسبقاً.",
        address: "תל אביב, רחוב המסגר 12",
        notes: "שעות פעילות: א׳–ה׳ 9:00–18:00, ו' 9:00–14:00. יש לתאם הגעה מראש בטלפון.",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    },
    { upsert: true, new: true }
  );

  console.log(`✅ تم إضافة ${deliveryAreas.length} منطقة توصيل، ${pickupPoints.length} نقطة استلام`);

  /* -------------------------
     6) Coupons
  ------------------------- */
  console.log("📝 إضافة الكوبونات...");

  const coupons = [
    { code: "SAVE20", type: "percent", value: 20, minOrderTotal: 200, maxDiscount: 100, usageLimit: 500, usedCount: 0, startAt: new Date(), endAt: nowPlusDays(60), isActive: true },
    { code: "FIRST10", type: "percent", value: 10, minOrderTotal: 100, maxDiscount: 50, usageLimit: 1000, usedCount: 0, startAt: new Date(), endAt: nowPlusDays(90), isActive: true },
    { code: "FREESHIP", type: "fixed", value: 30, minOrderTotal: 150, maxDiscount: 30, usageLimit: 2000, usedCount: 0, startAt: new Date(), endAt: nowPlusDays(45), isActive: true },
    { code: "BEARD25", type: "percent", value: 25, minOrderTotal: 100, maxDiscount: 75, usageLimit: 300, usedCount: 0, startAt: new Date(), endAt: nowPlusDays(30), isActive: true },
  ];

  for (const coupon of coupons) {
    await upsertByFilter(Coupon, { code: coupon.code }, {
      ...coupon,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }

  console.log(`✅ تم إضافة ${coupons.length} كوبون`);

  /* -------------------------
     7) Campaigns (optional)
  ------------------------- */
  console.log("📝 إضافة الحملات...");
  const campaigns = [];
  for (const campaign of campaigns) {
    await upsertByFilter(Campaign, { nameHe: campaign.nameHe }, {
      ...campaign,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }
  console.log(`✅ تم إضافة ${campaigns.length} حملة`);

  /* -------------------------
     8) Gifts
  ------------------------- */
  console.log("📝 إضافة عروض الهدايا...");

  const giftComb = productBySku.get("BP-GIFT-COMB");
  if (!giftComb) throw new Error("[seed] منتج الهدية غير موجود: BP-GIFT-COMB");

  const gifts = [
    {
      nameHe: "מסרק במתנה - רכישה מעל 300 ש״ח",
      nameAr: "مشط هدية - شراء فوق 300 شيكل",
      name: "מסרק במתנה",
      giftProductId: giftComb._id,
      minOrderTotal: 300,
      requiredProductId: null,
      requiredCategoryId: null,
      startAt: new Date(),
      endAt: nowPlusDays(90),
      isActive: true,
    },
    {
      nameHe: "שמן זקן במתנה - רכישה מעל 500 ש״ח",
      nameAr: "زيت لحية هدية - شراء فوق 500 شيكل",
      name: "שמן זקן במתנה",
      giftProductId: productBySku.get("BP-BEARD-OIL-PREMIUM")?._id,
      minOrderTotal: 500,
      requiredProductId: null,
      requiredCategoryId: getCatId("BEARD_CARE"),
      startAt: new Date(),
      endAt: nowPlusDays(60),
      isActive: true,
    },
  ];

  let savedGiftsCount = 0;
  for (const gift of gifts) {
    if (gift.giftProductId) {
      await upsertByFilter(Gift, { nameHe: gift.nameHe }, {
        ...gift,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      savedGiftsCount++;
    }
  }

  console.log(`✅ تم إضافة ${savedGiftsCount} عرض هدايا`);

  /* -------------------------
     9) Offers
  ------------------------- */
  console.log("📝 إضافة العروض الموسمية...");

  const hairWax = productBySku.get("BP-HAIR-WAX");
  if (!hairWax) throw new Error("[seed] منتج غير موجود للعرض BUY_X_GET_Y: BP-HAIR-WAX");

  const offers = [
    {
      nameHe: "הנחת חורף - 15% על כל מוצרי הטיפוח",
      nameAr: "خصم شتوي - 15٪ على جميع منتجات العناية",
      name: "הנחת חורף",
      type: "PERCENT_OFF",
      value: 15,
      minTotal: 150,
      productIds: [],
      categoryIds: [getCatId("HAIR_CARE"), getCatId("BEARD_CARE"), getCatId("SKINCARE")],
      stackable: true,
      priority: 10,
      startAt: new Date(),
      endAt: nowPlusDays(60),
      isActive: true,
    },
    {
      nameHe: "משלוח חינם בהזמנה מעל 250 ש״ח",
      nameAr: "شحن مجاني على الطلبات فوق 250 شيكل",
      name: "משלוח חינם",
      type: "FREE_SHIPPING",
      value: 0,
      minTotal: 250,
      productIds: [],
      categoryIds: [],
      stackable: false,
      priority: 20,
      startAt: new Date(),
      endAt: nowPlusDays(45),
      isActive: true,
    },
    {
      nameHe: "רכישה 3 ב-2 על שעווה לשיער",
      nameAr: "شراء 3 بسعر 2 على واكس الشعر",
      name: "רכישה 3 ב-2",
      type: "BUY_X_GET_Y",
      value: 0,
      minTotal: 100,

      buyProductId: hairWax._id,
      buyVariantId: null,
      buyQty: 3,

      getProductId: hairWax._id,
      getVariantId: null,
      getQty: 1,

      productIds: [],
      categoryIds: [],

      stackable: false,
      priority: 30,
      startAt: new Date(),
      endAt: nowPlusDays(30),
      isActive: true,
    },
  ];

  for (const offer of offers) {
    await upsertByFilter(Offer, { nameHe: offer.nameHe }, {
      ...offer,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }

  console.log(`✅ تم إضافة ${offers.length} عرض موسمي`);

  /* -------------------------
     10) Content Pages
  ------------------------- */
  console.log("📝 إضافة صفحات المحتوى...");

  const pages = [
    {
      slug: "about",
      titleHe: "אודות Barber Bang",
      titleAr: "من نحن - Barber Bang",
      contentHe: `ברוכים הבאים ל-Barber Bang — חנות אונליין מובילה בישראל למוצרי טיפוח לגברים ולציוד ברבר מקצועי.`,
      contentAr: `أهلاً بكم في Barber Bang — متجر إلكتروني رائد في إسرائيل لمنتجات العناية بالرجال ومستلزمات الحلاقة الاحترافية.`,
      sortOrder: 10,
      isActive: true,
    },
    {
      slug: "terms",
      titleHe: "תקנון האתר",
      titleAr: "شروط وأحكام",
      contentHe: `תקנון האתר — Barber Bang`,
      contentAr: `شروط وأحكام — Barber Bang`,
      sortOrder: 15,
      isActive: true,
    },
    {
      slug: "shipping",
      titleHe: "מדיניות משלוחים",
      titleAr: "سياسة الشحن",
      contentHe: `מדיניות משלוחים — Barber Bang`,
      contentAr: `سياسة الشحن — Barber Bang`,
      sortOrder: 20,
      isActive: true,
    },
    {
      slug: "returns",
      titleHe: "החזרות והחלפות",
      titleAr: "الإرجاع والاستبدال",
      contentHe: `מדיניות החזרות והחלפות — Barber Bang`,
      contentAr: `سياسة الإرجاع والاستبدال — Barber Bang`,
      sortOrder: 30,
      isActive: true,
    },
    {
      slug: "accessibility",
      titleHe: "הצהרת נגישות",
      titleAr: "بيان إمكانية الوصول",
      contentHe: `הצהרת נגישות — Barber Bang`,
      contentAr: `بيان إمكانية الوصول — Barber Bang`,
      sortOrder: 25,
      isActive: true,
    },
    {
      slug: "contact",
      titleHe: "צור קשר",
      titleAr: "اتصل بنا",
      contentHe: `צור קשר — Barber Bang`,
      contentAr: `اتصل بنا — Barber Bang`,
      sortOrder: 50,
      isActive: true,
    },
  ];

  for (const p of pages) {
    await upsertByFilter(ContentPage, { slug: p.slug }, {
      ...p,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }

  console.log(`✅ تم إضافة/تحديث ${pages.length} صفحات محتوى`);

  /* -------------------------
     11) Wishlist for test user
  ------------------------- */
  console.log("📝 إعداد قائمة الرغبات لمستخدم الاختبار...");

  const wishlistSkus = ["BP-WAHL-MAGIC-CLIP", "BP-BABYLISS-SKELETON", "BP-BEARD-OIL-PREMIUM", "BP-HAIR-WAX"];
  const wishlistProductIds = wishlistSkus.map((sku) => productBySku.get(sku)?._id).filter(Boolean);

  await User.updateOne({ _id: testUser._id }, { $set: { wishlist: wishlistProductIds, updatedAt: new Date() } });
  console.log(`✅ تمت إضافة ${wishlistProductIds.length} منتج لقائمة رغبات مستخدم الاختبار`);

  /* -------------------------
     12) Reviews samples
  ------------------------- */
  console.log("📝 إضافة عينات التقييمات...");

  const reviewTargets = [
    { productSku: "BP-WAHL-MAGIC-CLIP", rating: 5, commentHe: "מכונה מצוינת! עובדת כמו חדשה כבר שנה.", commentAr: "ماكينة ممتازة! تعمل مثل الجديدة منذ سنة." },
    { productSku: "BP-BEARD-OIL-PREMIUM", rating: 5, commentHe: "שמן זקן מעולה! הריח נעים.", commentAr: "زيت لحية رائع! الرائحة لطيفة." },
    { productSku: "BP-HAIR-WAX", rating: 4, commentHe: "ווקס טוב מאוד, אחיזה חזקה.", commentAr: "واكس جيد جداً، تثبيت قوي." },
    { productSku: "BP-GILLETTE-FUSION5", rating: 5, commentHe: "הסכינים הטובים ביותר שניסיתי.", commentAr: "أفضل الشفرات التي جربتها." },
  ];

  for (const r of reviewTargets) {
    const prod = productBySku.get(r.productSku);
    if (!prod) continue;

    const comment = `${r.commentHe}\n\n${r.commentAr}`;

    await Review.findOneAndUpdate(
      { productId: prod._id, userId: testUser._id },
      {
        $set: {
          productId: prod._id,
          userId: testUser._id,
          rating: Number(r.rating || 5),
          comment: String(comment || "").trim(),
          isVerified: true,
          helpfulCount: Math.floor(Math.random() * 20) + 5,
          createdAt: new Date(Date.now() - Math.floor(Math.random() * 30) * 24 * 60 * 60 * 1000),
          updatedAt: new Date(),
        },
      },
      { upsert: true, new: true }
    );
  }

  console.log(`✅ تم إضافة ${reviewTargets.length} تقييم عينة`);

  /* -------------------------
     Summary
  ------------------------- */
  console.log("\n🎉 اكتملت عملية بذر البيانات بنجاح!");
  console.log("=".repeat(60));
  console.log("📊 ملخص البيانات:");
  console.log("=".repeat(60));
  console.log("👥 المستخدمون:");
  console.log(`  • المشرف: ${adminEmail} (${adminPass})`);
  console.log(`  • الاختبار: ${testEmail} (${testPass})`);
  console.log("\n🏷️  سمات المنتج:");
  console.log(`  • ${attributes.length} سمة`);
  console.log("\n📁 الفئات:");
  categories.forEach((cat, i) => {
    console.log(`  • ${i + 1}. ${cat.nameHe} / ${cat.nameAr} (sortOrder=${cat.sortOrder ?? "n/a"})`);
  });
  console.log("\n🛒 المنتجات:");
  console.log(`  • ${products.length} منتج`);
  console.log("\n🚚 الشحن:");
  console.log(`  • ${deliveryAreas.length} منطقة توصيل`);
  console.log(`  • ${pickupPoints.length} نقطة استلام`);
  console.log("\n🎟️  التخفيضات والعروض:");
  console.log(`  • ${coupons.length} كوبون`);
  console.log(`  • ${campaigns.length} حملة`);
  console.log(`  • ${savedGiftsCount} عرض هدايا`);
  console.log(`  • ${offers.length} عرض موسمي`);
  console.log("\n📄 المحتوى:");
  console.log(`  • ${pages.length} صفحة محتوى`);
  console.log("\n💬 التقييمات:");
  console.log(`  • ${reviewTargets.length} تقييم عينة`);
  console.log("=".repeat(60));
  console.log("\n✅ اكتمل سكريبت البذر بنجاح!");
  console.log("\n💡 ملاحظة: تحكم بالتنظيف عبر SEED_CLEANUP:");
  console.log("   • all   => حذف قاعدة البيانات بالكامل (الافتراضي)");
  console.log("   • smart => حذف ذكي");
  console.log("   • none  => بدون حذف");
}

main()
  .catch((err) => {
    console.error("❌ فشل سكريبت البذر:", err);
    process.exitCode = 1;
  })
  .finally(async () => {
    try {
      await mongoose.disconnect();
      console.log("🔌 تم إغلاق اتصال MongoDB");
    } catch (e) {
      console.warn("[best-effort] فشل قطع اتصال mongoose:", String(e?.message || e));
    }
  });
