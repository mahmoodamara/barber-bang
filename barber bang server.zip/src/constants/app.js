export const APP = {
  name: "barber-store-server",
  version: "0.0.1",
};
